/// <reference types="next" />
/// <reference types="next/image-types/global" />

// Next.js tarafından yönetilen ortam tipleri.
