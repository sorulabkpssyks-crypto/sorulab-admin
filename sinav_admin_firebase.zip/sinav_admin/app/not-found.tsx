import Link from "next/link";

export default function NotFound() {
  return <main className="error-page"><h1>Sayfa bulunamadı</h1><p>Bu adres yönetim panelinde bulunmuyor.</p><Link href="/" className="btn btn-primary">Ana sayfaya dön</Link></main>;
}
