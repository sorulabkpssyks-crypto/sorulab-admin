"use client";

export default function ErrorPage({ reset }: { error: Error & { digest?: string }; reset: () => void }) {
  return <main className="error-page"><h1>Panel yüklenemedi</h1><p>Sayfayı yeniden yükleyerek tekrar deneyebilirsiniz.</p><button onClick={reset} className="btn btn-primary">Tekrar dene</button></main>;
}
