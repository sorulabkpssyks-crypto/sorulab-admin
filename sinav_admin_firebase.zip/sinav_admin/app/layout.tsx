import type { Metadata, Viewport } from "next";
import { AdminProvider } from "@/lib/admin-context";
import { AuthProvider } from "@/lib/auth-context";
import AuthGate from "@/components/AuthGate";
import "./globals.css";

export const metadata: Metadata = {
  title: "SınavApp Admin Paneli",
  description: "SınavApp soru, kullanıcı, forum ve abonelik yönetim paneli.",
  icons: { icon: "/favicon.svg" },
};
export const viewport: Viewport = { width: "device-width", initialScale: 1 };

export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return <html lang="tr"><body><AuthProvider><AdminProvider><AuthGate>{children}</AuthGate></AdminProvider></AuthProvider></body></html>;
}
