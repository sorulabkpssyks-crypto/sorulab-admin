import { notFound } from "next/navigation";
import AdminPanel from "@/components/AdminPanel";

const routes = ["sorular", "pdf", "kategoriler", "ipuclari", "admob", "reklam-alanlari", "abonelikler", "forum", "yorumlar", "raporlar", "kufur-filtresi", "forum-ayarlari", "kullanicilar", "uygulama-ayarlari", "istatistikler", "bildirimler", "yedekleme", "gunlukler"];

export default async function Page({ params }: { params: Promise<{ section?: string[] }> }) {
  const { section } = await params;
  if (section && (section.length !== 1 || !routes.includes(section[0]))) notFound();
  return <AdminPanel section={section?.[0] ?? ""} />;
}
