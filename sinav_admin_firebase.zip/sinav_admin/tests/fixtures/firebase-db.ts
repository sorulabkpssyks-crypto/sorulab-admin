// An opaque test reference; no Firebase app or network is started by these tests.
export const db = Object.freeze({ testDatabase: true });
