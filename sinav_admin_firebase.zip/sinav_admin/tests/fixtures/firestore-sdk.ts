// Test-only SDK boundary. Production serialization and diffing run unchanged.
type Data = Record<string, unknown>;
type Reference = { path: string };
export type Operation = { kind: "set" | "update" | "delete"; path: string; data?: Data };
type Snapshot = { docs: { id: string; data(): Data }[]; metadata: { fromCache: boolean; hasPendingWrites: boolean } };
const listeners = new Map<string, Set<(snapshot: Snapshot) => void>>();
export const batches: { operations: Operation[]; commitCalls: number }[] = [];
let commitFailure: unknown;

export function resetSdk(): void {
  listeners.clear();
  batches.length = 0;
  commitFailure = undefined;
}
export function failNextCommit(error: unknown): void { commitFailure = error; }
export function feedSnapshot(path: string, documents: Record<string, Data>, metadata = { fromCache: false, hasPendingWrites: false }): void {
  const snapshot = { docs: Object.entries(documents).map(([id, data]) => ({ id, data: () => data })), metadata };
  for (const listener of listeners.get(path) ?? []) listener(snapshot);
}
export function collection(_db: unknown, path: string): Reference { return { path }; }
export function doc(_db: unknown, path: string, id: string): Reference { return { path: `${path}/${id}` }; }
export function increment(value: number): Data { return { __testSentinel: "increment", value }; }
export function serverTimestamp(): Data { return { __testSentinel: "serverTimestamp" }; }
export function onSnapshot(reference: Reference, _options: unknown, receive: (snapshot: Snapshot) => void, _error: (error: unknown) => void): () => void {
  const callbacks = listeners.get(reference.path) ?? new Set<(snapshot: Snapshot) => void>();
  callbacks.add(receive);
  listeners.set(reference.path, callbacks);
  return () => callbacks.delete(receive);
}
export function writeBatch(_db: unknown) {
  const captured = { operations: [] as Operation[], commitCalls: 0 };
  batches.push(captured);
  return {
    set(reference: Reference, data: Data) { captured.operations.push({ kind: "set", path: reference.path, data }); },
    update(reference: Reference, data: Data) { captured.operations.push({ kind: "update", path: reference.path, data }); },
    delete(reference: Reference) { captured.operations.push({ kind: "delete", path: reference.path }); },
    async commit() {
      captured.commitCalls++;
      if (commitFailure !== undefined) {
        const error = commitFailure;
        commitFailure = undefined;
        throw error;
      }
    },
  };
}
