import assert from "node:assert/strict";
import { existsSync } from "node:fs";
import { registerHooks } from "node:module";
import { afterEach, beforeEach, test } from "node:test";
import type { AdminData, Question } from "../lib/mockData.ts";

// Stub only SDK I/O, retaining the real production service and adapters.
registerHooks({
  resolve(specifier, context, nextResolve) {
    if (specifier === "firebase/firestore") return { url: new URL("./fixtures/firestore-sdk.ts", import.meta.url).href, shortCircuit: true };
    if (specifier === "./firebase" && context.parentURL?.endsWith("/lib/firestore-service.ts")) {
      return { url: new URL("./fixtures/firebase-db.ts", import.meta.url).href, shortCircuit: true };
    }
    if (["./firestore-adapters", "./mockData"].includes(specifier) && context.parentURL) {
      const url = new URL(`${specifier}.ts`, context.parentURL);
      if (existsSync(url)) return { url: url.href, shortCircuit: true };
    }
    return nextResolve(specifier, context);
  },
});
const service = await import("../lib/firestore-service.ts");
const sdk = await import("./fixtures/firestore-sdk.ts");
let unsubscribers: (() => void)[] = [];
let live: AdminData;

function emptyData(): AdminData {
  return {
    users: [], questions: [], forums: [], categories: [], plans: [], filters: [],
    admob: { appId: "", bannerId: "", interstitialId: "", rewardedId: "" },
    hints: [], ads: [], comments: [], reports: [], notifications: [], profanity: [], logs: [],
    settings: { name: "Test", email: "", maintenance: false, registration: true, forumEnabled: true, maxPostLength: 1000, dailyPostLimit: 10 },
  };
}
const rawQuestion = {
  questionText: "Mevcut soru?", categoryId: "math", level: "easy", choices: ["A seçeneği", "B seçeneği"],
  correctAnswer: "B", solution: "Açıklama", createdAt: "2025-05-09T12:00:00Z", mobileOnly: { image: "retained.png" },
};
function nextData(): AdminData { return structuredClone(live); }
function newQuestion(id = "new-question"): Question {
  return { id, text: "Yeni soru?", category: "Matematik", difficulty: "Orta", date: "2026-10-07", options: ["Bir", "İki"], answer: 0, explanation: "Bir doğru." };
}

beforeEach(() => {
  sdk.resetSdk();
  live = emptyData();
  for (const key of ["users", "questions", "forums", "categories"] as const) {
    unsubscribers.push(service.subscribeCollection(key, (rows) => { Object.assign(live, { [key]: rows }); }, (error) => { throw error; }));
    sdk.feedSnapshot(service.coreCollections[key], {});
  }
});
afterEach(() => { for (const unsubscribe of unsubscribers) unsubscribe(); unsubscribers = []; });

test("live snapshots use the four collection paths and resolve category IDs without demo rows", () => {
  assert.deepEqual(live.users, []);
  assert.deepEqual(live.questions, []);
  sdk.feedSnapshot("questions", { q1: rawQuestion });
  assert.equal(live.questions[0].category, "math");
  sdk.feedSnapshot("categories", { math: { title: "Matematik", totalQuestions: 10 } });
  assert.equal(live.questions[0].category, "Matematik");
  assert.equal(live.questions[0].answer, 1);
  sdk.feedSnapshot("users", { uid: { displayName: "Canlı Kullanıcı", emailAddress: "user@example.test", userRole: "admin", isPremium: true, disabled: false } });
  sdk.feedSnapshot("forum_posts", { post: { authorName: "Yazar", title: "Canlı gönderi", approvalStatus: "approved" } });
  assert.equal(live.users[0].id, "uid");
  assert.equal(live.users[0].role, "Admin");
  assert.equal(live.forums[0].topic, "Canlı gönderi");
  assert.equal(live.forums[0].status, "Onaylandı");
});

test("editing question text updates the existing alias without replacing creation date or mobile fields", async () => {
  sdk.feedSnapshot("questions", { "q-real-id": rawQuestion });
  const previous = nextData();
  const next = nextData();
  next.questions[0].text = "Düzenlenen soru?";
  await service.persistCoreChanges(previous, next);
  assert.equal(sdk.batches.length, 1);
  assert.equal(sdk.batches[0].commitCalls, 1);
  assert.deepEqual(sdk.batches[0].operations, [{ kind: "update", path: "questions/q-real-id", data: { questionText: "Düzenlenen soru?", updatedAt: { __testSentinel: "serverTimestamp" } } }]);
  assert.equal(rawQuestion.createdAt, "2025-05-09T12:00:00Z");
  assert.deepEqual(rawQuestion.mobileOnly, { image: "retained.png" });
});

test("new question and the category count delta are committed in the same atomic batch", async () => {
  sdk.feedSnapshot("categories", { math: { title: "Matematik", totalQuestions: 10, customColor: "blue" } });
  const previous = nextData();
  const next = nextData();
  next.questions.push(newQuestion());
  next.categories[0].count++;
  await service.persistCoreChanges(previous, next);
  assert.equal(sdk.batches.length, 1);
  assert.equal(sdk.batches[0].commitCalls, 1);
  const operations = sdk.batches[0].operations;
  assert.equal(operations.length, 2);
  const question = operations.find((operation) => operation.path === "questions/new-question")!;
  assert.equal(question.kind, "set");
  assert.deepEqual(question.data?.options, ["Bir", "İki"]);
  assert.deepEqual(question.data?.createdAt, { __testSentinel: "serverTimestamp" });
  assert.deepEqual(operations.find((operation) => operation.path === "categories/math"), { kind: "update", path: "categories/math", data: { totalQuestions: { __testSentinel: "increment", value: 1 }, updatedAt: { __testSentinel: "serverTimestamp" } } });
});

test("question deletion targets the original Firestore document path", async () => {
  sdk.feedSnapshot("questions", { "server-document-42": rawQuestion });
  const previous = nextData();
  const next = nextData();
  next.questions = [];
  await service.persistCoreChanges(previous, next);
  assert.deepEqual(sdk.batches[0].operations, [{ kind: "delete", path: "questions/server-document-42" }]);
});

test("forum approval writes English status to the existing alias", async () => {
  sdk.feedSnapshot("forum_posts", { post: { authorName: "Yazar", title: "Konu", approvalStatus: "pending", createdAt: "2025-01-01" } });
  const previous = nextData();
  const next = nextData();
  next.forums[0].status = "Onaylandı";
  await service.persistCoreChanges(previous, next);
  assert.deepEqual(sdk.batches[0].operations, [{ kind: "update", path: "forum_posts/post", data: { approvalStatus: "approved", updatedAt: { __testSentinel: "serverTimestamp" } } }]);
});

test("a rejected Firestore commit propagates to the caller", async () => {
  const next = nextData();
  next.questions.push(newQuestion());
  const rejection = Object.assign(new Error("Denied"), { code: "permission-denied" });
  sdk.failNextCommit(rejection);
  await assert.rejects(service.persistCoreChanges(live, next), (error) => error === rejection);
  assert.equal(sdk.batches[0].commitCalls, 1);
});

test("duplicate or invalid document IDs reject before opening a write batch", async () => {
  const duplicate = nextData();
  duplicate.questions.push(newQuestion("same"), newQuestion("same"));
  await assert.rejects(service.persistCoreChanges(live, duplicate), /birden fazla/);
  for (const id of ["", "bad/path", ".", "..", "__reserved__"]) {
    const next = nextData();
    next.questions.push(newQuestion(id));
    await assert.rejects(service.persistCoreChanges(live, next), /Geçersiz/);
  }
  assert.equal(sdk.batches.length, 0);
});

test("unchanged rows produce no write batch or commit", async () => {
  sdk.feedSnapshot("questions", { q1: rawQuestion });
  await service.persistCoreChanges(live, nextData());
  assert.equal(sdk.batches.length, 0);
});
