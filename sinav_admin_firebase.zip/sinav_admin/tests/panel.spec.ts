import { test, expect } from "@playwright/test";

test.beforeEach(async ({ page }) => {
  await page.goto("/");
  await expect(page.getByRole("heading", { name: "Yönetici girişi", exact: true })).toBeVisible();
});

test("oturum açılmadan canlı panel verileri görünmez", async ({ page }) => {
  await expect(page.getByRole("heading", { name: "Son Eklenen Sorular", exact: true })).toHaveCount(0);
  await expect(page.getByLabel("E-posta adresi", { exact: true })).toBeVisible();
  await expect(page.getByLabel("Parola", { exact: true })).toHaveAttribute("type", "password");
});

test("parola görünürlüğü değiştirilebilir", async ({ page }) => {
  await page.getByRole("button", { name: "Parolayı göster", exact: true }).click();
  await expect(page.getByLabel("Parola", { exact: true })).toHaveAttribute("type", "text");
  await page.getByRole("button", { name: "Parolayı gizle", exact: true }).click();
  await expect(page.getByLabel("Parola", { exact: true })).toHaveAttribute("type", "password");
});

test("boş e-posta ile sıfırlama isteği gönderilmez", async ({ page }) => {
  let requests = 0;
  page.on("request", (request) => { if (request.url().includes("accounts:sendOobCode")) requests += 1; });
  await page.getByRole("button", { name: "Parolamı unuttum", exact: true }).click();
  await expect(page.getByRole("alert")).toHaveText("Parola sıfırlamak için geçerli bir e-posta adresi girin.");
  expect(requests).toBe(0);
});

test("yönetim adresleri oturum kapısıyla korunur", async ({ page }) => {
  for (const route of ["sorular", "forum", "kategoriler", "kullanicilar", "pdf"]) {
    await page.goto(`/${route}`);
    await expect(page.getByRole("heading", { name: "Yönetici girişi", exact: true })).toBeVisible();
    await expect(page.getByRole("table")).toHaveCount(0);
  }
});

test("mobil giriş ekranı taşmaz", async ({ page }) => {
  await page.setViewportSize({ width: 390, height: 844 });
  await expect(page.getByRole("button", { name: "Giriş yap", exact: true })).toBeVisible();
  expect(await page.evaluate(() => document.documentElement.scrollWidth <= window.innerWidth)).toBe(true);
});
