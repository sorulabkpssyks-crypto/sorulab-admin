import assert from "node:assert/strict";
import { test } from "node:test";
import { normalizeCategory, normalizeDate, normalizeForumPost, normalizeQuestion, normalizeUser } from "../lib/firestore-adapters.ts";

test("Firestore document ID, category relationships and object options are normalized", () => {
  const question = normalizeQuestion("question-live-id", {
    id: 8451, questionText: "2 + 2 kaçtır?", categoryId: "math-id", difficulty: "easy",
    choices: [{ text: "3", isCorrect: false }, { text: "4", isCorrect: true }],
    correctAnswer: "B", createdAt: { toDate: () => new Date("2026-10-07T09:10:00Z") },
    solution: "Toplama işlemi yapılır.",
  }, new Map([["math-id", "Matematik"]]));
  assert.deepEqual(question, {
    id: "question-live-id", text: "2 + 2 kaçtır?", category: "Matematik", difficulty: "Kolay",
    options: ["3", "4"], answer: 1, date: "2026-10-07T09:10:00.000Z", explanation: "Toplama işlemi yapılır.",
  });
});

test("answer indices, letters, answer text and option flags are accepted", () => {
  assert.equal(normalizeQuestion("index", { options: ["Ankara", "İzmir"], answer: 0 }).answer, 0);
  assert.equal(normalizeQuestion("value", { options: ["Ankara", "İzmir"], correctAnswer: "İzmir" }).answer, 1);
  assert.equal(normalizeQuestion("flags", { options: [{ value: "A" }, { value: "B", correct: true }] }).answer, 1);
  assert.equal(normalizeQuestion("letter", { choices: { A: "Ankara", B: "İzmir" }, correctOption: "B" }).answer, 1);
  assert.equal(normalizeQuestion("missing", { options: ["Ankara", "İzmir"] }).answer, -1);
});

test("user profile aliases, subscriptions, disabled accounts and timestamps are accepted", () => {
  const user = normalizeUser("uid", {
    displayName: "Ayşe", email: "ayse@example.com", role: "moderator",
    subscription: { status: "active", plan: "yearly" }, disabled: true, createdAt: { seconds: 0 },
  });
  assert.deepEqual(user, {
    id: "uid", name: "Ayşe", email: "ayse@example.com", role: "Moderatör",
    premium: true, active: false, joined: "1970-01-01T00:00:00.000Z",
  });
  assert.equal(normalizeUser("admin", { role: "Admin", isPremium: false, isActive: true }).role, "Admin");
  assert.equal(normalizeUser("user", { role: "Kullanıcı", subscription: "premium" }).premium, true);
  assert.equal(normalizeUser("blocked", { status: "disabled" }).active, false);
});

test("forum English and Turkish statuses, authors, titles and bodies are accepted", () => {
  const post = normalizeForumPost("forum-id", {
    author: { displayName: "Ömer" }, title: "Kaynak önerisi", body: "Hangi kaynak?",
    moderationStatus: "pending", timestamp: "2026-10-07",
  });
  assert.equal(post.user, "Ömer");
  assert.equal(post.avatar, "Ö");
  assert.equal(post.topic, "Kaynak önerisi");
  assert.equal(post.status, "Onay Bekliyor");
  assert.equal(normalizeForumPost("approved", { status: "approved" }).status, "Onaylandı");
  assert.equal(normalizeForumPost("rejected", { approvalStatus: "rejected" }).status, "Reddedildi");
  assert.equal(normalizeForumPost("turkish", { status: "Onaylandı" }).status, "Onaylandı");
});

test("category counts use stored counts or counts derived from real questions", () => {
  assert.deepEqual(normalizeCategory("cat", { title: "Matematik" }, 7), { id: "cat", name: "Matematik", count: 7 });
  assert.equal(normalizeCategory("cat", { name: "Matematik", questionCount: 12 }, 7).count, 12);
  assert.equal(normalizeCategory("cat", { name: "Matematik", count: "980" }).count, 980);
});

test("missing fields and invalid dates never introduce demo data or a fabricated answer", () => {
  assert.equal(normalizeDate(undefined), "");
  assert.equal(normalizeDate("not-a-date"), "");
  assert.equal(normalizeDate({ _seconds: 0 }), "1970-01-01T00:00:00.000Z");
  assert.equal(normalizeQuestion("empty", {}).date, "");
  assert.equal(normalizeQuestion("empty", {}).text, "");
  assert.equal(normalizeQuestion("empty", {}).answer, -1);
  assert.deepEqual(normalizeQuestion("empty", {}).options, []);
  assert.equal(normalizeUser("empty", {}).joined, "");
  assert.equal(normalizeCategory("empty", {}).count, 0);
});
