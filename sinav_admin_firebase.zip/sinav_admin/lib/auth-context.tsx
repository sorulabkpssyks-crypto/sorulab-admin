"use client";

import { createContext, useCallback, useContext, useEffect, useMemo, useState } from "react";
import type { ReactNode } from "react";
import {
  browserLocalPersistence,
  browserSessionPersistence,
  onAuthStateChanged,
  sendPasswordResetEmail,
  setPersistence,
  signInWithEmailAndPassword,
  signOut as firebaseSignOut,
} from "firebase/auth";
import type { User } from "firebase/auth";
import { auth } from "@/lib/firebase";

type AuthContextValue = {
  user: User | null;
  loading: boolean;
  error: string | null;
  signIn: (email: string, password: string, remember: boolean) => Promise<void>;
  signOut: () => Promise<void>;
  resetPassword: (email: string) => Promise<void>;
};

const AuthContext = createContext<AuthContextValue | null>(null);

function authErrorMessage(error: unknown): string {
  const code = typeof error === "object" && error !== null && "code" in error
    ? String(error.code)
    : "";

  switch (code) {
    case "auth/invalid-email":
      return "Geçerli bir e-posta adresi girin.";
    case "auth/invalid-credential":
    case "auth/invalid-login-credentials":
    case "auth/user-not-found":
    case "auth/wrong-password":
    case "auth/user-disabled":
      return "Giriş yapılamadı. E-posta adresinizi ve parolanızı kontrol edin.";
    case "auth/too-many-requests":
      return "Çok fazla deneme yapıldı. Bir süre sonra tekrar deneyin.";
    case "auth/network-request-failed":
      return "Firebase bağlantısı kurulamadı. İnternet bağlantınızı kontrol edin.";
    case "auth/operation-not-allowed":
      return "E-posta ve parola ile giriş Firebase projesinde etkin değil.";
    case "auth/unauthorized-domain":
      return "Bu adres Firebase Authentication yetkili alan adları arasında değil.";
    case "auth/web-storage-unsupported":
      return "Tarayıcı oturum depolamaya izin vermiyor. Tarayıcı ayarlarınızı kontrol edin.";
    case "auth/invalid-api-key":
    case "auth/app-not-authorized":
    case "auth/configuration-not-found":
      return "Firebase Authentication yapılandırması doğrulanamadı.";
    default:
      return "İşlem tamamlanamadı. Lütfen tekrar deneyin.";
  }
}

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<User | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    return onAuthStateChanged(auth, (currentUser) => {
      setUser(currentUser);
      setError(null);
      setLoading(false);
    }, (cause) => {
      setUser(null);
      setError(authErrorMessage(cause));
      setLoading(false);
    });
  }, []);

  const signIn = useCallback(async (email: string, password: string, remember: boolean) => {
    setError(null);
    try {
      await setPersistence(auth, remember ? browserLocalPersistence : browserSessionPersistence);
      await signInWithEmailAndPassword(auth, email.trim(), password);
    } catch (cause) {
      const message = authErrorMessage(cause);
      setError(message);
      throw new Error(message);
    }
  }, []);

  const signOut = useCallback(async () => {
    setError(null);
    try {
      await firebaseSignOut(auth);
    } catch (cause) {
      const message = authErrorMessage(cause);
      setError(message);
      throw new Error(message);
    }
  }, []);

  const resetPassword = useCallback(async (email: string) => {
    setError(null);
    try {
      await sendPasswordResetEmail(auth, email.trim());
    } catch (cause) {
      // Hesabın var olup olmadığına bakılmaksızın aynı sonuç gösterilir.
      if (typeof cause === "object" && cause !== null && "code" in cause && cause.code === "auth/user-not-found") return;
      const message = authErrorMessage(cause);
      setError(message);
      throw new Error(message);
    }
  }, []);

  const value = useMemo(() => ({ user, loading, error, signIn, signOut, resetPassword }), [user, loading, error, signIn, signOut, resetPassword]);

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
}

export function useAuth(): AuthContextValue {
  const context = useContext(AuthContext);
  if (!context) throw new Error("useAuth, AuthProvider içinde kullanılmalıdır.");
  return context;
}
