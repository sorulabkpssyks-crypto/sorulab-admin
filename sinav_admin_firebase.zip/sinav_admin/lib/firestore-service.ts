import {
  collection,
  doc,
  increment,
  onSnapshot,
  serverTimestamp,
  writeBatch,
  type DocumentData,
  type Unsubscribe,
} from "firebase/firestore";
import { db } from "./firebase";
import {
  at, categoryFields, field, first, forumFields, object, optionFields, optionValues,
  own, questionFields, string, userFields,
  normalizeCategory, normalizeForumPost, normalizeQuestion, normalizeUser,
  type RawDocument,
} from "./firestore-adapters";
export { normalizeDate, normalizeCategory, normalizeForumPost, normalizeQuestion, normalizeUser } from "./firestore-adapters";
import type { AdminData, Category, Difficulty, ForumPost, ForumStatus, Question, User } from "./mockData";

export type CoreKey = "users" | "questions" | "forums" | "categories";
export interface SnapshotMetadata { fromCache: boolean; hasPendingWrites: boolean }
export const coreCollections: Record<CoreKey, string> = {
  users: "users", questions: "questions", forums: "forum_posts", categories: "categories",
};
type CoreRecord = User | Question | ForumPost | Category;
const coreKeys: CoreKey[] = ["users", "questions", "forums", "categories"];
// Kept in memory only: aliases are needed to update a document without replacing
// fields belonging to the mobile application or another administration tool.
const sourceDocuments: Record<CoreKey, Map<string, RawDocument>> = {
  users: new Map(), questions: new Map(), forums: new Map(), categories: new Map(),
};
const questionSubscribers = new Set<() => void>();
const categorySubscribers = new Set<() => void>();
export function clearCoreCache() {
  coreKeys.forEach((key) => sourceDocuments[key].clear());
}

function categoryNames(categories?: Category[]): Map<string, string> {
  return categories
    ? new Map(categories.map((category) => [String(category.id), category.name]))
    : new Map([...sourceDocuments.categories].map(([id, raw]) => [id, normalizeCategory(id, raw).name]));
}
function categoryQuestionCount(id: string, raw: RawDocument): number {
  const name = string(first(raw, categoryFields.name));
  let count = 0;
  for (const question of sourceDocuments.questions.values()) {
    const category = first(question, questionFields.category);
    const value = typeof category === "object" ? string(first(object(category), ["id", "name", "title"])) : string(category);
    if (question.categoryId === id || value === id || (name !== "" && value === name)) count++;
  }
  return count;
}
function normalize<K extends CoreKey>(key: K, id: string, raw: RawDocument): AdminData[K][number] {
  const converters = {
    questions: () => normalizeQuestion(id, raw, categoryNames()), forums: () => normalizeForumPost(id, raw),
    categories: () => normalizeCategory(id, raw, categoryQuestionCount(id, raw)), users: () => normalizeUser(id, raw),
  };
  return converters[key]() as AdminData[K][number];
}

/** A missing or inaccessible collection stays empty; demo data is never substituted. */
export function subscribeCollection<K extends CoreKey>(key: K, onData: (rows: AdminData[K], metadata?: SnapshotMetadata) => void, onError: (error: unknown) => void): Unsubscribe {
  let receivedSnapshot = false;
  let serverConfirmed = false;
  let metadata: SnapshotMetadata = { fromCache: false, hasPendingWrites: false };
  const emit = () => {
    if (!receivedSnapshot) return;
    const rows = [...sourceDocuments[key]].map(([id, raw]) => normalize(key, id, raw));
    if (key === "questions" || key === "forums") {
      rows.sort((a, b) => ("date" in b ? b.date : "").localeCompare("date" in a ? a.date : ""));
    } else if (key === "users") {
      rows.sort((a, b) => ("joined" in b ? b.joined : "").localeCompare("joined" in a ? a.joined : ""));
    } else {
      rows.sort((a, b) => ("name" in a ? a.name : "").localeCompare("name" in b ? b.name : "", "tr"));
    }
    onData(rows as AdminData[K], metadata);
  };
  if (key === "questions") questionSubscribers.add(emit);
  if (key === "categories") categorySubscribers.add(emit);
  const unsubscribe = onSnapshot(collection(db, coreCollections[key]), { includeMetadataChanges: true }, (snapshot) => {
    // Re-authorize collection access after each login before using the SDK cache.
    if (snapshot.metadata.fromCache && !serverConfirmed) return;
    if (!snapshot.metadata.fromCache) serverConfirmed = true;
    receivedSnapshot = true;
    metadata = { fromCache: snapshot.metadata.fromCache, hasPendingWrites: snapshot.metadata.hasPendingWrites };
    const documents = sourceDocuments[key];
    documents.clear();
    snapshot.docs.forEach((document) => documents.set(document.id, document.data()));
    emit();
    if (key === "categories") questionSubscribers.forEach((notify) => notify());
    if (key === "questions") categorySubscribers.forEach((notify) => notify());
  }, onError);
  return () => { unsubscribe(); questionSubscribers.delete(emit); categorySubscribers.delete(emit); };
}

const equal = (a: unknown, b: unknown) => JSON.stringify(a) === JSON.stringify(b);
function encodedDifficulty(value: Difficulty, original: unknown): string | number {
  if (typeof original === "number") return { Kolay: 1, Orta: 2, Zor: 3 }[value];
  const originalText = string(original);
  return /^(easy|medium|hard|difficult|beginner)$/i.test(originalText)
    ? { Kolay: "easy", Orta: "medium", Zor: "hard" }[value] : value;
}
function encodedStatus(value: ForumStatus, original: unknown): string {
  if (["Onaylandı", "Onay Bekliyor", "Reddedildi"].includes(string(original))) return value;
  return { Onaylandı: "approved", "Onay Bekliyor": "pending", Reddedildi: "rejected" }[value];
}
function encodedRole(value: User["role"], original: unknown): string {
  if (["Kullanıcı", "Moderatör", "Admin"].includes(string(original))) return value;
  return { Kullanıcı: "user", Moderatör: "moderator", Admin: "admin" }[value];
}
function encodedBool(value: boolean, original: unknown, path: string): unknown {
  if (path === "disabled") return !value;
  if (original && typeof original === "object") {
    const subscription = object(original);
    const activePath = field(subscription, ["active", "isActive", "isPremium", "status"], "active");
    return { ...subscription, [activePath]: encodedBool(value, subscription[activePath], `subscription.${activePath}`) };
  }
  if (typeof original === "number") return value ? 1 : 0;
  if (typeof original === "string") {
    if (["true", "false"].includes(original.toLowerCase())) return String(value);
    if (path.includes("subscription")) return value ? "active" : "inactive";
    if (path === "status") return value ? "active" : "disabled";
  }
  return value;
}
function encodedOptions(question: Question, originals: unknown): unknown {
  const values = optionValues(originals);
  const result = question.options.map((text, index) => {
    const original = values[index];
    if (!original || typeof original !== "object") return text;
    const raw = object(original);
    const next = { ...raw, [field(raw, optionFields, "text")]: text };
    if (own(raw, "isCorrect")) next.isCorrect = question.answer === index;
    if (own(raw, "correct")) next.correct = question.answer === index;
    return next;
  });
  if (originals && typeof originals === "object" && !Array.isArray(originals)) {
    const keys = Object.keys(object(originals));
    return Object.fromEntries(result.map((value, index) => [keys[index] ?? String.fromCharCode(65 + index), value]));
  }
  return result;
}
function encodedAnswer(question: Question, original: unknown): string | number {
  if (typeof original === "string") {
    if (/^[A-Z]$/i.test(original.trim())) return String.fromCharCode(65 + question.answer);
    if (/^\d+$/.test(original.trim())) return String(question.answer);
    return question.options[question.answer] ?? "";
  }
  return question.answer;
}

function serialize(key: CoreKey, next: CoreRecord, previous: CoreRecord | undefined, raw: RawDocument, categories: Category[]): DocumentData {
  const payload: DocumentData = {};
  const changed = (name: string) => !previous || !equal((previous as unknown as RawDocument)[name], (next as unknown as RawDocument)[name]);
  const put = (name: string, aliases: string[], fallback: string, transform?: (value: unknown, original: unknown, path: string) => unknown) => {
    if (!changed(name)) return;
    const path = field(raw, aliases, fallback);
    const value = (next as unknown as RawDocument)[name];
    payload[path] = transform ? transform(value, at(raw, path), path) : value;
  };
  if (key === "questions") {
    const question = next as Question;
    if (!previous && (!question.text.trim() || question.options.length < 2 || question.options.some((option) => !option.trim()) || !Number.isInteger(question.answer) || question.answer < 0 || question.answer >= question.options.length)) {
      throw new Error("Yeni soru için soru metni, en az iki dolu seçenek ve geçerli bir doğru cevap gereklidir.");
    }
    put("text", questionFields.text, "text");
    put("category", questionFields.category, "category", (value, original, path) => {
      const category = categories.find((item) => item.name === value || String(item.id) === value);
      if (path === "categoryId") {
        if (!category && value) throw new Error(`“${String(value)}” kategorisinin Firestore kimliği bulunamadı. Önce kategoriyi ekleyin.`);
        return category ? String(category.id) : "";
      }
      if (original && typeof original === "object") {
        const categoryRaw = object(original);
        const namePath = field(categoryRaw, ["name", "title"], "name");
        return { ...categoryRaw, [namePath]: value };
      }
      return value;
    });
    put("difficulty", questionFields.difficulty, "difficulty", (value, original) => encodedDifficulty(value as Difficulty, original));
    if (changed("options") || (changed("answer") && optionValues(first(raw, questionFields.options)).some((item) => own(object(item), "isCorrect") || own(object(item), "correct")))) {
      const path = field(raw, questionFields.options, "options");
      payload[path] = encodedOptions(question, at(raw, path));
    }
    if (changed("answer") || changed("options")) {
      const path = field(raw, questionFields.answer, "answer");
      payload[path] = encodedAnswer(question, at(raw, path));
    }
    put("explanation", questionFields.explanation, "explanation");
  } else if (key === "forums") {
    put("user", forumFields.user, "user", (value, original) => {
      if (!original || typeof original !== "object") return value;
      const author = object(original);
      return { ...author, [field(author, ["displayName", "name", "username"], "displayName")]: value };
    });
    put("avatar", forumFields.avatar, "avatar"); put("color", forumFields.color, "color");
    put("topic", forumFields.topic, "topic"); put("content", forumFields.content, "content");
    put("status", forumFields.status, "status", (value, original) => encodedStatus(value as ForumStatus, original));
  } else if (key === "categories") {
    put("name", categoryFields.name, "name");
    put("count", categoryFields.count, "questionCount", (value) => {
      const existingCount = first(raw, categoryFields.count);
      return previous && typeof existingCount === "number"
        ? increment(Number(value) - (previous as Category).count)
        : value;
    });
  } else {
    put("name", userFields.name, "name"); put("email", userFields.email, "email");
    put("role", userFields.role, "role", (value, original) => encodedRole(value as User["role"], original));
    put("premium", userFields.premium, "premium", (value, original, path) => encodedBool(value as boolean, original, path));
    put("active", userFields.active, "active", (value, original, path) => encodedBool(value as boolean, original, path));
  }
  // Existing creation dates belong to the original app record and remain intact.
  if (!previous) payload.createdAt = serverTimestamp();
  if (Object.keys(payload).length) payload.updatedAt = serverTimestamp();
  return payload;
}

/** Commits the four live collections in one atomic batch, preserving unknown fields. */
export async function persistCoreChanges(previous: AdminData, next: AdminData): Promise<void> {
  const operations: { key: CoreKey; id: string; kind: "create" | "update" | "delete"; data?: DocumentData }[] = [];
  for (const key of coreKeys) {
    const oldRows = new Map((previous[key] as CoreRecord[]).map((row) => [String(row.id), row]));
    const newRows = new Map((next[key] as CoreRecord[]).map((row) => [String(row.id), row]));
    if (newRows.size !== next[key].length) throw new Error("Aynı Firestore belge kimliği birden fazla kayıtta kullanılamaz.");
    for (const [id, row] of newRows) {
      if (!id || id.includes("/") || id === "." || id === ".." || /^__.*__$/.test(id)) throw new Error("Geçersiz Firestore belge kimliği.");
      const old = oldRows.get(id);
      if (old && equal(old, row)) continue;
      const existing = sourceDocuments[key].get(id);
      const base = old ?? (existing ? normalize(key, id, existing) as CoreRecord : undefined);
      const data = serialize(key, row, base, existing ?? {}, next.categories);
      if (Object.keys(data).length) operations.push({ key, id, kind: base ? "update" : "create", data });
    }
    for (const id of oldRows.keys()) if (!newRows.has(id)) operations.push({ key, id, kind: "delete" });
  }
  if (!operations.length) return;
  if (operations.length > 450) throw new Error("Tek işlemde en fazla 450 kayıt değiştirilebilir. Aktarımı daha küçük gruplara ayırın; hiçbir kayıt yazılmadı.");
  const batch = writeBatch(db);
  for (const operation of operations) {
    const reference = doc(db, coreCollections[operation.key], operation.id);
    if (operation.kind === "delete") batch.delete(reference);
    else if (operation.kind === "create") batch.set(reference, operation.data!);
    else batch.update(reference, operation.data!);
  }
  await batch.commit();
}

export function firebaseErrorMessage(error: unknown): string {
  const details = object(error);
  const code = string(details.code).replace(/^(auth|firestore)\//, "");
  const messages: Record<string, string> = {
    "permission-denied": "Firestore erişimi reddedildi. Hesabınızın yönetici yetkisini ve koleksiyonların güvenlik kurallarını kontrol edin.",
    "unauthenticated": "Bu işlem için yönetici hesabınızla oturum açın.",
    "unavailable": "Firebase hizmetine ulaşılamıyor. İnternet bağlantınızı kontrol edip tekrar deneyin.",
    "network-request-failed": "Firebase bağlantısı kurulamadı. İnternet bağlantınızı kontrol edin.",
    "invalid-api-key": "Firebase API anahtarı geçersiz. Proje yapılandırmasını kontrol edin.",
    "api-key-not-valid.-please-pass-a-valid-api-key.": "Firebase API anahtarı geçersiz. Proje yapılandırmasını kontrol edin.",
    "invalid-credential": "E-posta veya parola hatalı.",
    "invalid-login-credentials": "E-posta veya parola hatalı.",
    "user-not-found": "E-posta veya parola hatalı.",
    "wrong-password": "E-posta veya parola hatalı.",
    "invalid-email": "Geçerli bir e-posta adresi girin.",
    "user-disabled": "Bu kullanıcı hesabı devre dışı bırakılmış.",
    "too-many-requests": "Çok fazla deneme yapıldı. Bir süre sonra tekrar deneyin.",
    "operation-not-allowed": "Firebase Authentication için e-posta/parola ile giriş etkinleştirilmemiş.",
    "failed-precondition": "Firestore işlemi tamamlanamadı. Veritabanı yapılandırmasını ve gerekli dizinleri kontrol edin.",
    "not-found": "Kayıt bulunamadı. Listeyi yenileyip tekrar deneyin.",
    "resource-exhausted": "Firebase kullanım kotası aşıldı. Proje kotasını kontrol edin.",
  };
  return messages[code] ?? string(details.message, "Firebase işlemi tamamlanamadı. Lütfen tekrar deneyin.");
}
