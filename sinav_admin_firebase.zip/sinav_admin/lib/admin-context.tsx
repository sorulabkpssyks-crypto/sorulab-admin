"use client";

import { createContext, useCallback, useContext, useEffect, useRef, useState, type ReactNode } from "react";
import { initialData, type AdminData, type RecordId } from "./mockData";
import { validateBackup } from "./backup";
import { useAuth } from "./auth-context";
import { clearCoreCache, firebaseErrorMessage, persistCoreChanges, subscribeCollection, type CoreKey } from "./firestore-service";

export type DialogKind = "question" | "category" | "plan" | "admob" | "forum" | "hint" | "ad" | "user" | "notification" | "filters" | "profile";
export interface DialogState { kind: DialogKind | "confirm"; id?: RecordId; title?: string; onConfirm?: () => void | boolean | Promise<void | boolean> }
export interface Toast { id: number; message: string; type: "success" | "error" | "info" }
export interface CollectionState { loading: boolean; error: string | null; fromCache: boolean }
interface AdminContextValue {
  data: AdminData; hydrated: boolean; saving: boolean;
  collectionState: Record<CoreKey, CollectionState>; retryCollections: () => void;
  query: string; setQuery: (value: string) => void;
  sidebarOpen: boolean; setSidebarOpen: (value: boolean) => void;
  dialog: DialogState | null; closeDialog: () => void;
  openDialog: (kind: DialogKind, id?: RecordId) => void;
  confirm: (title: string, callback: NonNullable<DialogState["onConfirm"]>) => void;
  updateData: (updater: (data: AdminData) => AdminData, action: string) => Promise<boolean>;
  restoreData: (value: unknown) => Promise<boolean>;
  notify: (message: string, type?: Toast["type"]) => void;
  toasts: Toast[]; dismissToast: (id: number) => void;
}

const LOCAL_KEY = "sinavapp-admin-local-v2";
const CORE_KEYS: CoreKey[] = ["users", "questions", "forums", "categories"];
const emptyData = (): AdminData => ({ ...initialData, users: [], questions: [], forums: [], categories: [], comments: [], reports: [] });
const initialState = (): Record<CoreKey, CollectionState> => Object.fromEntries(CORE_KEYS.map((key) => [key, { loading: true, error: null, fromCache: true }])) as Record<CoreKey, CollectionState>;
const withoutCore = ({ users: _users, questions: _questions, forums: _forums, categories: _categories, ...local }: AdminData) => local;
const AdminContext = createContext<AdminContextValue | null>(null);

export function AdminProvider({ children }: { children: ReactNode }) {
  const { user } = useAuth();
  const [data, setData] = useState<AdminData>(emptyData);
  const dataRef = useRef(data);
  const [hydrated, setHydrated] = useState(false);
  const [saving, setSaving] = useState(false);
  const [collectionState, setCollectionState] = useState(initialState);
  const stateRef = useRef(collectionState);
  const [retry, setRetry] = useState(0);
  const [query, setQuery] = useState("");
  const [sidebarOpen, setSidebarOpen] = useState(true);
  const [dialog, setDialog] = useState<DialogState | null>(null);
  const [toasts, setToasts] = useState<Toast[]>([]);
  const sequence = useRef(0);
  const mutation = useRef(false);
  const session = useRef(0);
  const timers = useRef<ReturnType<typeof setTimeout>[]>([]);
  const dismissToast = useCallback((id: number) => setToasts((items) => items.filter((item) => item.id !== id)), []);
  const notify = useCallback((message: string, type: Toast["type"] = "success") => {
    const id = ++sequence.current;
    setToasts((items) => [...items.slice(-3), { id, message, type }]);
    timers.current.push(setTimeout(() => dismissToast(id), 4500));
  }, [dismissToast]);
  const replaceData = useCallback((value: AdminData) => { dataRef.current = value; setData(value); }, []);
  const replaceState = useCallback((value: Record<CoreKey, CollectionState>) => { stateRef.current = value; setCollectionState(value); }, []);

  useEffect(() => {
    setSidebarOpen(window.innerWidth >= 768);
    return () => timers.current.forEach(clearTimeout);
  }, []);

  useEffect(() => {
    const token = ++session.current;
    clearCoreCache();
    const serverAuthorized = new Set<CoreKey>();
    setDialog(null); setQuery(""); setToasts([]); setHydrated(false);
    let local = emptyData();
    if (user) {
      try {
        const saved = localStorage.getItem(`${LOCAL_KEY}:${user.uid}`);
        if (saved) local = { ...local, ...withoutCore(validateBackup({ ...local, ...JSON.parse(saved), users: [], questions: [], forums: [], categories: [] })) };
      } catch { notify("Yerel ayarlar okunamadı. Varsayılan ayarlar kullanılıyor.", "error"); }
    }
    replaceData(local); replaceState(initialState()); setHydrated(true);
    if (!user) return;
    const unsubscribers = CORE_KEYS.map((key) => subscribeCollection(key,
      (rows, metadata) => {
        if (token !== session.current) return;
        // A different signed-in account must not see the previous account's SDK cache.
        if (metadata?.fromCache && !serverAuthorized.has(key)) return;
        if (!metadata?.fromCache) serverAuthorized.add(key);
        replaceData({ ...dataRef.current, [key]: rows });
        replaceState({ ...stateRef.current, [key]: { loading: false, error: null, fromCache: metadata?.fromCache ?? false } });
      },
      (error) => {
        if (token !== session.current) return;
        replaceData({ ...dataRef.current, [key]: [] });
        replaceState({ ...stateRef.current, [key]: { loading: false, error: firebaseErrorMessage(error), fromCache: false } });
      },
    ));
    return () => { session.current += 1; unsubscribers.forEach((unsubscribe) => unsubscribe()); };
  }, [user?.uid, retry, notify, replaceData, replaceState]);

  useEffect(() => {
    if (!hydrated || !user) return;
    try { localStorage.setItem(`${LOCAL_KEY}:${user.uid}`, JSON.stringify(withoutCore(dataRef.current))); }
    catch { /* Core records stay on Firestore; local export is still available. */ }
  }, [data, hydrated, user?.uid]);

  const updateData = useCallback(async (updater: (current: AdminData) => AdminData, action: string): Promise<boolean> => {
    if (!user) { notify("İşlem için yeniden giriş yapın.", "error"); return false; }
    if (mutation.current) { notify("Önce devam eden kaydetme işlemini bekleyin.", "info"); return false; }
    const previous = dataRef.current;
    const next = updater(previous);
    const changed = CORE_KEYS.filter((key) => JSON.stringify(previous[key]) !== JSON.stringify(next[key]));
    if (changed.some((key) => stateRef.current[key].loading || stateRef.current[key].error)) {
      notify("İlgili koleksiyon yüklenmeden veya erişim hatası çözülmeden kaydetme yapılamaz.", "error"); return false;
    }
    if (changed.length && !navigator.onLine) { notify("Firestore’a kaydetmek için internet bağlantısı gerekir.", "error"); return false; }
    const token = session.current;
    mutation.current = true; setSaving(true);
    try {
      if (changed.length) await persistCoreChanges(previous, next);
      if (token !== session.current) return false;
      // Canlı koleksiyonları yalnızca onSnapshot günceller; eşzamanlı kayıtlar korunur.
      replaceData({ ...dataRef.current, ...withoutCore(next), logs: [{ id: Date.now(), action, date: new Date().toISOString(), type: "Bilgi" as const }, ...dataRef.current.logs].slice(0, 500) });
      return true;
    } catch (error) {
      if (token === session.current) notify(firebaseErrorMessage(error), "error");
      return false;
    } finally { mutation.current = false; setSaving(false); }
  }, [user?.uid, notify, replaceData]);

  const restoreData = useCallback(async (value: unknown) => {
    try {
      const restored = validateBackup(value);
      const success = await updateData((current) => ({ ...current, ...withoutCore(restored) }), "Yerel ayarlar yedekten geri yüklendi; canlı koleksiyonlar korundu");
      if (success) notify("Yerel ayarlar geri yüklendi. Firestore kayıtları korundu.");
      return success;
    } catch (error) { notify(error instanceof Error ? error.message : "Yedek okunamadı.", "error"); return false; }
  }, [notify, updateData]);

  return <AdminContext.Provider value={{
    data, hydrated, saving, collectionState, retryCollections: () => {
      if (mutation.current) { notify("Yenilemeden önce kaydetme işlemini bekleyin.", "info"); return; }
      setRetry((value) => value + 1);
    }, query, setQuery,
    sidebarOpen, setSidebarOpen, dialog, closeDialog: () => setDialog(null),
    openDialog: (kind, id) => setDialog({ kind, id }), confirm: (title, onConfirm) => setDialog({ kind: "confirm", title, onConfirm }),
    updateData, restoreData, notify, toasts, dismissToast,
  }}>{children}</AdminContext.Provider>;
}

export function useAdmin() {
  const context = useContext(AdminContext);
  if (!context) throw new Error("useAdmin, AdminProvider içinde kullanılmalıdır.");
  return context;
}
