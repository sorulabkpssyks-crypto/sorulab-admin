import type { AdminData } from "./mockData";

type Rule = (value: unknown) => boolean;
const string: Rule = (v) => typeof v === "string";
const number: Rule = (v) => typeof v === "number" && Number.isFinite(v);
const bool: Rule = (v) => typeof v === "boolean";
const record = (v: unknown): v is Record<string, unknown> => typeof v === "object" && v !== null && !Array.isArray(v);
const oneOf = (...values: unknown[]): Rule => (v) => values.includes(v);
const arrayOf = (rule: Rule): Rule => (v) => Array.isArray(v) && v.every(rule);
const shape = (rules: Record<string, Rule>): Rule => (v) => record(v) && Object.entries(rules).every(([key, rule]) => rule(v[key]));
const status = oneOf("Onaylandı", "Onay Bekliyor", "Reddedildi");
const validDate: Rule = (v) => typeof v === "string" && Number.isFinite(Date.parse(v));
const nonnegative: Rule = (v) => number(v) && (v as number) >= 0;
const recordId: Rule = (v) => (typeof v === "string" && v.length > 0) || number(v);
const optionalDate: Rule = (v) => v === "" || validDate(v);
const schema: Record<keyof AdminData, Rule> = {
  questions: arrayOf(shape({ id: recordId, text: string, category: string, difficulty: oneOf("Kolay", "Orta", "Zor"), date: optionalDate, options: arrayOf(string), answer: number, explanation: string })),
  forums: arrayOf(shape({ id: recordId, user: string, avatar: string, color: string, topic: string, content: string, date: optionalDate, status })),
  categories: arrayOf(shape({ id: recordId, name: string, count: nonnegative })),
  plans: arrayOf(shape({ id: number, name: string, price: nonnegative, months: (v) => v === null || nonnegative(v) })),
  filters: arrayOf(shape({ id: string, name: string, description: string, enabled: bool })),
  admob: shape({ appId: string, bannerId: string, interstitialId: string, rewardedId: string }),
  users: arrayOf(shape({ id: recordId, name: string, email: string, role: oneOf("Kullanıcı", "Moderatör", "Admin"), premium: bool, active: bool, joined: optionalDate })),
  hints: arrayOf(shape({ id: number, title: string, category: string, content: string })),
  ads: arrayOf(shape({ id: number, title: string, placement: string, url: string, active: bool })),
  comments: arrayOf(shape({ id: number, user: string, postId: recordId, text: string, status })),
  reports: arrayOf(shape({ id: number, user: string, postId: recordId, reason: string, resolved: bool })),
  notifications: arrayOf(shape({ id: number, title: string, message: string, date: validDate, read: bool, audience: string })),
  profanity: arrayOf(string),
  logs: arrayOf(shape({ id: number, action: string, date: validDate, type: oneOf("Bilgi", "Uyarı") })),
  settings: shape({ name: string, email: string, maintenance: bool, registration: bool, forumEnabled: bool, maxPostLength: nonnegative, dailyPostLimit: nonnegative }),
};

export function validateBackup(value: unknown): AdminData {
  const candidate = record(value) && "data" in value ? value.data : value;
  if (!record(candidate) || !Object.entries(schema).every(([key, rule]) => rule(candidate[key]))) {
    throw new Error("Geçersiz yedek dosyası. SınavApp üzerinden oluşturulmuş bir JSON yedeği seçin.");
  }
  return candidate as unknown as AdminData;
}

export function downloadJson(data: unknown, filename: string) {
  const url = URL.createObjectURL(new Blob([JSON.stringify(data, null, 2)], { type: "application/json;charset=utf-8" }));
  const anchor = document.createElement("a");
  anchor.href = url;
  anchor.download = filename;
  anchor.click();
  setTimeout(() => URL.revokeObjectURL(url), 1000);
}
