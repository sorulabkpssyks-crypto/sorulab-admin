export type Difficulty = "Kolay" | "Orta" | "Zor";
export type ForumStatus = "Onaylandı" | "Onay Bekliyor" | "Reddedildi";
export type RecordId = string | number;
export interface Question { id: RecordId; text: string; category: string; difficulty: Difficulty; date: string; options: string[]; answer: number; explanation: string }
export interface ForumPost { id: RecordId; user: string; avatar: string; color: string; topic: string; content: string; date: string; status: ForumStatus }
export interface Category { id: RecordId; name: string; count: number }
export interface Plan { id: number; name: string; price: number; months: number | null }
export interface FilterSetting { id: string; name: string; description: string; enabled: boolean }
export interface AdmobSettings { appId: string; bannerId: string; interstitialId: string; rewardedId: string }
export interface User { id: RecordId; name: string; email: string; role: "Kullanıcı" | "Moderatör" | "Admin"; premium: boolean; active: boolean; joined: string }
export interface Hint { id: number; title: string; category: string; content: string }
export interface Advertisement { id: number; title: string; placement: string; url: string; active: boolean }
export interface Comment { id: number; user: string; postId: RecordId; text: string; status: ForumStatus }
export interface Report { id: number; user: string; postId: RecordId; reason: string; resolved: boolean }
export interface Notification { id: number; title: string; message: string; date: string; read: boolean; audience: string }
export interface Log { id: number; action: string; date: string; type: "Bilgi" | "Uyarı" }
export interface AppSettings { name: string; email: string; maintenance: boolean; registration: boolean; forumEnabled: boolean; maxPostLength: number; dailyPostLimit: number }
export interface AdminData {
  questions: Question[]; forums: ForumPost[]; categories: Category[]; plans: Plan[];
  filters: FilterSetting[]; admob: AdmobSettings; users: User[]; hints: Hint[];
  ads: Advertisement[]; comments: Comment[]; reports: Report[];
  notifications: Notification[]; profanity: string[]; logs: Log[]; settings: AppSettings;
}

export const stats = [
  { id: "users", label: "Toplam Kullanıcı", value: 12548, growth: 12, color: "blue" },
  { id: "questions", label: "Toplam Soru", value: 8240, growth: 5, color: "green" },
  { id: "forums", label: "Forum Gönderisi", value: 1243, growth: 18, color: "purple" },
  { id: "subscribers", label: "Aktif Abone", value: 3621, growth: 27, color: "orange" },
];
export const chartData = [
  { date: "3 May", active: 1000, solved: 560, subscribers: 200 },
  { date: "4 May", active: 1050, solved: 640, subscribers: 280 },
  { date: "5 May", active: 1340, solved: 860, subscribers: 430 },
  { date: "6 May", active: 1280, solved: 710, subscribers: 360 },
  { date: "7 May", active: 1650, solved: 1060, subscribers: 570 },
  { date: "8 May", active: 1580, solved: 1000, subscribers: 510 },
  { date: "9 May", active: 1840, solved: 1270, subscribers: 650 },
];
export const questions: Question[] = [
  { id: 8451, text: "Türkiye’nin en uzun nehri hangisidir?", category: "Coğrafya", difficulty: "Orta", date: "2025-05-09", options: ["Fırat", "Kızılırmak", "Sakarya", "Dicle"], answer: 1, explanation: "Türkiye sınırları içinde doğup denize dökülen en uzun nehir 1.355 km ile Kızılırmak’tır." },
  { id: 8450, text: "Osmanlı Devleti’nde ilk medreseyi hangi padişah kurmuştur?", category: "Tarih", difficulty: "Kolay", date: "2025-05-09", options: ["Osman Bey", "Orhan Bey", "I. Murad", "Yıldırım Bayezid"], answer: 1, explanation: "İlk Osmanlı medresesi Orhan Bey tarafından 1331 yılında İznik’te kurulmuştur." },
  { id: 8449, text: "Fotosentez olayı hangi organelde gerçekleşir?", category: "Biyoloji", difficulty: "Orta", date: "2025-05-08", options: ["Mitokondri", "Ribozom", "Kloroplast", "Golgi aygıtı"], answer: 2, explanation: "Fotosentez, klorofil pigmenti içeren kloroplastlarda gerçekleşir." },
  { id: 8448, text: "2x + 5 = 15 denkleminin çözümü nedir?", category: "Matematik", difficulty: "Kolay", date: "2025-05-08", options: ["3", "5", "7", "10"], answer: 1, explanation: "Her iki taraftan 5 çıkarılır: 2x = 10. İkiye bölünür: x = 5." },
  { id: 8447, text: "Aşağıdakilerden hangisi bir asit özelliğidir?", category: "Kimya", difficulty: "Zor", date: "2025-05-08", options: ["Kırmızı turnusolü maviye çevirir", "pH değeri 7’den büyüktür", "Mavi turnusolü kırmızıya çevirir", "Suda OH⁻ iyonu verir"], answer: 2, explanation: "Asitler mavi turnusol kâğıdını kırmızıya çevirir ve pH değerleri 7’den küçüktür." },
];
export const forumPosts: ForumPost[] = [
  { id: 1, user: "AhmetK", avatar: "A", color: "#ca44d5", topic: "YKS matematik için kaynak önerisi", content: "YKS’ye hazırlanıyorum. Matematik için orta seviyede, çözümleri anlaşılır bir kaynak önerebilir misiniz?", date: "2025-05-09T12:14:00", status: "Onaylandı" },
  { id: 2, user: "zeynepp", avatar: "Z", color: "#aa45ce", topic: "Tyt denemeleri nasıl gidiyor?", content: "Son TYT denememde 75 net yaptım. Siz denemeleri hangi sıklıkla çözüyorsunuz?", date: "2025-05-09T11:48:00", status: "Onaylandı" },
  { id: 3, user: "mersinli33", avatar: "M", color: "#234b79", topic: "Biyoloji zor mu sizce?", content: "Biyolojide sistemler konusunu tekrar ediyorum. Konuları akılda tutmak için önerilerinizi bekliyorum.", date: "2025-05-09T10:22:00", status: "Onay Bekliyor" },
  { id: 4, user: "emirhan07", avatar: "E", color: "#254b79", topic: "Bu soru hatalı mı?", content: "8451 numaralı soruda Türkiye sınırları içindeki en uzun nehir soruluyor. Açıklamanın bu ayrımı belirtmesi iyi olur.", date: "2025-05-09T09:51:00", status: "Onaylandı" },
  { id: 5, user: "selinac", avatar: "S", color: "#c509e8", topic: "Tavsiyeleriniz neler?", content: "Gönderi, izinsiz reklam bağlantısı içerdiği için moderasyon tarafından reddedildi.", date: "2025-05-09T09:12:00", status: "Reddedildi" },
];
export const categories: Category[] = [
  { id: 1, name: "Matematik", count: 1245 }, { id: 2, name: "Türkçe", count: 980 },
  { id: 3, name: "Tarih", count: 860 }, { id: 4, name: "Coğrafya", count: 720 },
  { id: 5, name: "Biyoloji", count: 690 },
];
export const subscriptionPlans: Plan[] = [
  { id: 1, name: "Aylık Premium", price: 49.99, months: 1 },
  { id: 2, name: "3 Aylık Premium", price: 129.99, months: 3 },
  { id: 3, name: "Yıllık Premium", price: 299.99, months: 12 },
  { id: 4, name: "Sınırsız Paket", price: 399.99, months: null },
];
export const forumFilters: FilterSetting[] = [
  { id: "profanity", name: "Küfür Filtresi", description: "Uygunsuz kelimeleri otomatik filtrele", enabled: true },
  { id: "links", name: "Link Engelleme", description: "Forumda dış linkleri engelle", enabled: true },
  { id: "censor", name: "Otomatik Sansür", description: "Tespit edilen kelimeleri yıldızla (***)", enabled: true },
  { id: "reporting", name: "Raporlama Sistemi", description: "Kullanıcı raporlarını aktif et", enabled: true },
];
export const admobSettings: AdmobSettings = {
  appId: "ca-app-pub-3940256099942544~3347511713",
  bannerId: "ca-app-pub-3940256099942544/6300978111",
  interstitialId: "ca-app-pub-3940256099942544/1033173712",
  rewardedId: "ca-app-pub-3940256099942544/5224354917",
};
export const initialData: AdminData = {
  questions, forums: forumPosts, categories, plans: subscriptionPlans, filters: forumFilters, admob: admobSettings,
  users: [
    { id: 1, name: "Ahmet Kaya", email: "ahmet.kaya@example.com", role: "Kullanıcı", premium: true, active: true, joined: "2025-04-12" },
    { id: 2, name: "Zeynep Yılmaz", email: "zeynep@example.com", role: "Kullanıcı", premium: true, active: true, joined: "2025-04-18" },
    { id: 3, name: "Mert Demir", email: "mert@example.com", role: "Moderatör", premium: false, active: true, joined: "2025-03-08" },
    { id: 4, name: "Emirhan Aydın", email: "emirhan@example.com", role: "Kullanıcı", premium: false, active: true, joined: "2025-05-01" },
    { id: 5, name: "Selin Acar", email: "selin@example.com", role: "Kullanıcı", premium: false, active: false, joined: "2025-05-02" },
  ],
  hints: [
    { id: 1, title: "Denklem çözerken", category: "Matematik", content: "Eşitliğin iki tarafına aynı işlemi uygulayın ve sonucu yerine koyarak kontrol edin." },
    { id: 2, title: "Paragraf soruları", category: "Türkçe", content: "Önce soru kökünü okuyun. Ana düşünceyi bulurken metnin bütününü değerlendirin." },
    { id: 3, title: "Tarih çalışırken", category: "Tarih", content: "Olayları bir zaman çizelgesine yerleştirerek neden ve sonuç ilişkilerini kurun." },
  ],
  ads: [{ id: 1, title: "YKS Hazırlık Paketi", placement: "Ana sayfa", url: "https://example.com/yks", active: true }],
  comments: [
    { id: 1, user: "zeynepp", postId: 1, text: "Konu anlatımını bitirip ardından branş denemelerine geçmeni öneririm.", status: "Onaylandı" },
    { id: 2, user: "AhmetK", postId: 2, text: "Haftada iki deneme çözüyorum, yanlışlarımı ayrıca tekrar ediyorum.", status: "Onay Bekliyor" },
  ],
  reports: [{ id: 1, user: "emirhan07", postId: 5, reason: "İzinsiz reklam ve dış bağlantı", resolved: false }],
  notifications: [
    { id: 3, title: "Yeni kullanıcı raporu", message: "Forumda bir gönderi incelemenizi bekliyor.", date: "2025-05-09T12:20:00", read: false, audience: "Yöneticiler" },
    { id: 2, title: "Abonelik güncellemesi", message: "Bugün 27 yeni kullanıcı Premium’a geçti.", date: "2025-05-09T11:00:00", read: false, audience: "Yöneticiler" },
    { id: 1, title: "Yedekleme tamamlandı", message: "Günlük veriler başarıyla yedeklendi.", date: "2025-05-09T08:00:00", read: false, audience: "Yöneticiler" },
  ],
  profanity: ["aptal", "salak"],
  logs: [{ id: 1, action: "Yönetici paneli başlatıldı", date: "2025-05-09T08:00:00", type: "Bilgi" }],
  settings: { name: "SınavApp", email: "destek@sinavapp.com", maintenance: false, registration: true, forumEnabled: true, maxPostLength: 2000, dailyPostLimit: 10 },
};

export const formatNumber = (value: number) => new Intl.NumberFormat("tr-TR").format(value);
export const formatPrice = (value: number) => new Intl.NumberFormat("tr-TR", { style: "currency", currency: "TRY" }).format(value);
export const formatDate = (value: string, time = false) => !value || !Number.isFinite(Date.parse(value)) ? "—" : new Intl.DateTimeFormat("tr-TR", {
  day: "numeric", month: "short", year: "numeric", ...(time ? { hour: "2-digit", minute: "2-digit" } as const : {}),
}).format(new Date(value));
