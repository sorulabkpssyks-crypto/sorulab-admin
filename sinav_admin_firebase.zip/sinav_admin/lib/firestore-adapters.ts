import type { Category, Difficulty, ForumPost, ForumStatus, Question, User } from "./mockData";

export type RawDocument = Record<string, unknown>;

export const own = (value: object, key: string) => Object.prototype.hasOwnProperty.call(value, key);
export const object = (value: unknown): RawDocument => value && typeof value === "object" && !Array.isArray(value) ? value as RawDocument : {};
export const string = (value: unknown, fallback = "") => typeof value === "string" ? value : typeof value === "number" ? String(value) : fallback;
const number = (value: unknown, fallback = 0) => {
  const parsed = typeof value === "number" ? value : Number(value);
  return Number.isFinite(parsed) && value !== null && value !== "" ? parsed : fallback;
};
export function at(raw: RawDocument, path: string): unknown {
  return path.split(".").reduce<unknown>((value, key) => object(value)[key], raw);
}
export function first(raw: RawDocument, paths: string[]): unknown {
  for (const path of paths) {
    const value = at(raw, path);
    if (value !== undefined && value !== null) return value;
  }
  return undefined;
}
export function field(raw: RawDocument, aliases: string[], fallback: string): string {
  return aliases.find((path) => at(raw, path) !== undefined) ?? fallback;
}
function bool(value: unknown, fallback: boolean): boolean {
  if (typeof value === "boolean") return value;
  if (typeof value === "number") return value !== 0;
  if (typeof value === "string") {
    const lowered = value.toLocaleLowerCase("en-US");
    if (["true", "active", "enabled", "premium", "paid", "trialing", "subscribed", "1"].includes(lowered)) return true;
    if (["false", "inactive", "disabled", "blocked", "banned", "suspended", "deleted", "expired", "cancelled", "canceled", "free", "0"].includes(lowered)) return false;
  }
  return fallback;
}

/** Accepts native Firestore Timestamp, REST timestamp objects, milliseconds and ISO strings. */
export function normalizeDate(value: unknown): string {
  if (value === undefined || value === null || value === "") return "";
  let date: Date;
  if (value instanceof Date) date = value;
  else if (typeof object(value).toDate === "function") {
    try { date = (value as { toDate(): Date }).toDate(); } catch { return ""; }
  } else {
    const timestamp = object(value);
    const seconds = timestamp.seconds ?? timestamp._seconds;
    if (typeof seconds === "number") date = new Date(seconds * 1000);
    else if (typeof value === "string" || typeof value === "number") date = new Date(value);
    else return "";
  }
  return Number.isFinite(date.getTime()) ? date.toISOString() : "";
}

export const questionFields = {
  text: ["text", "question", "questionText", "content", "title"],
  category: ["category", "categoryName", "categoryId"],
  difficulty: ["difficulty", "level"],
  date: ["date", "createdAt", "created_at", "timestamp"],
  options: ["options", "choices", "answers"],
  answer: ["answer", "correctAnswer", "correctOption", "answerIndex", "correctAnswerIndex"],
  explanation: ["explanation", "solution", "answerExplanation"],
};
export const optionFields = ["text", "value", "content", "title", "option", "label"];
export function optionValues(value: unknown): unknown[] {
  return Array.isArray(value) ? value : Object.values(object(value));
}
function optionText(value: unknown): string {
  return typeof value === "object" ? string(first(object(value), optionFields)) : string(value);
}
function normalizeDifficulty(value: unknown): Difficulty {
  const lowered = string(value).toLocaleLowerCase("tr-TR");
  if (["easy", "kolay", "beginner", "1"].includes(lowered)) return "Kolay";
  if (["hard", "zor", "difficult", "3"].includes(lowered)) return "Zor";
  return "Orta";
}
function normalizeAnswer(value: unknown, options: string[], originalOptions: unknown[]): number {
  if (typeof value === "number" && Number.isInteger(value) && value >= 0 && value < options.length) return value;
  if (typeof value === "string") {
    const trimmed = value.trim();
    const letter = /^[A-Z]$/i.test(trimmed) ? trimmed.toUpperCase().charCodeAt(0) - 65 : -1;
    if (letter >= 0 && letter < options.length) return letter;
    const match = options.findIndex((option) => option === trimmed);
    if (match >= 0) return match;
    const numeric = Number(trimmed);
    if (trimmed !== "" && Number.isInteger(numeric) && numeric >= 0 && numeric < options.length) return numeric;
  }
  const flagged = originalOptions.findIndex((option) => bool(first(object(option), ["isCorrect", "correct"]), false));
  return flagged;
}

export function normalizeQuestion(id: string, raw: RawDocument, categoryNames: ReadonlyMap<string, string> = new Map()): Question {
  const originals = optionValues(first(raw, questionFields.options));
  const options = originals.map(optionText);
  const category = first(raw, questionFields.category);
  const categoryValue = typeof category === "object" ? string(first(object(category), ["name", "title", "id"])) : string(category);
  return {
    id, text: string(first(raw, questionFields.text)), category: categoryNames.get(categoryValue) ?? categoryValue,
    difficulty: normalizeDifficulty(first(raw, questionFields.difficulty)), date: normalizeDate(first(raw, questionFields.date)),
    options, answer: normalizeAnswer(first(raw, questionFields.answer), options, originals),
    explanation: string(first(raw, questionFields.explanation)),
  };
}

export const forumFields = {
  user: ["user", "username", "authorName", "userName", "displayName", "author.displayName", "author.name"],
  avatar: ["avatar", "avatarLetter"], color: ["color", "avatarColor"],
  topic: ["topic", "title", "subject"], content: ["content", "body", "text"],
  date: ["date", "createdAt", "created_at", "timestamp"], status: ["status", "approvalStatus", "moderationStatus"],
};
function normalizeStatus(value: unknown): ForumStatus {
  const lowered = string(value).toLocaleLowerCase("tr-TR");
  if (["approved", "accepted", "published", "onaylandı", "onaylandi"].includes(lowered)) return "Onaylandı";
  if (["rejected", "removed", "blocked", "reddedildi"].includes(lowered)) return "Reddedildi";
  return "Onay Bekliyor";
}
export function normalizeForumPost(id: string, raw: RawDocument): ForumPost {
  const author = first(raw, forumFields.user);
  const user = typeof author === "object" ? string(first(object(author), ["displayName", "name", "username"])) : string(author);
  return {
    id, user, avatar: string(first(raw, forumFields.avatar), user.charAt(0).toLocaleUpperCase("tr-TR") || "?"),
    color: string(first(raw, forumFields.color), "#315a90"), topic: string(first(raw, forumFields.topic)),
    content: string(first(raw, forumFields.content)), date: normalizeDate(first(raw, forumFields.date)),
    status: normalizeStatus(first(raw, forumFields.status)),
  };
}

export const categoryFields = { name: ["name", "title", "categoryName"], count: ["questionCount", "count", "questionsCount", "totalQuestions"] };
export function normalizeCategory(id: string, raw: RawDocument, derivedCount = 0): Category {
  return { id, name: string(first(raw, categoryFields.name)), count: Math.max(0, number(first(raw, categoryFields.count), derivedCount)) };
}

export const userFields = {
  name: ["name", "displayName", "fullName", "username"], email: ["email", "emailAddress"],
  role: ["role", "userRole"],
  premium: ["premium", "isPremium", "hasPremium", "subscriptionActive", "isSubscriber", "subscription.active", "subscription.isActive", "subscription.status", "subscription"],
  active: ["active", "isActive", "status", "disabled"], joined: ["joined", "createdAt", "registeredAt", "created_at"],
};
function normalizeRole(value: unknown): User["role"] {
  const lowered = string(value).toLocaleLowerCase("tr-TR");
  if (["admin", "administrator", "yönetici", "sistem yöneticisi"].includes(lowered)) return "Admin";
  if (["moderator", "moderatör", "mod"].includes(lowered)) return "Moderatör";
  return "Kullanıcı";
}
export function normalizeUser(id: string, raw: RawDocument): User {
  const activePath = field(raw, userFields.active, "active");
  const premiumValue = first(raw, userFields.premium);
  const premium = premiumValue && typeof premiumValue === "object"
    ? bool(first(object(premiumValue), ["active", "isActive", "isPremium", "status"]), false)
    : bool(premiumValue, false);
  return {
    id, name: string(first(raw, userFields.name)), email: string(first(raw, userFields.email)),
    role: normalizeRole(first(raw, userFields.role)), premium,
    active: activePath === "disabled" ? !bool(raw.disabled, false) : bool(at(raw, activePath), true),
    joined: normalizeDate(first(raw, userFields.joined)),
  };
}

