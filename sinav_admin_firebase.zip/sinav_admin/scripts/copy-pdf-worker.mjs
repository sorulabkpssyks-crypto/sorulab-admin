import { copyFileSync, mkdirSync } from "node:fs";
import { fileURLToPath } from "node:url";

const projectDir = fileURLToPath(new URL("../", import.meta.url));
mkdirSync(`${projectDir}/public`, { recursive: true });
copyFileSync(`${projectDir}/node_modules/pdfjs-dist/build/pdf.worker.min.mjs`, `${projectDir}/public/pdf.worker.min.mjs`);
console.log("PDF.js worker hazır.");
