# SınavApp Admin Paneli — Firebase

Next.js App Router, TypeScript, Tailwind CSS, Lucide React, Recharts, Firebase SDK ve PDF.js ile hazırlanmış yönetim paneli.

## Çalıştırma

Node.js 20.19+ gerekir. Dahili servis testleri için Node.js 24 önerilir.

```bash
cd sinav_admin
npm install
npm run dev
```

Adres: http://localhost:3000

```bash
npm run typecheck
npm run build
npm start
```

Kurulumun postinstall adımı PDF.js worker dosyasını public/ dizinine kopyalar. Kurulum betikleri kapalıysa `node scripts/copy-pdf-worker.mjs` çalıştırın.

## Canlı bağlantılar

Son gönderilen Firebase Console konfigürasyonu lib/firebase.ts ve .env.local içine işlendi. Uygulama getApps() ile bir kez başlatılır; db, auth ve storage dışa aktarılır. measurementId korunur; Analytics sunucuda başlatılmaz.

| Panel verisi | Firestore koleksiyonu | İşlem |
| --- | --- | --- |
| Kullanıcılar | users | Anlık okuma, profil ekleme/düzenleme |
| Sorular | questions | Anlık okuma, ekleme/düzenleme/silme, PDF aktarımı |
| Forum gönderileri | forum_posts | Anlık okuma, moderasyon, silme |
| Kategoriler | categories | Anlık okuma, ekleme/yeniden adlandırma/silme |

Dört koleksiyona onSnapshot ile abone olunur. Oturum kapandığında dinleyiciler ve paneldeki canlı veriler temizlenir. Bu koleksiyonlarda mock veriye veya localStorage kayıtlarına geri dönüş yapılmaz. Yükleme, boş koleksiyon ve erişim hataları ayrı gösterilir.

Belge kimlikleri Firestore kimlikleri olarak korunur. Yeni belgeler UUID kullanır. Soru işlemleri ve kategori sayacı aynı atomik batch içinde yazılır; mevcut sayaca increment farkı uygulanır. Düzenleme yalnızca değişen alanları günceller, diğer uygulama alanlarını ve oluşturulma tarihlerini korur. İşlem mesajı ancak sunucu yazmayı onayladıktan sonra gösterilir.

## Authentication

Panel Firebase Auth oturumu gerektirir. E-posta/parola girişi, beni hatırla, oturum kapatma ve parola sıfırlama vardır. Profilde görünen ad Firebase Auth hesabında güncellenir.

Firebase Console → Authentication → Sign-in method bölümünde Email/Password etkin olmalıdır. Mevcut Firebase Auth hesabınızla giriş yapın. Yayın adresini Authorized domains bölümüne ekleyin. Firestore kuralları giriş yaptığınız hesabın ilgili dört koleksiyona erişimine izin vermelidir; oturum açmak tek başına Firestore yetkisi vermez. Mevcut güvenlik kuralları bu çalışma sırasında değiştirilmedi.

users koleksiyonundaki bir profili eklemek veya pasifleştirmek Firebase Auth giriş hesabını oluşturmaz/devre dışı bırakmaz. Diğer kullanıcıların Auth hesaplarını yönetmek için güvenilir sunucuda Firebase Admin SDK gerekir.

## Belge şeması

Yeni belgeler aşağıdaki alanlarla yazılır:

- users: name, email, role, premium, active, createdAt, updatedAt.
- questions: text, category, difficulty, options, answer (sıfır tabanlı indeks), explanation, createdAt, updatedAt.
- forum_posts: user, avatar, color, topic, content, status, createdAt, updatedAt.
- categories: name, questionCount, createdAt, updatedAt.

Mevcut belgelerde question/questionText, categoryName/categoryId, choices, correctAnswer, displayName, isPremium, authorName, title/body ve benzer yaygın alan adları desteklenir. Firestore Timestamp, ISO tarih, İngilizce/Türkçe durumlar ve nesne biçimindeki seçenekler okunabilir. Uyarlama kodu lib/firestore-adapters.ts, yazma eşleştirmesi lib/firestore-service.ts içindedir.

## Diğer panel verileri

Abonelik fiyatları, AdMob kimlikleri, reklam alanları, ipuçları, yorum/rapor kayıtları, filtreler, bildirimler, uygulama ayarları ve günlükler bu isteğin dört canlı koleksiyon bağlantısı dışındadır; hesap bazında bu tarayıcıda saklanır. Grafik 3–9 Mayıs 2025 tasarım örneğini gösterir. Özet kartlar gerçek koleksiyon ve Premium kullanıcı sayılarını gösterir.

JSON yedeği canlı kayıtları ve yerel ayarları dışa aktarır. JSON geri yükleme yalnızca yerel ayar ve kayıtları değiştirir; dört canlı Firestore koleksiyonunu değiştirmez. Boş koleksiyonlara örnek veri eklenmez.

## Doğrulama

```bash
npm test
```

Node.js 24 üzerinde 14 test geçti: belge şeması dönüşümleri, koleksiyon yolları, alanların korunması, atomik soru/sayaç yazma, silme, moderasyon, başarısız commit ve geçersiz kimlikler. Testlerde Firebase SDK sınırı test fixture ile değiştirilir; gerçek servis kodu çalıştırılır. Testler canlı projeye belge yazmaz.

Bağımlılık kurulumu çalışma ortamında ağ erişimi EPERM hatasıyla engellendi. Bu ortamda Next.js derlemesi ve gerçek hesapla oturum/Firestore erişimi doğrulanamadı.

```bash
npx playwright install chromium
npm run test:e2e
```

Tarayıcı kontrolleri oturum açılmadan panelin gizlenmesini ve giriş formunu kontrol eder; canlı veritabanına yazmaz.
