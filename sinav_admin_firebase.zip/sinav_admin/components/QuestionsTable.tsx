"use client";

import { useEffect, useMemo, useState } from "react";
import Link from "next/link";
import { ChevronLeft, ChevronRight, Pencil, Plus, Search, Trash2 } from "lucide-react";
import { useAdmin } from "@/lib/admin-context";
import { formatDate, type Difficulty, type Question } from "@/lib/mockData";

const PAGE_SIZE = 10;
const difficultyClass: Record<Difficulty, string> = {
  Kolay: "badge-green", Orta: "badge-amber", Zor: "badge-red",
};

export default function QuestionsTable({ full = false }: { full?: boolean }) {
  const { data, query, updateData, openDialog, confirm, notify, saving, collectionState, retryCollections } = useAdmin();
  const state = collectionState.questions;
  const writeBlocked = saving || state.loading || Boolean(state.error) || collectionState.categories.loading || Boolean(collectionState.categories.error);
  const [category, setCategory] = useState("");
  const [difficulty, setDifficulty] = useState("");
  const [search, setSearch] = useState("");
  const [page, setPage] = useState(1);
  const categoryNames = useMemo(() => Array.from(new Set([
    ...data.categories.map((item) => item.name), ...data.questions.map((item) => item.category),
  ])), [data.categories, data.questions]);

  const filtered = useMemo(() => {
    const terms = [query, full ? search : ""].map((term) => term.trim().toLocaleLowerCase("tr-TR")).filter(Boolean);
    return data.questions.filter((question) => {
      const text = `${question.id} ${question.text} ${question.category} ${question.difficulty}`.toLocaleLowerCase("tr-TR");
      return terms.every((term) => text.includes(term)) && (!full || (
        (!category || question.category === category) && (!difficulty || question.difficulty === difficulty)
      ));
    }).sort((a, b) => b.date.localeCompare(a.date) || String(b.id).localeCompare(String(a.id), "tr", { numeric: true }));
  }, [data.questions, query, search, category, difficulty, full]);

  useEffect(() => { setPage(1); }, [query, search, category, difficulty]);
  const pageCount = Math.max(1, Math.ceil(filtered.length / PAGE_SIZE));
  const currentPage = Math.min(page, pageCount);
  const rows = full ? filtered.slice((currentPage - 1) * PAGE_SIZE, currentPage * PAGE_SIZE) : filtered.slice(0, 5);

  const deleteQuestion = (question: Question) => confirm(
    `#${question.id} numaralı soru silinsin mi?`,
    async () => {
      const saved = await updateData((current) => ({
      ...current,
      questions: current.questions.filter((item) => item.id !== question.id),
      categories: current.categories.map((item) => item.name === question.category
        ? { ...item, count: Math.max(0, item.count - 1) } : item),
      }), `#${question.id} numaralı soru silindi.`);
      if (saved) notify("Soru silindi.");
      return saved;
    },
  );

  const resetFilters = () => { setSearch(""); setCategory(""); setDifficulty(""); };

  return (
    <section className={`panel question-table${full ? " full-table" : ""}`} aria-labelledby="questions-heading">
      <div className="panel-heading">
        <h2 id="questions-heading">{full ? "Soru Yönetimi" : "Son Eklenen Sorular"}</h2>
        {full ? (
          <button className="btn btn-primary" disabled={writeBlocked} onClick={() => openDialog("question")}><Plus size={16} /> Soru Ekle</button>
        ) : <Link href="/sorular" className="btn btn-small">Tümünü Gör</Link>}
      </div>
      {full && (
        <div className="filter-bar">
          <label className="field table-search"><span>Soru ara</span><div className="search-field"><Search size={16} /><input value={search} onChange={(event) => setSearch(event.target.value)} placeholder="Soru metni veya ID ile ara" /></div></label>
          <label className="field"><span>Kategori</span><select value={category} onChange={(event) => setCategory(event.target.value)}><option value="">Tüm kategoriler</option>{categoryNames.map((name) => <option key={name} value={name}>{name}</option>)}</select></label>
          <label className="field"><span>Zorluk</span><select value={difficulty} onChange={(event) => setDifficulty(event.target.value)}><option value="">Tüm seviyeler</option>{(["Kolay", "Orta", "Zor"] as const).map((name) => <option key={name} value={name}>{name}</option>)}</select></label>
          {(search || category || difficulty) && <button className="btn btn-small" onClick={resetFilters}>Filtreleri Temizle</button>}
        </div>
      )}
      <div className="table-scroll">
        <table className="data-table" aria-label={full ? "Sorular" : "Son eklenen sorular"}>
          <colgroup><col style={{ width: "8%" }} /><col style={{ width: "38%" }} /><col style={{ width: "13%" }} /><col style={{ width: "11%" }} /><col style={{ width: "16%" }} /><col style={{ width: "14%" }} /></colgroup>
          <thead><tr><th scope="col">{full ? "ID" : "#"}</th><th scope="col">Soru</th><th scope="col">Kategori</th><th scope="col">Zorluk</th><th scope="col">Tarih</th><th scope="col">İşlem</th></tr></thead>
          <tbody>{rows.map((question) => (
            <tr key={question.id}>
              <td><span className="text-ellipsis" title={String(question.id)}>{String(question.id).length > 9 ? `${String(question.id).slice(0, 7)}…` : question.id}</span></td>
              <td><span className="text-ellipsis" title={question.text}>{question.text}</span></td>
              <td>{question.category}</td>
              <td><span className={`badge ${difficultyClass[question.difficulty]}`}>{question.difficulty}</span></td>
              <td className="table-date">{formatDate(question.date)}</td>
              <td><div className="table-actions"><button className="icon-button" disabled={writeBlocked} onClick={() => openDialog("question", question.id)} aria-label={`#${question.id} numaralı soruyu düzenle`} title="Düzenle"><Pencil size={14} /></button><button className="icon-button danger" disabled={writeBlocked} onClick={() => deleteQuestion(question)} aria-label={`#${question.id} numaralı soruyu sil`} title="Sil"><Trash2 size={14} /></button></div></td>
            </tr>
          ))}</tbody>
        </table>
      </div>
      {(state.loading || state.error || rows.length === 0) && <div className="table-empty" role={state.error ? "alert" : "status"}><Search size={24} /><p>{state.loading ? "Sorular Firestore’dan yükleniyor…" : state.error ?? (query || search || category || difficulty ? "Aramanıza uygun soru bulunamadı." : "Henüz soru eklenmedi.")}</p>{state.error ? <button className="btn btn-small" onClick={retryCollections}>Yeniden Dene</button> : !state.loading && (full && (search || category || difficulty) ? <button className="btn btn-small" onClick={resetFilters}>Filtreleri Temizle</button> : !query && <button className="btn btn-small" disabled={writeBlocked} onClick={() => openDialog("question")}>İlk Soruyu Ekle</button>)}</div>}
      {full && <div className="pagination"><span className="pagination-info">{filtered.length === 0 ? "0 soru" : `${(currentPage - 1) * PAGE_SIZE + 1}–${Math.min(currentPage * PAGE_SIZE, filtered.length)} / ${filtered.length} soru`}</span><div className="table-actions"><button className="icon-button" disabled={currentPage === 1} onClick={() => setPage(currentPage - 1)} aria-label="Önceki sayfa"><ChevronLeft size={17} /></button><span>{currentPage} / {pageCount}</span><button className="icon-button" disabled={currentPage === pageCount} onClick={() => setPage(currentPage + 1)} aria-label="Sonraki sayfa"><ChevronRight size={17} /></button></div></div>}
    </section>
  );
}
