"use client";

import { useRef, useState } from "react";
import type { FormEvent, ReactNode } from "react";
import { Eye, EyeOff, GraduationCap, LoaderCircle, LockKeyhole, LogIn, Mail } from "lucide-react";
import { useAuth } from "@/lib/auth-context";

export default function AuthGate({ children }: { children: ReactNode }) {
  const { user, loading, error, signIn, resetPassword } = useAuth();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [remember, setRemember] = useState(true);
  const [showPassword, setShowPassword] = useState(false);
  const [pending, setPending] = useState<"sign-in" | "reset" | null>(null);
  const [formError, setFormError] = useState<string | null>(null);
  const [status, setStatus] = useState<string | null>(null);
  const emailRef = useRef<HTMLInputElement>(null);

  if (loading) {
    return (
      <main className="flex min-h-screen items-center justify-center bg-[#f0f3f9] px-6" aria-busy="true">
        <div role="status" className="flex flex-col items-center gap-4 text-[#526078]">
          <GraduationCap size={48} className="text-[#087bff]" aria-hidden="true" />
          <span className="flex items-center gap-2"><LoaderCircle size={18} className="animate-spin text-[#087bff]" aria-hidden="true" />Oturum kontrol ediliyor…</span>
        </div>
      </main>
    );
  }

  if (user) return <>{children}</>;

  async function handleSignIn(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setPending("sign-in");
    setFormError(null);
    setStatus(null);
    try {
      await signIn(email, password, remember);
    } catch (cause) {
      setFormError(cause instanceof Error ? cause.message : "Giriş yapılamadı. Lütfen tekrar deneyin.");
    } finally {
      setPending(null);
    }
  }

  async function handlePasswordReset() {
    setFormError(null);
    setStatus(null);
    if (!email.trim() || !emailRef.current?.checkValidity()) {
      setFormError("Parola sıfırlamak için geçerli bir e-posta adresi girin.");
      emailRef.current?.focus();
      return;
    }
    setPending("reset");
    try {
      await resetPassword(email);
      setStatus("Bu e-posta adresine bağlı bir hesap varsa parola sıfırlama bağlantısı gönderildi.");
    } catch (cause) {
      setFormError(cause instanceof Error ? cause.message : "Parola sıfırlama işlemi tamamlanamadı.");
    } finally {
      setPending(null);
    }
  }

  return (
    <main className="grid min-h-screen bg-[#f0f3f9] lg:grid-cols-[minmax(280px,0.85fr)_minmax(420px,1.5fr)]">
      <aside className="flex flex-col justify-between bg-[#162236] px-7 py-8 text-white lg:px-12 lg:py-12">
        <div className="flex items-center gap-3">
          <GraduationCap size={43} className="shrink-0 text-[#1287ff]" strokeWidth={1.7} aria-hidden="true" />
          <div><p className="text-[23px] font-bold leading-tight">SınavApp</p><p className="mt-1 text-[13px] text-[#c4cbd7]">Admin Paneli</p></div>
        </div>
        <div className="hidden max-w-sm lg:block">
          <h2 className="text-3xl font-semibold leading-tight">Yönetim panelinize<br />hoş geldiniz.</h2>
          <p className="mt-5 text-sm leading-7 text-[#b6c1d3]">Soruları, kategorileri, kullanıcıları ve forum gönderilerini tek bir yerden yönetin.</p>
        </div>
        <p className="hidden text-xs text-[#8796ae] lg:block">SınavApp · Yönetici erişimi</p>
      </aside>
      <section className="flex items-center justify-center px-5 py-12 sm:px-10">
        <div className="w-full max-w-[420px] rounded-2xl border border-[#e4eaf3] bg-white p-7 shadow-[0_8px_35px_#1723350a] sm:p-9">
          <div className="mb-6 flex h-12 w-12 items-center justify-center rounded-xl bg-[#e8f2ff] text-[#087bff]"><LockKeyhole size={25} aria-hidden="true" /></div>
          <h1 className="text-[26px] font-bold tracking-tight text-[#172137]">Yönetici girişi</h1>
          <p className="mb-7 mt-2 text-[13px] leading-6 text-[#778296]">Yönetici hesabınızla giriş yapın.</p>
          <form onSubmit={handleSignIn} className="flex flex-col gap-5" aria-busy={pending !== null}>
            <div>
              <label htmlFor="admin-email" className="mb-2 block text-xs font-semibold text-[#35435b]">E-posta adresi</label>
              <div className="flex items-center gap-3 rounded-lg border border-[#dfe5ef] px-3 focus-within:border-[#087bff]">
                <Mail size={17} className="shrink-0 text-[#8793a5]" aria-hidden="true" />
                <input ref={emailRef} id="admin-email" name="email" type="email" autoComplete="username" required value={email} onChange={(event) => { setEmail(event.target.value); setFormError(null); setStatus(null); }} disabled={pending !== null} className="min-w-0 flex-1 border-0 bg-transparent py-3 text-sm text-[#25334a] outline-none disabled:opacity-60" />
              </div>
            </div>
            <div>
              <label htmlFor="admin-password" className="mb-2 block text-xs font-semibold text-[#35435b]">Parola</label>
              <div className="flex items-center gap-3 rounded-lg border border-[#dfe5ef] px-3 focus-within:border-[#087bff]">
                <LockKeyhole size={17} className="shrink-0 text-[#8793a5]" aria-hidden="true" />
                <input id="admin-password" name="password" type={showPassword ? "text" : "password"} autoComplete="current-password" required value={password} onChange={(event) => { setPassword(event.target.value); setFormError(null); }} disabled={pending !== null} className="min-w-0 flex-1 border-0 bg-transparent py-3 text-sm text-[#25334a] outline-none disabled:opacity-60" />
                <button type="button" onClick={() => setShowPassword(!showPassword)} aria-label={showPassword ? "Parolayı gizle" : "Parolayı göster"} aria-pressed={showPassword} className="rounded p-1 text-[#778296] hover:text-[#087bff]">{showPassword ? <EyeOff size={17} aria-hidden="true" /> : <Eye size={17} aria-hidden="true" />}</button>
              </div>
            </div>
            <div className="flex flex-wrap items-center justify-between gap-3 text-xs">
              <label className="flex cursor-pointer items-center gap-2 text-[#526078]"><input type="checkbox" checked={remember} onChange={(event) => setRemember(event.target.checked)} disabled={pending !== null} className="h-4 w-4 accent-[#087bff]" />Beni hatırla</label>
              <button type="button" disabled={pending !== null} onClick={handlePasswordReset} className="flex items-center gap-1 text-[#087bff] hover:underline disabled:opacity-60">{pending === "reset" && <LoaderCircle size={13} className="animate-spin" aria-hidden="true" />}Parolamı unuttum</button>
            </div>
            {(formError || error) && <p role="alert" className="rounded-lg border border-[#ffd7de] bg-[#fff1f3] px-3 py-3 text-xs leading-5 text-[#cb344b]">{formError || error}</p>}
            {status && <p role="status" className="rounded-lg border border-[#bfe7d5] bg-[#effaf5] px-3 py-3 text-xs leading-5 text-[#238166]">{status}</p>}
            <button type="submit" disabled={pending !== null} className="flex min-h-11 items-center justify-center gap-2 rounded-lg bg-[#087bff] px-4 py-3 text-sm font-semibold text-white transition-colors hover:bg-[#0068e4] disabled:opacity-60">
              {pending === "sign-in" ? <LoaderCircle size={18} className="animate-spin" aria-hidden="true" /> : <LogIn size={18} aria-hidden="true" />}
              {pending === "sign-in" ? "Giriş yapılıyor…" : "Giriş yap"}
            </button>
          </form>
        </div>
      </section>
    </main>
  );
}
