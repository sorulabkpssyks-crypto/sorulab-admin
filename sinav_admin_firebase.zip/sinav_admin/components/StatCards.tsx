"use client";

import { Crown, FileText, MessageCircleMore, UsersRound } from "lucide-react";
import { useAdmin } from "@/lib/admin-context";
import { formatNumber, stats } from "@/lib/mockData";

const icons = { users: UsersRound, questions: FileText, forums: MessageCircleMore, subscribers: Crown };
const colors: Record<string, string> = {
  blue: "from-[#087cff] to-[#168afa]", green: "from-[#14b475] to-[#25b887]",
  purple: "from-[#9565f5] to-[#8464e9]", orange: "from-[#ff920a] to-[#ffa214]",
};

export default function StatCards() {
  const { data, collectionState } = useAdmin();
  const counts: Record<string, number> = {
    users: data.users.length,
    questions: data.questions.length,
    forums: data.forums.length,
    subscribers: data.users.filter((user) => user.premium && user.active).length,
  };
  return (
    <div className="stat-cards grid grid-cols-2 gap-[12px] lg:grid-cols-4">
      {stats.map((stat) => {
        const Icon = icons[stat.id as keyof typeof icons];
        const state = collectionState[stat.id === "subscribers" ? "users" : stat.id as "users" | "questions" | "forums"];
        const status = state.loading ? "Yükleniyor" : state.error ? "Bağlantı hatası" : state.fromCache ? "Önbellek" : "Canlı";
        return (
          <article key={stat.id} className="flex h-[76px] min-w-0 items-center gap-[14px] rounded-[9px] border border-[#e9edf4] bg-white/85 px-[14px] shadow-[0_1px_3px_#26385606]">
            <span className={`flex h-[48px] w-[48px] shrink-0 items-center justify-center rounded-[10px] bg-gradient-to-br text-white shadow-[inset_0_0_0_1px_#ffffff1a] ${colors[stat.color]}`}><Icon size={24} strokeWidth={2.25} aria-hidden="true" /></span>
            <div className="min-w-0 flex-1"><h2 className="truncate text-[11.5px] font-normal text-[#455166]">{stat.label}</h2><p className="mt-[4px] text-[22px] font-bold leading-none tracking-[-.6px] text-[#172335]">{state.loading || state.error ? "—" : formatNumber(counts[stat.id])}</p></div>
            <span className={`flex shrink-0 items-center text-[10px] font-semibold ${state.error ? "text-red-500" : "text-[#25a06b]"}`} title={state.error ?? "Firestore anlık kayıt sayısı"}>{status}</span>
          </article>
        );
      })}
    </div>
  );
}
