"use client";

import { useState } from "react";
import Link from "next/link";
import { usePathname } from "next/navigation";
import {
  BarChart3, Bell, BookText, ChevronDown, DatabaseBackup, FileText,
  Folder, GraduationCap, Home, Lightbulb, Megaphone, MessageCircle,
  Settings, ShieldCheck, UsersRound, X,
} from "lucide-react";
import type { LucideIcon } from "lucide-react";
import { useAdmin } from "@/lib/admin-context";

type Child = { label: string; href?: string; action?: () => void };

export default function Sidebar() {
  const pathname = usePathname();
  const { sidebarOpen, setSidebarOpen, openDialog } = useAdmin();
  const [expanded, setExpanded] = useState<Record<string, boolean>>({ questions: false, ads: true, forum: true });
  const closeOnMobile = () => {
    if (window.matchMedia("(max-width: 767px)").matches) setSidebarOpen(false);
  };
  const link = (label: string, href: string, Icon: LucideIcon, chevron = false) => (
    <Link
      key={href}
      href={href}
      onClick={closeOnMobile}
      aria-current={pathname === href ? "page" : undefined}
      className={`sidebar-link flex h-[34px] items-center gap-[15px] rounded-md px-[10px] text-[12px] transition-colors ${pathname === href ? "bg-[#284f94] text-white shadow-[0_1px_5px_#102542]" : "text-[#d1d7e2] hover:bg-white/10 hover:text-white"}`}
    >
      <Icon size={17} strokeWidth={1.65} className="shrink-0" aria-hidden="true" />
      <span className="flex-1">{label}</span>
      {chevron && <ChevronDown size={12} aria-hidden="true" />}
    </Link>
  );
  const group = (id: string, label: string, Icon: LucideIcon, children: Child[]) => {
    const active = children.some((child) => child.href === pathname);
    return (
      <div key={id}>
        <button
          type="button"
          aria-expanded={!!expanded[id]}
          aria-controls={`sidebar-${id}`}
          onClick={() => setExpanded((value) => ({ ...value, [id]: !value[id] }))}
          className={`flex h-[34px] w-full items-center gap-[15px] rounded-md px-[10px] text-left text-[12px] transition-colors hover:bg-white/10 ${active ? "text-white" : "text-[#d1d7e2]"}`}
        >
          <Icon size={17} strokeWidth={1.65} className="shrink-0" aria-hidden="true" />
          <span className="flex-1">{label}</span>
          <ChevronDown size={12} className={`transition-transform ${expanded[id] ? "rotate-180" : ""}`} aria-hidden="true" />
        </button>
        {expanded[id] && (
          <div id={`sidebar-${id}`} className="pb-[3px] pl-[36px]">
            {children.map((child) => {
              const className = `flex min-h-[28px] w-full items-center gap-[9px] rounded px-[3px] text-left text-[11.5px] transition-colors hover:text-white ${child.href === pathname ? "text-[#7bb8ff]" : "text-[#c9d1de]"}`;
              const content = <><span className="h-[4px] w-[4px] shrink-0 rounded-full bg-current" aria-hidden="true" /><span>{child.label}</span></>;
              return child.href ? <Link key={child.label} href={child.href} onClick={closeOnMobile} className={className} aria-current={child.href === pathname ? "page" : undefined}>{content}</Link> : <button key={child.label} type="button" className={className} onClick={() => { child.action?.(); closeOnMobile(); }}>{content}</button>;
            })}
          </div>
        )}
      </div>
    );
  };

  return (
    <>
      {sidebarOpen && <button type="button" className="sidebar-backdrop fixed inset-0 z-40 bg-[#111c2d]/50 backdrop-blur-[2px] md:hidden" onClick={() => setSidebarOpen(false)} aria-label="Menüyü kapat" />}
      <aside aria-label="Ana gezinme" inert={!sidebarOpen} className={`sidebar fixed inset-y-0 left-0 z-50 w-[204px] overflow-y-auto bg-[#162235] shadow-[1px_0_4px_#1523361a] transition-transform duration-200 ${sidebarOpen ? "translate-x-0" : "-translate-x-full"}`}>
        <Link href="/" onClick={closeOnMobile} className="flex h-[68px] items-start gap-[8px] px-[17px] pt-[15px] text-white" aria-label="SınavApp Admin Paneli ana sayfa">
          <GraduationCap size={40} strokeWidth={1.6} fill="#1685ed" className="mt-[-1px] shrink-0 text-[#1685ed]" aria-hidden="true" />
          <span className="leading-none"><span className="block text-[20px] font-bold tracking-[-.4px]">SınavApp</span><span className="mt-[6px] block text-[12px] font-normal tracking-[.05px] text-[#cbd2dd]">Admin Paneli</span></span>
        </Link>
        <button type="button" onClick={() => setSidebarOpen(false)} aria-label="Menüyü kapat" className="absolute right-1 top-1 rounded p-1 text-[#cbd2dd] hover:bg-white/10 md:hidden"><X size={15} /></button>
        <nav className="px-[10px] pb-6 pt-[5px]">
          {link("Ana Sayfa", "/", Home)}
          {group("questions", "Soru Yönetimi", BookText, [
            { label: "Tüm Sorular", href: "/sorular" },
            { label: "Yeni Soru Ekle", action: () => openDialog("question") },
          ])}
          {link("PDF ile Soru Ekle", "/pdf", FileText)}
          {link("Kategoriler", "/kategoriler", Folder)}
          {link("İpuçları Yönetimi", "/ipuclari", Lightbulb)}
          {group("ads", "Reklam Yönetimi", Megaphone, [
            { label: "AdMob Ayarları", href: "/admob" },
            { label: "Ücretli Reklam Alanları", href: "/reklam-alanlari" },
          ])}
          {link("Abonelik Yönetimi", "/abonelikler", ShieldCheck)}
          {group("forum", "Forum Yönetimi", MessageCircle, [
            { label: "Gönderiler", href: "/forum" },
            { label: "Yorumlar", href: "/yorumlar" },
            { label: "Kullanıcı Raporları", href: "/raporlar" },
            { label: "Küfür Filtresi", href: "/kufur-filtresi" },
            { label: "Forum Ayarları", href: "/forum-ayarlari" },
          ])}
          <div className="mt-[3px] [&_a]:h-[35px]">
            {link("Kullanıcılar", "/kullanicilar", UsersRound, true)}
            {link("Uygulama Ayarları", "/uygulama-ayarlari", Settings)}
            {link("İstatistikler", "/istatistikler", BarChart3)}
            {link("Bildirimler", "/bildirimler", Bell)}
            {link("Yedekleme", "/yedekleme", DatabaseBackup)}
            {link("Sistem Günlükleri", "/gunlukler", BookText)}
          </div>
        </nav>
      </aside>
    </>
  );
}
