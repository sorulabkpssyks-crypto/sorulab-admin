"use client";

import { Copy, Crown, Folder, Pencil, Plus, Settings, Trash2 } from "lucide-react";
import { useAdmin } from "@/lib/admin-context";
import { formatNumber, formatPrice, type AdmobSettings, type RecordId } from "@/lib/mockData";

type WidgetProps = { full?: boolean };

function AdmobLogo() {
  return (
    <svg viewBox="0 0 28 28" width="24" height="24" aria-hidden="true">
      <path d="M15 4a10 10 0 1 0 0 20" fill="none" stroke="#ea4335" strokeWidth="6" strokeLinecap="round" />
      <path d="M15 4a10 10 0 0 1 9 6" fill="none" stroke="#fbbc04" strokeWidth="6" strokeLinecap="round" />
      <path d="M23 11v13" fill="none" stroke="#34a853" strokeWidth="6" strokeLinecap="round" />
    </svg>
  );
}

async function copyToClipboard(value: string) {
  if (navigator.clipboard && window.isSecureContext) {
    try {
      await navigator.clipboard.writeText(value);
      return;
    } catch {
      // Older browsers and restricted clipboard contexts can use the fallback.
    }
  }
  const activeElement = document.activeElement;
  const textarea = document.createElement("textarea");
  textarea.value = value;
  textarea.setAttribute("readonly", "");
  textarea.style.position = "fixed";
  textarea.style.left = "-9999px";
  document.body.appendChild(textarea);
  textarea.select();
  try {
    if (!document.execCommand("copy")) throw new Error("Clipboard unavailable");
  } finally {
    textarea.remove();
    if (activeElement instanceof HTMLElement) activeElement.focus();
  }
}

export function AdmobWidget({ full = false }: WidgetProps) {
  const { data, openDialog, notify, saving } = useAdmin();
  const fields: { key: keyof AdmobSettings; label: string }[] = [
    { key: "appId", label: "Uygulama ID" },
    { key: "bannerId", label: "Banner ID" },
    { key: "interstitialId", label: "Geçiş Reklamı ID" },
    { key: "rewardedId", label: "Ödüllü Reklam ID" },
  ];

  async function copy(value: string, label: string) {
    try {
      await copyToClipboard(value);
      notify(`${label} kopyalandı.`, "success");
    } catch {
      notify("Kopyalama başarısız oldu. Kimliği seçerek kopyalayabilirsiniz.", "error");
    }
  }

  return (
    <section className={`panel bottom-widget admob-widget ${full ? "widget-full" : ""}`} aria-labelledby="admob-widget-title">
      <div className="panel-heading flex items-center justify-between gap-2">
        <h2 id="admob-widget-title" className="flex items-center gap-2 text-[13px] font-bold"><AdmobLogo />AdMob Ayarları</h2>
        <button type="button" className="btn btn-small" disabled={saving} onClick={() => openDialog("admob")}>Düzenle</button>
      </div>
      <div className={`grid ${full ? "gap-4" : "gap-[5px]"}`}>
        {fields.map(({ key, label }) => (
          <label key={key} className="block min-w-0">
            <span className={`mb-[3px] block font-semibold ${full ? "text-sm" : "text-[10px] leading-3"}`}>{label}</span>
            <span className={`flex items-center rounded border border-[#e4e9f1] bg-[#f0f3f8] ${full ? "h-10" : "h-[21px]"}`}>
              <input aria-label={label} title={data.admob[key]} readOnly value={data.admob[key]} onFocus={(event) => event.currentTarget.select()} className={`min-w-0 flex-1 border-0 bg-transparent px-[5px] text-[#4d5769] outline-none ${full ? "text-sm" : "text-[9px]"}`} />
              <button type="button" onClick={() => copy(data.admob[key], label)} className="flex h-full w-6 shrink-0 items-center justify-center rounded-r text-[#586579] transition hover:bg-blue-100 hover:text-blue-600 focus-visible:outline focus-visible:outline-2 focus-visible:outline-blue-500" aria-label={`${label} kopyala`} title={`${label} kopyala`}><Copy size={12} /></button>
            </span>
          </label>
        ))}
      </div>
    </section>
  );
}

export function SubscriptionWidget({ full = false }: WidgetProps) {
  const { data, openDialog, saving } = useAdmin();
  return (
    <section className={`panel bottom-widget subscription-widget ${full ? "widget-full" : ""}`} aria-labelledby="subscription-widget-title">
      <div className="panel-heading flex items-center justify-between gap-2">
        <h2 id="subscription-widget-title" className="flex items-center gap-[7px] text-[13px] font-bold"><Crown size={24} className="shrink-0 text-[#ff981b]" fill="#ff981b" />Abonelik Fiyatları</h2>
        <button type="button" className="btn btn-small" disabled={saving} onClick={() => openDialog("plan")}>Düzenle</button>
      </div>
      <ul className={full ? "space-y-2" : "divide-y divide-[#edf0f5]"}>
        {data.plans.map((plan) => (
          <li key={plan.id} className={`flex items-center justify-between gap-2 ${full ? "rounded-lg bg-slate-50 p-4 text-sm" : "h-[35px] text-[10px]"}`}>
            <span className="min-w-0 truncate" title={plan.name}>{plan.name}</span>
            <span className="ml-auto whitespace-nowrap font-medium tabular-nums">{formatPrice(plan.price)}</span>
            <button type="button" className="icon-button shrink-0" disabled={saving} aria-label={`${plan.name} fiyatını düzenle`} title="Fiyatı düzenle" onClick={() => openDialog("plan", plan.id)}><Pencil size={12} /></button>
          </li>
        ))}
      </ul>
    </section>
  );
}

export function CategoriesWidget({ full = false }: WidgetProps) {
  const { data, openDialog, updateData, confirm, notify, saving, collectionState, retryCollections } = useAdmin();
  const state = collectionState.categories;
  const writeBlocked = saving || state.loading || Boolean(state.error) || collectionState.questions.loading || Boolean(collectionState.questions.error);
  function removeCategory(id: RecordId, name: string) {
    if (data.questions.some((question) => question.category === name) || data.hints.some((hint) => hint.category === name)) {
      notify("Bu kategoriye bağlı sorular veya ipuçları var. Önce bu kayıtları başka bir kategoriye taşıyın.", "error");
      return;
    }
    confirm(`“${name}” kategorisi silinsin mi?`, async () => {
      const saved = await updateData((current) => ({ ...current, categories: current.categories.filter((category) => category.id !== id) }), `${name} kategorisi silindi`);
      if (saved) notify("Kategori silindi.", "success");
      return saved;
    });
  }
  const categories = full ? data.categories : data.categories.slice(0, 5);
  return (
    <section className={`panel bottom-widget categories-widget ${full ? "widget-full" : ""}`} aria-labelledby="categories-widget-title">
      <div className="panel-heading flex items-center justify-between gap-2">
        <h2 id="categories-widget-title" className="flex items-center gap-2 text-[13px] font-bold"><Folder size={23} className="shrink-0 text-[#ffa126]" fill="#ffa126" />Kategoriler</h2>
        <button type="button" className="btn btn-small btn-primary" disabled={writeBlocked} onClick={() => openDialog("category")}><Plus size={12} />Ekle</button>
      </div>
      <div className="overflow-x-auto">
        <table className={`data-table w-full text-left ${full ? "text-sm" : "text-[10px]"}`}>
          <thead><tr className="bg-[#f0f3f8]"><th scope="col" className="px-[3px] py-1 font-normal">Kategori Adı</th><th scope="col" className="px-[3px] py-1 font-normal whitespace-nowrap">Soru Sayısı</th><th scope="col" className="px-[3px] py-1 font-normal text-center">İşlem</th></tr></thead>
          <tbody>
            {categories.map((category) => (
              <tr key={category.id} className={`border-b border-[#edf0f5] last:border-0 ${full ? "h-12" : "h-[27px]"}`}>
                <td className="px-[3px]">{category.name}</td>
                <td className="px-[3px] tabular-nums">{formatNumber(category.count)}</td>
                <td className="px-[3px]"><div className="flex items-center justify-center gap-[7px]">
                  <button type="button" className="icon-button" disabled={writeBlocked} aria-label={`${category.name} kategorisini düzenle`} title="Kategoriyi düzenle" onClick={() => openDialog("category", category.id)}><Pencil size={12} /></button>
                  <button type="button" className="icon-button danger" disabled={writeBlocked} aria-label={`${category.name} kategorisini sil`} title="Kategoriyi sil" onClick={() => removeCategory(category.id, category.name)}><Trash2 size={12} /></button>
                </div></td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      {(state.loading || state.error || categories.length === 0) && <div className="table-empty" role={state.error ? "alert" : "status"}><p>{state.loading ? "Kategoriler Firestore’dan yükleniyor…" : state.error ?? "Henüz kategori eklenmedi."}</p>{state.error && <button type="button" className="btn btn-small" onClick={retryCollections}>Yeniden Dene</button>}</div>}
    </section>
  );
}

export function ForumFiltersWidget({ full = false }: WidgetProps) {
  const { data, updateData, openDialog, saving } = useAdmin();
  return (
    <section className={`panel bottom-widget forum-filters-widget ${full ? "widget-full" : ""}`} aria-labelledby="filters-widget-title">
      <div className="panel-heading flex items-center justify-between gap-2">
        <h2 id="filters-widget-title" className="flex items-center gap-2 text-[13px] font-bold"><Settings size={24} className="shrink-0 text-[#8d5cf6]" />Forum Filtre Ayarları</h2>
        <button type="button" className="btn btn-small" disabled={saving} onClick={() => openDialog("filters")}>Düzenle</button>
      </div>
      <ul className={full ? "space-y-4" : "space-y-[9px]"}>
        {data.filters.map((filter) => (
          <li key={filter.id} className={`flex items-center justify-between gap-2 ${full ? "rounded-lg bg-slate-50 p-4" : ""}`}>
            <div className="min-w-0">
              <span id={`filter-name-${filter.id}`} className={`block font-semibold ${full ? "text-sm" : "text-[10px] leading-[14px]"}`}>{filter.name}</span>
              <span id={`filter-description-${filter.id}`} className={`block text-[#7c8493] ${full ? "mt-1 text-xs" : "text-[9px] leading-[12px]"}`}>{filter.description}</span>
            </div>
            <button type="button" role="switch" disabled={saving} aria-checked={filter.enabled} aria-labelledby={`filter-name-${filter.id}`} aria-describedby={`filter-description-${filter.id}`} onClick={async () => { await updateData((current) => ({ ...current, filters: current.filters.map((setting) => setting.id === filter.id ? { ...setting, enabled: !setting.enabled } : setting) }), `${filter.name} ${filter.enabled ? "devre dışı bırakıldı" : "etkinleştirildi"}`); }} className={`relative h-[18px] w-[34px] shrink-0 rounded-full transition-colors focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-blue-500 ${filter.enabled ? "bg-[#087bff]" : "bg-slate-300"}`}>
              <span className={`absolute top-[2px] h-[14px] w-[14px] rounded-full bg-white shadow-sm transition-transform ${filter.enabled ? "translate-x-[16px]" : "translate-x-[2px]"} left-0`} />
            </button>
          </li>
        ))}
      </ul>
    </section>
  );
}

export default function BottomWidgets() {
  return (
    <div className="bottom-widgets grid grid-cols-1 gap-3 sm:grid-cols-2 xl:grid-cols-[1.25fr_1fr_1.04fr_1.1fr]">
      <AdmobWidget />
      <SubscriptionWidget />
      <CategoriesWidget />
      <ForumFiltersWidget />
    </div>
  );
}
