"use client";

import { useEffect, useRef, useState } from "react";
import Link from "next/link";
import { Bell, Check, CheckCheck, ChevronDown, Folder, LogOut, Menu, MessageCircle, Search, Settings, UserRound, X } from "lucide-react";
import type { LucideIcon } from "lucide-react";
import { useAdmin } from "@/lib/admin-context";
import { useAuth } from "@/lib/auth-context";

type MenuName = "search" | "notifications" | "profile" | null;
type SearchResult = { key: string; title: string; caption: string; Icon: LucideIcon; select: () => void };

export default function Header() {
  const { data, query, setQuery, sidebarOpen, setSidebarOpen, openDialog, updateData, notify, saving } = useAdmin();
  const { user, signOut } = useAuth();
  const [menu, setMenu] = useState<MenuName>(null);
  const [profileName, setProfileName] = useState("Admin");
  const [signingOut, setSigningOut] = useState(false);
  const headerRef = useRef<HTMLElement>(null);
  useEffect(() => {
    const readProfile = () => {
      setProfileName(user?.displayName || user?.email?.split("@")[0] || "Admin");
    };
    readProfile();
    window.addEventListener("sinavapp-profile-updated", readProfile);
    return () => window.removeEventListener("sinavapp-profile-updated", readProfile);
  }, [user]);
  const unreadCount = data.notifications.filter((notification) => !notification.read).length;
  const normalizedQuery = query.trim().toLocaleLowerCase("tr-TR");
  const matches = (value: string) => value.toLocaleLowerCase("tr-TR").includes(normalizedQuery);
  const results: SearchResult[] = normalizedQuery.length < 2 ? [] : [
    ...data.questions.filter((question) => matches(`${question.id} ${question.text} ${question.category}`)).map((question) => ({ key: `question-${question.id}`, title: question.text, caption: `Soru #${question.id} · ${question.category}`, Icon: Search, select: () => openDialog("question", question.id) })),
    ...data.users.filter((user) => matches(`${user.name} ${user.email}`)).map((user) => ({ key: `user-${user.id}`, title: user.name, caption: user.email, Icon: UserRound, select: () => openDialog("user", user.id) })),
    ...data.categories.filter((category) => matches(category.name)).map((category) => ({ key: `category-${category.id}`, title: category.name, caption: `${category.count.toLocaleString("tr-TR")} soru · Kategori`, Icon: Folder, select: () => openDialog("category", category.id) })),
    ...data.forums.filter((post) => matches(`${post.topic} ${post.user}`)).map((post) => ({ key: `forum-${post.id}`, title: post.topic, caption: `${post.user} · Forum gönderisi`, Icon: MessageCircle, select: () => openDialog("forum", post.id) })),
  ].slice(0, 6);

  useEffect(() => {
    if (!menu) return;
    const onPointerDown = (event: PointerEvent) => {
      if (!headerRef.current?.contains(event.target as Node)) setMenu(null);
    };
    const onKeyDown = (event: KeyboardEvent) => {
      if (event.key === "Escape") setMenu(null);
    };
    document.addEventListener("pointerdown", onPointerDown);
    document.addEventListener("keydown", onKeyDown);
    return () => {
      document.removeEventListener("pointerdown", onPointerDown);
      document.removeEventListener("keydown", onKeyDown);
    };
  }, [menu]);

  const selectResult = (result: SearchResult) => {
    setMenu(null);
    result.select();
  };
  const markRead = (id?: number) => updateData((current) => ({ ...current, notifications: current.notifications.map((notification) => id === undefined || notification.id === id ? { ...notification, read: true } : notification) }), id === undefined ? "Tüm bildirimler okundu" : "Bildirim okundu");

  return (
    <header ref={headerRef} className="dashboard-header relative z-30 flex h-[60px] items-center gap-[27px] border-b border-[#e4e9f2] bg-[#f1f4fa]/95 px-[24px] max-sm:gap-3 max-sm:px-4">
      <button type="button" onClick={() => setSidebarOpen(!sidebarOpen)} aria-label={sidebarOpen ? "Yan menüyü daralt" : "Yan menüyü aç"} aria-expanded={sidebarOpen} className="header-menu-button flex h-7 w-5 shrink-0 items-center justify-center rounded text-[#263349] transition-colors hover:text-[#087cff]"><Menu size={20} strokeWidth={1.8} /></button>
      <div className="relative min-w-0 flex-1">
        <form role="search" className="flex max-w-[525px] items-center gap-[8px] rounded-[6px] border border-transparent py-[7px] focus-within:border-[#d9e5f6] focus-within:bg-white/50 focus-within:px-2" onSubmit={(event) => { event.preventDefault(); if (results[0]) selectResult(results[0]); }}>
          <Search size={17} className="shrink-0 text-[#627085]" strokeWidth={1.8} aria-hidden="true" />
          <label htmlFor="global-search" className="sr-only">Kullanıcı, soru, kategori veya forumda ara</label>
          <input id="global-search" type="search" value={query} autoComplete="off" onChange={(event) => { setQuery(event.target.value); setMenu("search"); }} onFocus={() => setMenu("search")} placeholder="Ara... (kullanıcı, soru, kategori, forum vb.)" aria-controls={menu === "search" && normalizedQuery.length >= 2 ? "global-search-results" : undefined} className="w-full min-w-0 border-0 bg-transparent text-[11px] text-[#263349] outline-none placeholder:text-[#8792a3] [&::-webkit-search-cancel-button]:hidden" />
          {query && <button type="button" onClick={() => { setQuery(""); setMenu(null); }} aria-label="Aramayı temizle" className="shrink-0 rounded text-[#7b8798] hover:text-[#172335]"><X size={14} /></button>}
        </form>
        {menu === "search" && normalizedQuery.length >= 2 && <div id="global-search-results" className="absolute left-0 top-[43px] w-full min-w-[240px] max-w-[525px] overflow-hidden rounded-lg border border-[#e3e9f2] bg-white shadow-[0_8px_30px_#17233518]">
          <div className="border-b border-[#edf0f5] px-3 py-2 text-[11px] font-semibold text-[#667185]">Arama sonuçları</div>
          {results.length ? results.map((result) => <button key={result.key} type="button" onClick={() => selectResult(result)} className="flex w-full items-center gap-3 px-3 py-2.5 text-left transition-colors hover:bg-[#f2f6fc]"><result.Icon size={17} className="shrink-0 text-[#4387ed]" aria-hidden="true" /><span className="min-w-0"><span className="block truncate text-[11px] font-medium text-[#172335]">{result.title}</span><span className="mt-0.5 block truncate text-[10px] text-[#7c8797]">{result.caption}</span></span></button>) : <p className="p-4 text-[11px] text-[#667185]">“{query}” için sonuç bulunamadı.</p>}
        </div>}
      </div>
      <div className="relative shrink-0">
        <button type="button" aria-label={`Bildirimler, ${unreadCount} okunmamış bildirim`} aria-haspopup="true" aria-expanded={menu === "notifications"} onClick={() => setMenu(menu === "notifications" ? null : "notifications")} className="relative flex h-8 w-8 items-center justify-center rounded-md text-[#18263b] transition-colors hover:bg-[#e5ecf7]">
          <Bell size={21} strokeWidth={1.7} aria-hidden="true" />
          {unreadCount > 0 && <span className="absolute right-[-1px] top-[1px] flex h-[16px] min-w-[16px] items-center justify-center rounded-full border border-[#f1f4fa] bg-[#ed213d] px-1 text-[10px] leading-none text-white">{unreadCount > 99 ? "99+" : unreadCount}</span>}
        </button>
        {menu === "notifications" && <div className="absolute right-0 top-[44px] w-[320px] max-w-[calc(100vw-32px)] rounded-lg border border-[#e3e9f2] bg-white shadow-[0_8px_30px_#17233518] max-sm:right-[-72px]">
          <div className="flex items-center justify-between border-b border-[#edf0f5] px-3 py-3"><h2 className="text-[12px] font-semibold text-[#172335]">Bildirimler</h2><button type="button" disabled={unreadCount === 0} onClick={() => markRead()} className="flex items-center gap-1 text-[10px] text-[#1878ed] hover:underline disabled:opacity-40"><CheckCheck size={13} aria-hidden="true" />Tümünü okundu işaretle</button></div>
          <div className="max-h-[310px] overflow-y-auto">{data.notifications.length ? data.notifications.slice(0, 6).map((notification) => <div key={notification.id} className={`flex items-start gap-2 border-b border-[#f0f3f7] px-3 py-3 ${notification.read ? "" : "bg-[#f5f8ff]"}`}><span className={`mt-1.5 h-[6px] w-[6px] shrink-0 rounded-full ${notification.read ? "bg-[#c9d2df]" : "bg-[#1878ed]"}`} /><div className="min-w-0 flex-1"><p className="text-[11px] font-semibold text-[#27354a]">{notification.title}</p><p className="mt-1 text-[10px] leading-relaxed text-[#748095]">{notification.message}</p></div>{!notification.read && <button type="button" onClick={() => markRead(notification.id)} title="Okundu olarak işaretle" aria-label={`${notification.title} bildirimini okundu olarak işaretle`} className="rounded p-1 text-[#748095] hover:bg-[#e4edfa] hover:text-[#1878ed]"><Check size={13} /></button>}</div>) : <p className="px-3 py-6 text-center text-[11px] text-[#748095]">Henüz bildirim bulunmuyor.</p>}</div>
          <Link href="/bildirimler" onClick={() => setMenu(null)} className="block py-3 text-center text-[11px] font-medium text-[#1878ed] hover:bg-[#f5f8ff]">Tüm bildirimleri gör</Link>
        </div>}
      </div>
      <div className="relative ml-[-5px] shrink-0">
        <button type="button" aria-haspopup="menu" aria-expanded={menu === "profile"} onClick={() => setMenu(menu === "profile" ? null : "profile")} className="flex items-center gap-[10px] rounded-md text-left hover:bg-[#e5ecf7]">
          <span className="flex h-[32px] w-[32px] shrink-0 items-center justify-center overflow-hidden rounded-full bg-[#172335] text-white"><UserRound size={26} fill="#eef2fa" stroke="#172335" strokeWidth={1.25} className="translate-y-[3px]" aria-hidden="true" /></span>
          <span className="min-w-[78px] max-sm:hidden"><span className="block max-w-[120px] truncate text-[12px] font-semibold leading-[16px] text-[#172335]">{profileName}</span><span className="block text-[9px] leading-[15px] text-[#7b8799]">Sistem Yöneticisi</span></span>
          <ChevronDown size={13} className="ml-[2px] text-[#243248] max-sm:hidden" aria-hidden="true" />
          <span className="sr-only">Yönetici profil menüsü</span>
        </button>
        {menu === "profile" && <div role="menu" aria-label="Yönetici profil işlemleri" className="absolute right-0 top-[46px] w-[190px] overflow-hidden rounded-lg border border-[#e3e9f2] bg-white py-1 shadow-[0_8px_30px_#17233518]">
          <button role="menuitem" type="button" onClick={() => { setMenu(null); openDialog("profile"); }} className="flex w-full items-center gap-2 px-3 py-2.5 text-left text-[11px] text-[#344156] hover:bg-[#f3f7fc]"><UserRound size={15} />Profili düzenle</button>
          <Link role="menuitem" href="/uygulama-ayarlari" onClick={() => setMenu(null)} className="flex items-center gap-2 px-3 py-2.5 text-[11px] text-[#344156] hover:bg-[#f3f7fc]"><Settings size={15} />Uygulama ayarları</Link>
          <div className="border-t border-slate-100 px-3 py-2 text-[10px] text-slate-500 break-all">{user?.email}</div>
          <button role="menuitem" type="button" disabled={signingOut || saving} onClick={async () => {
            setSigningOut(true);
            try { await signOut(); setMenu(null); }
            catch (error) { notify(error instanceof Error ? error.message : "Oturum kapatılamadı.", "error"); }
            finally { setSigningOut(false); }
          }} className="flex w-full items-center gap-2 px-3 py-2.5 text-left text-[11px] text-red-600 hover:bg-red-50 disabled:opacity-50"><LogOut size={15} />{signingOut ? "Çıkış yapılıyor…" : "Çıkış yap"}</button>
        </div>}
      </div>
    </header>
  );
}
