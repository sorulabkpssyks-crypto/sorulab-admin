"use client";

import { useEffect, useMemo, useRef, useState } from "react";
import Link from "next/link";
import { AlertCircle, CheckCircle2, FileText, LoaderCircle, Plus, Trash2, Upload } from "lucide-react";
import type { PDFDocumentProxy } from "pdfjs-dist";
import { useAdmin } from "@/lib/admin-context";
import type { Difficulty, Question } from "@/lib/mockData";

interface Candidate {
  id: number;
  text: string;
  options: string[];
  answer: number | null;
  explanation: string;
}

const MAX_FILE_SIZE = 15 * 1024 * 1024;
const LETTERS = ["A", "B", "C", "D", "E"];
const QUESTION_START = /^\s*(?:soru\s*)?\d{1,4}\s*[.)\-:]\s*(.*)$/iu;
const ANSWER_LINE = /^\s*(?:cevap|yanıt|yanit|doğru\s*(?:cevap|yanıt)|dogru\s*cevap|answer)\s*[:\-]?\s*([A-E])(?:\s*[).])?(?:\s|$)/iu;

/** PDF text stays editable because column layouts and scanned pages need review. */
export function parsePdfQuestions(source: string): Candidate[] {
  const normalized = source.replace(/\r\n?/g, "\n").replace(/\u00a0/g, " ");
  const numbered = normalized.split("\n").some((line) => QUESTION_START.test(line));
  const result: Candidate[] = [];
  let current: Candidate | null = null;
  let optionIndex: number | null = null;
  let explanation = false;

  const finish = () => {
    if (!current || (!current.text.trim() && !current.options.some((option) => option.trim()))) return;
    result.push({
      ...current,
      id: result.length + 1,
      text: current.text.trim(),
      options: current.options.map((option) => option.trim()),
      explanation: current.explanation.trim(),
    });
  };

  // Preserve ordinary prose, but split choices printed together on the same line.
  const lines = normalized.split("\n").flatMap((line) => {
    const matches = Array.from(line.matchAll(/(?:^|[\t ]+)([A-E])[).][\t ]+/giu));
    const sequence = matches.map((match) => match[1].toUpperCase()).join("");
    if (matches.length > 1 && /AB|BC|CD|DE/.test(sequence)) {
      return line.replace(/(?:^|[\t ]+)([A-E])[).][\t ]+/giu, "\n$1) ").split("\n");
    }
    return [line];
  });

  for (const raw of lines) {
    const line = raw.trim();
    if (!line) continue;
    const start = line.match(QUESTION_START);
    if (start) {
      finish();
      current = { id: 0, text: start[1], options: [], answer: null, explanation: "" };
      optionIndex = null;
      explanation = false;
      continue;
    }
    if (!current) {
      if (numbered) continue;
      current = { id: 0, text: "", options: [], answer: null, explanation: "" };
    }
    const answer = line.match(ANSWER_LINE);
    if (answer) {
      current.answer = LETTERS.indexOf(answer[1].toUpperCase());
      optionIndex = null;
      continue;
    }
    const solution = line.match(/^(?:açıklama|aciklama|çözüm|cozum)\s*[:\-]\s*(.*)$/iu);
    if (solution) {
      current.explanation = solution[1];
      explanation = true;
      optionIndex = null;
      continue;
    }
    if (explanation) {
      current.explanation += `${current.explanation ? "\n" : ""}${line}`;
      continue;
    }
    const option = line.match(/^([A-E])\s*[).:\-]\s*(.*)$/iu);
    if (option) {
      optionIndex = LETTERS.indexOf(option[1].toUpperCase());
      while (current.options.length <= optionIndex) current.options.push("");
      current.options[optionIndex] = option[2];
      continue;
    }
    if (optionIndex !== null) {
      current.options[optionIndex] += `${current.options[optionIndex] ? " " : ""}${line}`;
    } else {
      current.text += `${current.text ? "\n" : ""}${line}`;
    }
  }
  finish();
  return result;
}

function validationMessage(candidate: Candidate): string | null {
  if (!candidate.text.trim()) return "Soru metnini yazın.";
  if (candidate.options.length < 2) return "En az iki seçenek ekleyin.";
  if (candidate.options.some((option) => !option.trim())) return "Boş seçenekleri doldurun veya kaldırın.";
  if (candidate.answer === null || !candidate.options[candidate.answer]?.trim()) return "Doğru cevabı seçin.";
  return null;
}

export default function PdfImport() {
  const { data, updateData, notify, saving, collectionState, retryCollections } = useAdmin();
  const categories = useMemo(() => Array.from(new Set([
    ...data.categories.map((item) => item.name), ...data.questions.map((item) => item.category),
  ])), [data.categories, data.questions]);
  const [category, setCategory] = useState(categories[0] ?? "");
  const [difficulty, setDifficulty] = useState<Difficulty>("Orta");
  const [source, setSource] = useState("");
  const [candidates, setCandidates] = useState<Candidate[]>([]);
  const [sourceChanged, setSourceChanged] = useState(false);
  const [fileName, setFileName] = useState("");
  const [busy, setBusy] = useState(false);
  const [importing, setImporting] = useState(false);
  const [progress, setProgress] = useState("");
  const [error, setError] = useState("");
  const [dragging, setDragging] = useState(false);
  const fileInput = useRef<HTMLInputElement>(null);
  const operation = useRef(0);
  const importPending = useRef(false);
  const validCount = candidates.filter((candidate) => !validationMessage(candidate)).length;
  const selectedCategory = categories.includes(category) ? category : (categories[0] ?? "");
  const writeBlocked = [collectionState.questions, collectionState.categories].some((state) => state.loading || state.error);
  const connectionError = collectionState.questions.error || collectionState.categories.error;
  const canImport = !writeBlocked && candidates.length > 0 && validCount === candidates.length && !!selectedCategory && !sourceChanged && !busy && !importing && !saving;

  useEffect(() => () => { operation.current += 1; }, []);

  async function readPdf(file: File) {
    if (busy || saving || importPending.current) return;
    setError("");
    if (!file.name.toLowerCase().endsWith(".pdf") && file.type !== "application/pdf") {
      setError("Lütfen PDF biçiminde bir dosya seçin.");
      return;
    }
    if (file.size > MAX_FILE_SIZE) {
      setError("PDF dosyası en fazla 15 MB olabilir.");
      return;
    }
    if (!file.size) {
      setError("Seçilen dosya boş. Geçerli bir PDF seçin.");
      return;
    }
    const taskId = ++operation.current;
    setBusy(true);
    setProgress("PDF okunuyor…");
    let document: PDFDocumentProxy | undefined;
    try {
      const buffer = await file.arrayBuffer();
      const signature = new TextDecoder("latin1").decode(buffer.slice(0, 1024));
      if (!signature.includes("%PDF-")) throw new Error("Dosya geçerli bir PDF başlığı içermiyor.");
      const pdfjs = await import("pdfjs-dist");
      pdfjs.GlobalWorkerOptions.workerSrc = "/pdf.worker.min.mjs";
      const loadingTask = pdfjs.getDocument({ data: new Uint8Array(buffer) });
      document = await loadingTask.promise;
      const pages: string[] = [];
      for (let pageNumber = 1; pageNumber <= document.numPages; pageNumber += 1) {
        if (taskId !== operation.current) return;
        setProgress(`Metin çıkarılıyor: ${pageNumber} / ${document.numPages} sayfa`);
        const page = await document.getPage(pageNumber);
        const content = await page.getTextContent();
        let text = "";
        let previousY: number | null = null;
        let lineEnded = true;
        for (const item of content.items) {
          if (!("str" in item)) continue;
          const currentY = item.transform[5];
          if (!lineEnded && previousY !== null && Math.abs(currentY - previousY) > Math.max(2, item.height * 0.35)) {
            text += "\n";
            lineEnded = true;
          }
          if (item.str) {
            text += `${!lineEnded && !text.endsWith(" ") ? " " : ""}${item.str}`;
            lineEnded = false;
          }
          if (item.hasEOL) {
            text += "\n";
            lineEnded = true;
          }
          previousY = currentY;
        }
        pages.push(text.trim());
        page.cleanup();
      }
      if (taskId !== operation.current) return;
      const extracted = pages.join("\n\n").trim();
      setSource(extracted);
      setFileName(file.name);
      setSourceChanged(false);
      const parsed = parsePdfQuestions(extracted);
      setCandidates(parsed);
      if (!extracted) {
        setError("Bu PDF’de okunabilir metin bulunamadı. Taranmış görseller için OCR gerekir. Soruları aşağıdaki alana yazarak veya metin olarak yapıştırarak devam edebilirsiniz.");
      } else if (!parsed.length) {
        setError("Metin çıkarıldı ancak soru biçimi tanınamadı. Metni aşağıdaki örneğe göre düzenleyip Önizleme Oluştur’a basın.");
      }
      setProgress(`${document.numPages} sayfa okundu. ${parsed.length} soru adayı bulundu; metinleri, seçenekleri ve doğru cevapları kontrol edin.`);
    } catch (caught) {
      if (taskId !== operation.current) return;
      const name = caught instanceof Error ? caught.name : "";
      setError(name === "PasswordException"
        ? "Bu PDF şifreli. Şifresi kaldırılmış bir kopya yükleyin veya soruları metin olarak yapıştırın."
        : `PDF okunamadı. ${caught instanceof Error && caught.message.includes("PDF başlığı") ? caught.message : "Dosya bozuk olabilir. Başka bir PDF seçin veya metni elle ekleyin."}`);
      setProgress("");
    } finally {
      if (document) {
        try { await document.destroy(); } catch { /* Cleanup must not discard extracted text. */ }
      }
      if (taskId === operation.current) setBusy(false);
    }
  }

  function preview() {
    setError("");
    const parsed = parsePdfQuestions(source);
    setCandidates(parsed);
    setSourceChanged(false);
    if (!parsed.length) setError("Önizleme için en az bir soru metni ekleyin.");
    setProgress(parsed.length ? `${parsed.length} soru adayı oluşturuldu. Kaydetmeden önce cevapları kontrol edin.` : "");
  }

  function updateCandidate(id: number, updater: (candidate: Candidate) => Candidate) {
    setCandidates((current) => current.map((candidate) => candidate.id === id ? updater(candidate) : candidate));
  }

  async function importQuestions() {
    if (importPending.current || saving) return;
    if (!canImport) {
      setError("Kaydetmeden önce tüm soru metinlerini, seçenekleri ve doğru cevapları tamamlayın.");
      return;
    }
    importPending.current = true;
    setImporting(true);
    setError("");
    const today = new Date().toISOString().slice(0, 10);
    const imported: Question[] = candidates.map((candidate) => ({
      id: crypto.randomUUID(),
      text: candidate.text.trim(),
      options: candidate.options.map((option) => option.trim()),
      answer: candidate.answer!,
      explanation: candidate.explanation.trim(),
      category: selectedCategory,
      difficulty,
      date: today,
    }));
    try {
      const committed = await updateData((current) => {
        const existing = current.categories.find((item) => item.name === selectedCategory);
        return {
          ...current,
          questions: [...imported, ...current.questions],
          categories: existing
            ? current.categories.map((item) => item.name === selectedCategory ? { ...item, count: item.count + imported.length } : item)
            : [...current.categories, { id: crypto.randomUUID(), name: selectedCategory, count: imported.length }],
        };
      }, `${imported.length} soru PDF/metin içe aktarımıyla eklendi.`);
      if (!committed) return;
      notify(`${imported.length} soru Firestore’a kaydedildi.`);
      setSource("");
      setCandidates([]);
      setFileName("");
      setSourceChanged(false);
      setProgress("Sorular Firestore’a kaydedildi. Soru Yönetimi bölümünden inceleyebilirsiniz.");
    } catch {
      setError("Sorular kaydedilemedi. Önizleme korunuyor; bağlantınızı kontrol edip tekrar deneyin.");
    } finally {
      importPending.current = false;
      setImporting(false);
    }
  }

  return (
    <section className="panel p-5 sm:p-6" aria-labelledby="pdf-title">
      <div className="mb-5 flex flex-wrap items-start justify-between gap-3">
        <div><h2 id="pdf-title" className="text-lg font-bold text-slate-900">PDF ile Soru Ekle</h2><p className="mt-1 text-sm text-slate-500">PDF’yi yükleyin, çıkarılan soruları kontrol edin ve soru bankasına kaydedin.</p></div>
        <Link href="/sorular" className="btn btn-small">Soru Yönetimi</Link>
      </div>

      <fieldset disabled={saving || importing} className="min-w-0">
      {connectionError && <div role="alert" className="form-error mb-4">{connectionError}<button type="button" className="btn btn-small ml-3" onClick={retryCollections}>Yeniden Dene</button></div>}
      <div
        onDragOver={(event) => { event.preventDefault(); if (!busy && !saving && !importing) setDragging(true); }}
        onDragLeave={() => setDragging(false)}
        onDrop={(event) => {
          event.preventDefault();
          setDragging(false);
          const files = event.dataTransfer.files;
          if (files.length > 1) { setError("Her seferinde bir PDF dosyası yükleyin."); return; }
          if (files[0]) void readPdf(files[0]);
        }}
        className={`flex flex-col items-center gap-3 rounded-xl border-2 border-dashed p-7 text-center transition-colors ${dragging ? "border-blue-500 bg-blue-50" : "border-slate-200 bg-slate-50/70"}`}
      >
        {busy ? <LoaderCircle className="animate-spin text-blue-500" size={32} /> : <Upload className="text-blue-500" size={32} />}
        <div><p className="font-medium text-slate-800">{fileName || "PDF dosyanızı buraya sürükleyin"}</p><p className="mt-1 text-xs text-slate-500">En fazla 15 MB · Metin içeren PDF · Dosya tarayıcınızda işlenir</p></div>
        <input ref={fileInput} type="file" accept="application/pdf,.pdf" className="sr-only" aria-label="Soru içeren PDF dosyası" disabled={busy} onChange={(event) => { const file = event.target.files?.[0]; if (file) void readPdf(file); event.target.value = ""; }} />
        <button type="button" className="btn btn-primary" disabled={busy} onClick={() => fileInput.current?.click()}><FileText size={16} />{busy ? "PDF İşleniyor…" : "PDF Seç"}</button>
      </div>

      {progress && <p role="status" className="mt-4 flex items-start gap-2 text-sm text-slate-600"><CheckCircle2 className="mt-0.5 shrink-0 text-blue-500" size={17} />{progress}</p>}
      {error && <div role="alert" className="mt-4 flex items-start gap-2 rounded-lg border border-red-100 bg-red-50 p-3 text-sm text-red-700"><AlertCircle className="mt-0.5 shrink-0" size={17} />{error}</div>}

      <div className="mt-5 grid gap-4 sm:grid-cols-2">
        <label className="field"><span>Kategori</span><select value={selectedCategory} onChange={(event) => setCategory(event.target.value)} disabled={busy}>{!categories.length && <option value="">Önce bir kategori ekleyin</option>}{categories.map((name) => <option key={name} value={name}>{name}</option>)}</select></label>
        <label className="field"><span>Zorluk</span><select value={difficulty} onChange={(event) => setDifficulty(event.target.value as Difficulty)} disabled={busy}>{(["Kolay", "Orta", "Zor"] as const).map((level) => <option key={level} value={level}>{level}</option>)}</select></label>
      </div>

      <div className="mt-5">
        <label className="field"><span>PDF’den çıkarılan metin / elle soru girişi</span><textarea value={source} rows={10} disabled={busy} className="font-mono text-xs" onChange={(event) => { setSource(event.target.value); setSourceChanged(true); }} placeholder="PDF’deki metni inceleyin veya soru metinlerinizi buraya yapıştırın." /></label>
        <details className="mt-2 text-xs text-slate-500"><summary className="cursor-pointer font-medium text-slate-600">Desteklenen soru biçimi ve kontrol bilgisi</summary><p className="my-2">Her soruya numara verin. A)–E) veya A.–E. seçeneklerini ayrı satırlarda yazın. Cevap bilgisi bulunmuyorsa önizlemede doğru cevabı seçin. Çok sütunlu PDF’lerde okuma sırası bozulabilir; kaynak metni düzeltip önizlemeyi yeniden oluşturun. Metin değiştirildiğinde önizleme yeniden oluşturulmalıdır.</p><pre className="overflow-x-auto rounded-lg bg-slate-50 p-3">{"1. 2x + 5 = 15 denkleminin çözümü nedir?\nA) 3\nB) 5\nC) 7\nD) 10\nCevap: B\nAçıklama: 2x = 10, x = 5."}</pre></details>
        <div className="mt-3 flex flex-wrap items-center gap-3"><button type="button" className="btn" onClick={preview} disabled={busy || !source.trim()}>Önizleme Oluştur</button>{sourceChanged && candidates.length > 0 && <span className="text-xs text-amber-700">Metin değişti. Güncel soruları kaydetmek için önizlemeyi yeniden oluşturun.</span>}</div>
      </div>

      <div className="mt-7 border-t border-slate-100 pt-5">
        <div className="mb-4 flex flex-wrap items-center justify-between gap-2"><h3 className="font-bold text-slate-800">Soru Önizlemesi</h3><span className="text-xs text-slate-500">{validCount} / {candidates.length} soru kaydetmeye hazır</span></div>
        {!candidates.length && <div className="empty-state rounded-lg bg-slate-50 px-4 py-8 text-center text-sm text-slate-500">PDF yükleyin veya metin ekleyip önizleme oluşturun. Sorular burada düzenlenebilir olarak görünür.</div>}
        <div className="space-y-4">
          {candidates.map((candidate, index) => {
            const warning = validationMessage(candidate);
            return <article key={candidate.id} className="rounded-xl border border-slate-200 p-4">
              <div className="mb-3 flex items-center justify-between"><h4 className="text-sm font-semibold text-slate-800">Soru {index + 1}</h4><button type="button" className="icon-button danger" onClick={() => setCandidates((current) => current.filter((item) => item.id !== candidate.id))} aria-label={`${index + 1}. soruyu içe aktarma listesinden kaldır`} title="Listeden kaldır"><Trash2 size={16} /></button></div>
              <label className="field"><span>Soru metni</span><textarea value={candidate.text} rows={3} onChange={(event) => updateCandidate(candidate.id, (item) => ({ ...item, text: event.target.value }))} /></label>
              <div className="mt-3 grid gap-3 sm:grid-cols-2">{candidate.options.map((option, optionNumber) => <div key={optionNumber} className="flex items-end gap-2"><label className="field min-w-0 flex-1"><span>{LETTERS[optionNumber]} seçeneği</span><input value={option} onChange={(event) => updateCandidate(candidate.id, (item) => ({ ...item, options: item.options.map((value, optionId) => optionId === optionNumber ? event.target.value : value) }))} /></label><button type="button" className="icon-button mb-1 shrink-0 text-slate-400" aria-label={`${index + 1}. sorunun ${LETTERS[optionNumber]} seçeneğini kaldır`} title="Seçeneği kaldır" onClick={() => updateCandidate(candidate.id, (item) => ({ ...item, options: item.options.filter((_, optionId) => optionId !== optionNumber), answer: item.answer === optionNumber ? null : item.answer !== null && item.answer > optionNumber ? item.answer - 1 : item.answer }))}><Trash2 size={14} /></button></div>)}</div>
              <div className="mt-3 flex flex-wrap items-end gap-3"><label className="field min-w-[180px]"><span>Doğru cevap</span><select value={candidate.answer ?? ""} onChange={(event) => updateCandidate(candidate.id, (item) => ({ ...item, answer: event.target.value === "" ? null : Number(event.target.value) }))}><option value="">Doğru cevabı seçin</option>{candidate.options.map((_, optionNumber) => <option key={optionNumber} value={optionNumber}>{LETTERS[optionNumber]} seçeneği</option>)}</select></label><button type="button" className="btn btn-small mb-0.5" disabled={candidate.options.length >= 5} onClick={() => updateCandidate(candidate.id, (item) => ({ ...item, options: [...item.options, ""] }))}><Plus size={14} />Seçenek Ekle</button></div>
              <label className="field mt-3"><span>Açıklama (isteğe bağlı)</span><textarea value={candidate.explanation} rows={2} onChange={(event) => updateCandidate(candidate.id, (item) => ({ ...item, explanation: event.target.value }))} /></label>
              {warning ? <p className="mt-3 flex items-center gap-1.5 text-xs text-amber-700"><AlertCircle size={14} />{warning}</p> : <p className="mt-3 flex items-center gap-1.5 text-xs text-emerald-600"><CheckCircle2 size={14} />Kaydetmeye hazır</p>}
            </article>;
          })}
        </div>
        <div className="mt-5 flex flex-wrap items-center justify-between gap-3"><p className="text-xs text-slate-500">Kaydedilen sorular {selectedCategory || "seçilen kategori"} kategorisine eklenir. Doğru cevap seçimi zorunludur.</p><button type="button" className="btn btn-primary" onClick={importQuestions} disabled={!canImport}>{importing ? <LoaderCircle size={16} className="animate-spin" /> : <Plus size={16} />}{importing ? "Firestore’a Kaydediliyor…" : candidates.length ? `${candidates.length} Soruyu Kaydet` : "Soruları Kaydet"}</button></div>
      </div>
      </fieldset>
    </section>
  );
}
