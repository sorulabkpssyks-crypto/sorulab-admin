"use client";

import Link from "next/link";
import { BarChart3, Crown, FilePlus2, Folder, MessageCircleMore, Upload } from "lucide-react";
import { useAdmin } from "@/lib/admin-context";

export default function QuickActions() {
  const { openDialog } = useAdmin();
  const actions = [
    { title: "+ Soru Ekle", Icon: FilePlus2, color: "from-[#0775ff] to-[#1986fb]", action: () => openDialog("question") },
    { title: "PDF ile Soru Ekle", Icon: Upload, color: "from-[#9061f4] to-[#9368f0]", href: "/pdf" },
    { title: "Kategori Ekle", Icon: Folder, color: "from-[#16ae73] to-[#23b67b]", action: () => openDialog("category") },
    { title: "AdMob Ayarları", Icon: BarChart3, color: "from-[#ff970d] to-[#ffa016]", action: () => openDialog("admob") },
    { title: "Abonelik Fiyatları", Icon: Crown, color: "from-[#ff5967] to-[#f84f61]", href: "/abonelikler" },
    { title: "Forum Kontrolü", Icon: MessageCircleMore, color: "from-[#06a2f8] to-[#0d9bf0]", href: "/forum" },
  ];
  return (
    <section className="quick-actions h-[218px] rounded-[9px] border border-[#e9edf4] bg-white/85 p-[13px] shadow-[0_1px_3px_#26385606]" aria-labelledby="quick-actions-title">
      <h2 id="quick-actions-title" className="mb-[11px] text-[14px] font-bold tracking-[-.25px] text-[#172335]">Hızlı İşlemler</h2>
      <div className="grid grid-cols-3 gap-[10px]">
        {actions.map(({ title, Icon, color, href, action }) => {
          const className = `flex h-[74px] min-w-0 flex-col items-center justify-center gap-[9px] rounded-[7px] bg-gradient-to-br text-center text-[10.5px] font-medium text-white transition duration-150 hover:-translate-y-0.5 hover:brightness-105 active:translate-y-0 ${color}`;
          const content = <><Icon size={22} strokeWidth={2.6} aria-hidden="true" /><span>{title}</span></>;
          return href ? <Link key={title} href={href} className={className}>{content}</Link> : <button key={title} type="button" onClick={action} className={className}>{content}</button>;
        })}
      </div>
    </section>
  );
}
