"use client";

import { useEffect, useRef, useState, type ChangeEvent, type FormEvent, type ReactNode } from "react";
import Link from "next/link";
import { Check, ShieldCheck, UserRound, X } from "lucide-react";
import { updateProfile, type User as FirebaseUser } from "firebase/auth";
import { useAuth } from "@/lib/auth-context";
import { firebaseErrorMessage } from "@/lib/firestore-service";
import { useAdmin, type DialogState } from "@/lib/admin-context";
import { formatDate, type AdminData, type Difficulty, type ForumStatus, type User } from "@/lib/mockData";

type Fields = Record<string, string>;
const nextId = (rows: { id: number }[]) => Math.max(0, ...rows.map((row) => row.id)) + 1;
const today = () => new Date().toISOString().slice(0, 10);
const titles: Record<DialogState["kind"], string> = {
  question: "Soru", category: "Kategori", plan: "Abonelik fiyatları", admob: "AdMob ayarları",
  forum: "Forum gönderisini incele", hint: "İpucu", ad: "Reklam alanı", user: "Kullanıcı profili",
  notification: "Bildirim oluştur", filters: "Forum filtre ayarları", profile: "Yönetici profili", confirm: "İşlemi onayla",
};

function initialFields(dialog: DialogState, data: AdminData, authUser: FirebaseUser | null): Fields {
  switch (dialog.kind) {
    case "question": {
      const question = data.questions.find((row) => row.id === dialog.id);
      return { text: question?.text ?? "", category: question?.category ?? data.categories[0]?.name ?? "", difficulty: question?.difficulty ?? "Orta", answer: question ? String(question.answer) : "", optionCount: String(question?.options.length ?? 4), explanation: question?.explanation ?? "", ...Object.fromEntries(Array.from({ length: question?.options.length ?? 4 }, (_, index) => [`option${index}`, question?.options[index] ?? ""])) };
    }
    case "category": return { name: data.categories.find((row) => row.id === dialog.id)?.name ?? "" };
    case "plan": return Object.fromEntries(data.plans.filter((row) => dialog.id === undefined || row.id === dialog.id).flatMap((row) => [[`name${row.id}`, row.name], [`price${row.id}`, String(row.price)]]));
    case "admob": return { ...data.admob };
    case "forum": return { status: data.forums.find((row) => row.id === dialog.id)?.status ?? "Onay Bekliyor" };
    case "hint": {
      const hint = data.hints.find((row) => row.id === dialog.id);
      return { title: hint?.title ?? "", category: hint?.category ?? data.categories[0]?.name ?? "", content: hint?.content ?? "" };
    }
    case "ad": {
      const ad = data.ads.find((row) => row.id === dialog.id);
      return { title: ad?.title ?? "", placement: ad?.placement ?? "Ana sayfa", url: ad?.url ?? "", active: String(ad?.active ?? true) };
    }
    case "user": {
      const user = data.users.find((row) => row.id === dialog.id);
      return { name: user?.name ?? "", email: user?.email ?? "", role: user?.role ?? "Kullanıcı", premium: String(user?.premium ?? false), active: String(user?.active ?? true) };
    }
    case "notification": return { title: "", message: "", audience: "Tüm kullanıcılar" };
    case "filters": return Object.fromEntries(data.filters.map((filter) => [filter.id, String(filter.enabled)]));
    case "profile": {
      return { name: authUser?.displayName || authUser?.email?.split("@")[0] || "", email: authUser?.email || "" };
    }
    default: return {};
  }
}

function Field({ label, children, hint }: { label: string; children: ReactNode; hint?: string }) {
  return <label className="form-field"><span>{label}</span>{children}{hint && <small className="field-hint">{hint}</small>}</label>;
}

function DialogContent({ dialog }: { dialog: DialogState }) {
  const { data, updateData, notify, closeDialog, saving, collectionState, retryCollections } = useAdmin();
  const { user: authUser } = useAuth();
  const [fields, setFields] = useState<Fields>(() => initialFields(dialog, data, authUser));
  const [error, setError] = useState("");
  const [submitting, setSubmitting] = useState(false);
  const relevantStates = dialog.kind === "question" || dialog.kind === "category"
    ? [collectionState.questions, collectionState.categories]
    : dialog.kind === "user" ? [collectionState.users]
    : dialog.kind === "forum" ? [collectionState.forums] : [];
  const unavailable = relevantStates.some((state) => state.loading || state.error);
  const collectionError = relevantStates.find((state) => state.error)?.error;
  const busy = saving || submitting;
  const text = (name: string) => fields[name]?.trim() ?? "";
  const optionIndexes = Array.from({ length: Number(fields.optionCount) || 4 }, (_, index) => index);
  const bind = (name: string) => ({ value: fields[name] ?? "", onChange: (event: ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => { setFields((current) => ({ ...current, [name]: event.target.value })); setError(""); } });
  const toggle = (name: string, label: string) => <label className="dialog-toggle"><span>{label}</span><input type="checkbox" checked={fields[name] === "true"} onChange={(event) => setFields((current) => ({ ...current, [name]: String(event.target.checked) }))} /><span aria-hidden="true" className="toggle-track" /></label>;
  const categoryNames = [...new Set([...data.categories.map((row) => row.name), ...(fields.category ? [fields.category] : [])])];
  const categoryField = <Field label="Kategori"><select className="field" required {...bind("category")}><option value="" disabled>Kategori seçin</option>{categoryNames.map((category) => <option key={category} value={category}>{category}</option>)}</select></Field>;
  const commit = async (updater: (current: AdminData) => AdminData, action: string): Promise<boolean> => {
    if (busy || unavailable) return false;
    setSubmitting(true);
    try {
      const saved = await updateData(updater, action);
      if (saved) {
        notify("Değişiklikler kaydedildi.");
        closeDialog();
      } else {
        setError("Değişiklikler kaydedilemedi. Bağlantıyı ve erişim izinlerini kontrol ederek yeniden deneyin.");
      }
      return saved;
    } catch (cause) {
      setError(cause instanceof Error ? cause.message : "Değişiklikler kaydedilemedi.");
      return false;
    } finally {
      setSubmitting(false);
    }
  };
  const fail = (message: string) => { setError(message); return; };
  const post = data.forums.find((row) => row.id === dialog.id);
  const saveForum = async (status: ForumStatus) => {
    if (!post) return fail("Gönderi bulunamadı.");
    await commit((current) => ({ ...current, forums: current.forums.map((row) => row.id === post.id ? { ...row, status } : row) }), `Forum gönderisi #${post.id}: ${status}`);
  };

  const submit = async (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    if (busy || unavailable) return;
    setError("");
    if (dialog.id !== undefined) {
      const records = dialog.kind === "question" ? data.questions : dialog.kind === "category" ? data.categories : dialog.kind === "user" ? data.users : dialog.kind === "forum" ? data.forums : null;
      if (records && !records.some((record) => record.id === dialog.id)) return fail("Kayıt artık mevcut değil. Listeyi yenileyerek yeniden deneyin.");
    }
    if (dialog.kind === "question") {
      const options = optionIndexes.map((index) => text(`option${index}`));
      if (!text("text") || !text("category") || options.some((option) => !option)) return fail("Soru metni, kategori ve seçenekler zorunludur.");
      if (new Set(options.map((option) => option.toLocaleLowerCase("tr-TR"))).size !== options.length) return fail("Cevap seçenekleri birbirinden farklı olmalıdır.");
      if (fields.answer === "" || !Number.isInteger(Number(fields.answer)) || Number(fields.answer) < 0 || Number(fields.answer) >= options.length) return fail("Doğru cevabı seçin.");
      const previous = data.questions.find((row) => row.id === dialog.id);
      const question = { id: previous?.id ?? crypto.randomUUID(), text: text("text"), category: text("category"), difficulty: text("difficulty") as Difficulty, options, answer: Number(fields.answer), explanation: text("explanation"), date: previous?.date ?? today() };
      await commit((current) => ({ ...current, questions: previous ? current.questions.map((row) => row.id === previous.id ? question : row) : [question, ...current.questions], categories: current.categories.map((category) => ({ ...category, count: Math.max(0, category.count + ((!previous || previous.category !== question.category) && category.name === question.category ? 1 : 0) - (previous && previous.category !== question.category && category.name === previous.category ? 1 : 0)) })) }), `Soru #${question.id} ${previous ? "düzenlendi" : "eklendi"}`);
    } else if (dialog.kind === "category") {
      const name = text("name");
      if (!name) return fail("Kategori adı zorunludur.");
      if (data.categories.some((row) => row.id !== dialog.id && row.name.toLocaleLowerCase("tr-TR") === name.toLocaleLowerCase("tr-TR"))) return fail("Bu isimde bir kategori zaten bulunuyor.");
      const previous = data.categories.find((row) => row.id === dialog.id);
      await commit((current) => ({ ...current, categories: previous ? current.categories.map((row) => row.id === previous.id ? { ...row, name } : row) : [...current.categories, { id: crypto.randomUUID(), name, count: 0 }], questions: previous ? current.questions.map((row) => row.category === previous.name ? { ...row, category: name } : row) : current.questions, hints: previous ? current.hints.map((row) => row.category === previous.name ? { ...row, category: name } : row) : current.hints }), `Kategori ${name} ${previous ? "düzenlendi" : "eklendi"}`);
    } else if (dialog.kind === "plan") {
      const plans = data.plans.filter((row) => dialog.id === undefined || row.id === dialog.id);
      if (!plans.length) return fail("Abonelik paketi bulunamadı.");
      if (plans.some((row) => !text(`name${row.id}`) || !text(`price${row.id}`) || !Number.isFinite(Number(text(`price${row.id}`).replace(",", "."))) || Number(text(`price${row.id}`).replace(",", ".")) < 0 || Number(text(`price${row.id}`).replace(",", ".")) > 1000000)) return fail("Her paket için bir ad ve 0–1.000.000 TL arasında geçerli bir fiyat girin.");
      await commit((current) => ({ ...current, plans: current.plans.map((row) => fields[`name${row.id}`] === undefined ? row : { ...row, name: text(`name${row.id}`), price: Math.round(Number(text(`price${row.id}`).replace(",", ".")) * 100) / 100 }) }), "Abonelik fiyatları güncellendi");
    } else if (dialog.kind === "admob") {
      if (!/^ca-app-pub-\d{16}~\d{10}$/.test(text("appId"))) return fail("Uygulama ID, ca-app-pub- ile başlamalı ve 16 haneli yayıncı numarası ile ~ işaretinden sonra 10 haneli uygulama numarası içermelidir.");
      if (["bannerId", "interstitialId", "rewardedId"].some((name) => !/^ca-app-pub-\d{16}\/\d{10}$/.test(text(name)))) return fail("Reklam birimi ID’leri ca-app-pub- ile başlamalı ve 16 haneli yayıncı numarası ile / işaretinden sonra 10 haneli birim numarası içermelidir.");
      await commit((current) => ({ ...current, admob: { appId: text("appId"), bannerId: text("bannerId"), interstitialId: text("interstitialId"), rewardedId: text("rewardedId") } }), "AdMob ayarları güncellendi");
    } else if (dialog.kind === "forum") {
      await saveForum(fields.status as ForumStatus);
    } else if (dialog.kind === "hint") {
      if (!text("title") || !text("category") || !text("content")) return fail("Başlık, kategori ve ipucu içeriği zorunludur.");
      const previous = data.hints.find((row) => row.id === dialog.id);
      const hint = { id: previous?.id ?? nextId(data.hints), title: text("title"), category: text("category"), content: text("content") };
      await commit((current) => ({ ...current, hints: previous ? current.hints.map((row) => row.id === hint.id ? hint : row) : [hint, ...current.hints] }), `İpucu ${hint.title} kaydedildi`);
    } else if (dialog.kind === "ad") {
      if (!text("title") || !text("placement")) return fail("Reklam adı ve gösterim alanı zorunludur.");
      try { if (!["https:", "http:"].includes(new URL(text("url")).protocol)) return fail("Reklam bağlantısı http veya https ile başlamalıdır."); } catch { return fail("Geçerli bir reklam bağlantısı girin."); }
      const previous = data.ads.find((row) => row.id === dialog.id);
      const ad = { id: previous?.id ?? nextId(data.ads), title: text("title"), placement: text("placement"), url: text("url"), active: fields.active === "true" };
      await commit((current) => ({ ...current, ads: previous ? current.ads.map((row) => row.id === ad.id ? ad : row) : [ad, ...current.ads] }), `Reklam ${ad.title} kaydedildi`);
    } else if (dialog.kind === "user") {
      if (!text("name") || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(text("email"))) return fail("Kullanıcı adı ve geçerli bir e-posta adresi girin.");
      if (data.users.some((row) => row.id !== dialog.id && row.email.toLowerCase() === text("email").toLowerCase())) return fail("Bu e-posta adresi başka bir kullanıcıya ait.");
      const previous = data.users.find((row) => row.id === dialog.id);
      const user = { id: previous?.id ?? crypto.randomUUID(), name: text("name"), email: text("email"), role: fields.role as User["role"], premium: fields.premium === "true", active: fields.active === "true", joined: previous?.joined ?? today() };
      await commit((current) => ({ ...current, users: previous ? current.users.map((row) => row.id === user.id ? user : row) : [user, ...current.users] }), `Kullanıcı ${user.name} kaydedildi`);
    } else if (dialog.kind === "notification") {
      if (!text("title") || !text("message")) return fail("Bildirim başlığı ve mesajı zorunludur.");
      await commit((current) => ({ ...current, notifications: [{ id: nextId(current.notifications), title: text("title"), message: text("message"), audience: text("audience"), read: false, date: new Date().toISOString() }, ...current.notifications] }), `Bildirim oluşturuldu: ${text("title")}`);
    } else if (dialog.kind === "filters") {
      await commit((current) => ({ ...current, filters: current.filters.map((filter) => ({ ...filter, enabled: fields[filter.id] === "true" })) }), "Forum filtre ayarları güncellendi");
    } else if (dialog.kind === "profile") {
      if (!authUser || !text("name")) return fail("Görünen adınızı girin ve oturumun açık olduğunu kontrol edin.");
      setSubmitting(true);
      try { await updateProfile(authUser, { displayName: text("name") }); window.dispatchEvent(new CustomEvent("sinavapp-profile-updated")); }
      catch (cause) { return fail(firebaseErrorMessage(cause)); }
      finally { setSubmitting(false); }
      await commit((current) => current, "Yönetici profili güncellendi");
    }
  };

  if (dialog.kind === "confirm") return <>
    <div className="dialog-body"><p className="dialog-description">{dialog.title}</p>{error && <div className="form-error" role="alert">{error}</div>}</div>
    <div className="dialog-footer">
      <button type="button" className="btn btn-secondary" disabled={busy} onClick={closeDialog}>Vazgeç</button>
      <button type="button" className="btn btn-danger" disabled={busy} onClick={async () => {
        if (busy) return;
        setSubmitting(true);
        setError("");
        try {
          const success = await dialog.onConfirm?.();
          if (success !== false) closeDialog();
          else setError("İşlem tamamlanamadı. Bağlantıyı ve erişim izinlerini kontrol ederek yeniden deneyin.");
        } catch (cause) {
          setError(cause instanceof Error ? cause.message : "İşlem tamamlanamadı.");
        } finally { setSubmitting(false); }
      }}>{busy ? "İşleniyor…" : "Onayla"}</button>
    </div>
  </>;

  return <form noValidate onSubmit={submit} aria-busy={busy}>
    <div className="dialog-body">
      {error && <div className="form-error" role="alert">{error}</div>}
      {unavailable && <div className="form-error" role={collectionError ? "alert" : "status"}>{collectionError ?? "Firestore verileri yükleniyor…"}{collectionError && <button type="button" className="btn btn-small" disabled={busy} onClick={retryCollections}>Yeniden Dene</button>}</div>}
      <fieldset disabled={busy || unavailable} className="m-0 flex min-w-0 flex-col gap-4 border-0 p-0">
      {dialog.kind === "question" && <>
        <Field label="Soru metni"><textarea className="field" rows={3} required maxLength={3000} {...bind("text")} /></Field>
        <div className="form-grid">{categoryField}<Field label="Zorluk"><select className="field" {...bind("difficulty")}>{["Kolay", "Orta", "Zor"].map((value) => <option key={value}>{value}</option>)}</select></Field></div>
        <div className="form-grid">{optionIndexes.map((index) => <Field key={index} label={`${String.fromCharCode(65 + index)} seçeneği`}><input className="field" required maxLength={500} {...bind(`option${index}`)} /></Field>)}</div>
        <Field label="Doğru cevap"><select className="field" required {...bind("answer")}><option value="" disabled>Doğru cevabı seçin</option>{optionIndexes.map((index) => <option key={index} value={index}>{String.fromCharCode(65 + index)} seçeneği</option>)}</select></Field>
        <Field label="Çözüm açıklaması (isteğe bağlı)"><textarea className="field" rows={3} maxLength={3000} {...bind("explanation")} /></Field>
      </>}
      {dialog.kind === "category" && <Field label="Kategori adı"><input className="field" required maxLength={100} {...bind("name")} /></Field>}
      {dialog.kind === "plan" && data.plans.filter((row) => dialog.id === undefined || row.id === dialog.id).map((plan) => <div key={plan.id} className="form-grid plan-edit-row"><Field label="Paket adı"><input className="field" required maxLength={100} {...bind(`name${plan.id}`)} /></Field><Field label="Fiyat (TL)"><input className="field" type="number" inputMode="decimal" min="0" max="1000000" step="0.01" required {...bind(`price${plan.id}`)} /></Field></div>)}
      {dialog.kind === "admob" && <><p className="dialog-description">Google AdMob konsolundaki uygulama ve reklam birimi kimliklerini girin.</p>{[["appId", "Uygulama ID"], ["bannerId", "Banner ID"], ["interstitialId", "Geçiş Reklamı ID"], ["rewardedId", "Ödüllü Reklam ID"]].map(([name, label]) => <Field key={name} label={label}><input className="field font-mono" required spellCheck={false} maxLength={50} {...bind(name)} /></Field>)}</>}
      {dialog.kind === "forum" && (post ? <><div className="forum-review-meta"><span className="avatar" style={{ background: post.color }}>{post.avatar}</span><span><strong>{post.user}</strong><small>{formatDate(post.date, true)}</small></span></div><h3 className="forum-review-title">{post.topic}</h3><p className="forum-review-content">{post.content}</p><Field label="Moderasyon durumu"><select className="field" {...bind("status")}>{["Onaylandı", "Onay Bekliyor", "Reddedildi"].map((status) => <option key={status}>{status}</option>)}</select></Field>{data.comments.some((comment) => comment.postId === post.id) && <div className="review-comments"><h4>Gönderi yorumları</h4>{data.comments.filter((comment) => comment.postId === post.id).map((comment) => <p key={comment.id}><strong>{comment.user}: </strong>{comment.text}<small>{comment.status}</small></p>)}</div>}</> : <p role="alert">Gönderi bulunamadı.</p>)}
      {dialog.kind === "hint" && <><Field label="İpucu başlığı"><input className="field" required maxLength={150} {...bind("title")} /></Field>{categoryField}<Field label="İpucu içeriği"><textarea className="field" rows={5} required maxLength={3000} {...bind("content")} /></Field></>}
      {dialog.kind === "ad" && <><Field label="Reklam adı"><input className="field" required maxLength={150} {...bind("title")} /></Field><Field label="Gösterim alanı"><select className="field" {...bind("placement")}>{[...new Set(["Ana sayfa", "Soru çözümü", "Forum", "Sonuç ekranı", fields.placement])].map((value) => <option key={value}>{value}</option>)}</select></Field><Field label="Hedef bağlantı"><input className="field" type="url" required maxLength={2000} {...bind("url")} /></Field>{toggle("active", "Reklam yayında")}</>}
      {dialog.kind === "user" && <><p className="field-hint">Bu form Firestore kullanıcı profilini kaydeder. Firebase Authentication giriş hesabı Firebase konsolundan veya yetkili sunucu üzerinden yönetilir.</p><Field label="Ad ve soyad"><input className="field" autoComplete="name" required maxLength={100} {...bind("name")} /></Field><Field label="E-posta adresi"><input className="field" type="email" autoComplete="email" required maxLength={254} {...bind("email")} /></Field><Field label="Rol"><select className="field" {...bind("role")}>{["Kullanıcı", "Moderatör", "Admin"].map((role) => <option key={role}>{role}</option>)}</select></Field>{toggle("premium", "Premium abonelik")}{toggle("active", "Profil aktif")}</>}
      {dialog.kind === "notification" && <><Field label="Bildirim başlığı"><input className="field" required maxLength={150} {...bind("title")} /></Field><Field label="Mesaj"><textarea className="field" rows={4} required maxLength={3000} {...bind("message")} /></Field><Field label="Hedef kitle"><select className="field" {...bind("audience")}>{["Tüm kullanıcılar", "Premium kullanıcılar", "Ücretsiz kullanıcılar", "Yöneticiler"].map((audience) => <option key={audience}>{audience}</option>)}</select></Field><p className="field-hint">Bildirim bu panelin kayıtlarına eklenir. Cihazlara push gönderimi için Firebase Cloud Messaging sunucu bağlantısı gerekir.</p></>}
      {dialog.kind === "filters" && data.filters.map((filter) => <div key={filter.id} className="filter-edit-row">{toggle(filter.id, filter.name)}<p className="field-hint">{filter.description}</p></div>)}
      {dialog.kind === "profile" && <><div className="profile-summary"><UserRound size={32} /><span><strong>Sistem Yöneticisi</strong><small><ShieldCheck size={14} />Firebase Authentication oturumu</small></span></div><Field label="Görünen ad"><input className="field" required autoComplete="name" maxLength={100} {...bind("name")} /></Field><Field label="E-posta adresi"><input className="field" readOnly type="email" value={authUser?.email ?? ""} /></Field><p className="field-hint">Görünen adınız Firebase Auth hesabında güncellenir. E-posta adresi bu formdan değiştirilemez.</p><Link href="/uygulama-ayarlari" className="text-link" onClick={closeDialog}>Uygulama ayarlarını aç</Link></>}
      </fieldset>
    </div>
    <div className="dialog-footer"><button type="button" className="btn btn-secondary" disabled={busy} onClick={closeDialog}>Vazgeç</button>{dialog.kind === "forum" && post ? <><button type="button" className="btn btn-danger" disabled={busy || unavailable} onClick={() => void saveForum("Reddedildi")}>Reddet</button><button type="button" className="btn btn-primary" disabled={busy || unavailable} onClick={() => void saveForum("Onaylandı")}><Check size={15} />Onayla</button><button type="submit" className="btn btn-secondary" disabled={busy || unavailable}>{busy ? "Kaydediliyor…" : "Durumu kaydet"}</button></> : <button type="submit" className="btn btn-primary" disabled={busy || unavailable}>{busy ? "Kaydediliyor…" : dialog.kind === "notification" ? "Bildirim oluştur" : "Kaydet"}</button>}</div>
  </form>;
}

export default function Dialogs() {
  const { dialog, closeDialog, saving } = useAdmin();
  const dialogRef = useRef<HTMLDialogElement>(null);
  useEffect(() => {
    if (!dialog) return;
    const element = dialogRef.current;
    const previouslyFocused = document.activeElement instanceof HTMLElement ? document.activeElement : null;
    if (element && !element.open) {
      element.showModal();
      element.querySelector<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>("input, textarea, select")?.focus();
    }
    const originalOverflow = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    return () => {
      element?.close();
      document.body.style.overflow = originalOverflow;
      if (previouslyFocused?.isConnected) previouslyFocused.focus();
    };
  }, [dialog]);

  if (!dialog) return null;
  const title = ["question", "category", "hint", "ad", "user"].includes(dialog.kind) ? `${titles[dialog.kind]} ${dialog.id === undefined ? "ekle" : "düzenle"}` : titles[dialog.kind];
  return <dialog ref={dialogRef} className="dialog-card" aria-labelledby="admin-dialog-title" onCancel={(event) => { event.preventDefault(); if (!saving) closeDialog(); }} onClick={(event) => { if (!saving && event.target === event.currentTarget) { const rect = event.currentTarget.getBoundingClientRect(); if (event.clientX < rect.left || event.clientX > rect.right || event.clientY < rect.top || event.clientY > rect.bottom) closeDialog(); } }}>
    <div className="dialog-header"><h2 id="admin-dialog-title">{title}</h2><button type="button" className="icon-button" disabled={saving} aria-label="Pencereyi kapat" onClick={closeDialog}><X size={19} /></button></div>
    <DialogContent key={`${dialog.kind}-${dialog.id ?? "new"}`} dialog={dialog} />
  </dialog>;
}
