"use client";

import { useEffect, useMemo, useState } from "react";
import Link from "next/link";
import { ChevronLeft, ChevronRight, Eye, Search, Trash2 } from "lucide-react";
import { useAdmin } from "@/lib/admin-context";
import { formatDate, type ForumPost, type ForumStatus } from "@/lib/mockData";

const PAGE_SIZE = 10;
const statusClass: Record<ForumStatus, string> = {
  "Onaylandı": "badge-green", "Onay Bekliyor": "badge-amber", "Reddedildi": "badge-red",
};

export default function ForumTable({ full = false }: { full?: boolean }) {
  const { data, query, updateData, openDialog, confirm, notify, saving, collectionState, retryCollections } = useAdmin();
  const state = collectionState.forums;
  const writeBlocked = saving || state.loading || Boolean(state.error);
  const [status, setStatus] = useState("");
  const [search, setSearch] = useState("");
  const [page, setPage] = useState(1);
  const filtered = useMemo(() => {
    const terms = [query, full ? search : ""].map((term) => term.trim().toLocaleLowerCase("tr-TR")).filter(Boolean);
    return data.forums.filter((post) => {
      const text = `${post.user} ${post.topic} ${post.content} ${post.status}`.toLocaleLowerCase("tr-TR");
      return terms.every((term) => text.includes(term)) && (!full || !status || post.status === status);
    }).sort((a, b) => b.date.localeCompare(a.date));
  }, [data.forums, query, search, status, full]);

  useEffect(() => { setPage(1); }, [query, search, status]);
  const pageCount = Math.max(1, Math.ceil(filtered.length / PAGE_SIZE));
  const currentPage = Math.min(page, pageCount);
  const rows = full ? filtered.slice((currentPage - 1) * PAGE_SIZE, currentPage * PAGE_SIZE) : filtered.slice(0, 5);
  const deletePost = (post: ForumPost) => confirm(
    `“${post.topic}” gönderisi silinsin mi? Bağlı yorumlar ve raporlar da silinecek.`,
    async () => {
      const saved = await updateData((current) => ({
      ...current,
      forums: current.forums.filter((item) => item.id !== post.id),
      comments: current.comments.filter((item) => item.postId !== post.id),
      reports: current.reports.filter((item) => item.postId !== post.id),
      }), `“${post.topic}” forum gönderisi silindi.`);
      if (saved) notify("Forum gönderisi silindi.");
      return saved;
    },
  );
  const resetFilters = () => { setSearch(""); setStatus(""); };

  return (
    <section className={`panel forum-table${full ? " full-table" : ""}`} aria-labelledby="forum-heading">
      <div className="panel-heading"><h2 id="forum-heading">{full ? "Forum Gönderileri" : "Forumda Son Gönderiler"}</h2>{!full && <Link href="/forum" className="btn btn-small">Tümünü Gör</Link>}</div>
      {full && <div className="filter-bar"><label className="field table-search"><span>Gönderi ara</span><div className="search-field"><Search size={16} /><input value={search} onChange={(event) => setSearch(event.target.value)} placeholder="Kullanıcı veya konu ile ara" /></div></label><label className="field"><span>Durum</span><select value={status} onChange={(event) => setStatus(event.target.value)}><option value="">Tüm durumlar</option>{(["Onaylandı", "Onay Bekliyor", "Reddedildi"] as const).map((name) => <option key={name} value={name}>{name}</option>)}</select></label>{(search || status) && <button className="btn btn-small" onClick={resetFilters}>Filtreleri Temizle</button>}</div>}
      <div className="table-scroll"><table className="data-table" aria-label={full ? "Forum gönderileri" : "Forumda son gönderiler"}>
        <colgroup><col style={{ width: "19%" }} /><col style={{ width: "29%" }} /><col style={{ width: "20%" }} /><col style={{ width: "19%" }} /><col style={{ width: "13%" }} /></colgroup>
        <thead><tr><th scope="col">Kullanıcı</th><th scope="col">Konu</th><th scope="col">Tarih</th><th scope="col">Durum</th><th scope="col">İşlem</th></tr></thead>
        <tbody>{rows.map((post) => <tr key={post.id}><td><div className="user-cell"><span className="avatar" style={{ backgroundColor: post.color }} aria-hidden="true">{post.avatar}</span><span className="text-ellipsis" title={post.user}>{post.user}</span></div></td><td><span className="text-ellipsis forum-topic" title={post.topic}>{post.topic}</span></td><td className="table-date">{formatDate(post.date, true).replace(",", "")}</td><td><span className={`badge ${statusClass[post.status]}`}>{post.status}</span></td><td><div className="table-actions"><button className="icon-button" disabled={writeBlocked} onClick={() => openDialog("forum", post.id)} aria-label={`“${post.topic}” gönderisini incele`} title="İncele"><Eye size={14} /></button><button className="icon-button danger" disabled={writeBlocked} onClick={() => deletePost(post)} aria-label={`“${post.topic}” gönderisini sil`} title="Sil"><Trash2 size={14} /></button></div></td></tr>)}</tbody>
      </table></div>
      {(state.loading || state.error || rows.length === 0) && <div className="table-empty" role={state.error ? "alert" : "status"}><Search size={24} /><p>{state.loading ? "Forum gönderileri Firestore’dan yükleniyor…" : state.error ?? (query || search || status ? "Aramanıza uygun gönderi bulunamadı." : "Henüz forum gönderisi yok.")}</p>{state.error ? <button className="btn btn-small" onClick={retryCollections}>Yeniden Dene</button> : !state.loading && full && (search || status) && <button className="btn btn-small" onClick={resetFilters}>Filtreleri Temizle</button>}</div>}
      {full && <div className="pagination"><span className="pagination-info">{filtered.length === 0 ? "0 gönderi" : `${(currentPage - 1) * PAGE_SIZE + 1}–${Math.min(currentPage * PAGE_SIZE, filtered.length)} / ${filtered.length} gönderi`}</span><div className="table-actions"><button className="icon-button" disabled={currentPage === 1} onClick={() => setPage(currentPage - 1)} aria-label="Önceki sayfa"><ChevronLeft size={17} /></button><span>{currentPage} / {pageCount}</span><button className="icon-button" disabled={currentPage === pageCount} onClick={() => setPage(currentPage + 1)} aria-label="Sonraki sayfa"><ChevronRight size={17} /></button></div></div>}
    </section>
  );
}
