"use client";

import { useId, useState } from "react";
import { Area, AreaChart, CartesianGrid, ResponsiveContainer, Tooltip, XAxis, YAxis } from "recharts";
import { chartData, formatNumber } from "@/lib/mockData";

const series = [
  { key: "active", label: "Aktif Kullanıcı", color: "#1878ec" },
  { key: "solved", label: "Soru Çözme", color: "#13aa96" },
  { key: "subscribers", label: "Yeni Abone", color: "#9061ed" },
] as const;

export default function StatsChart() {
  const id = useId().replace(/:/g, "");
  const [visible, setVisible] = useState<Record<string, boolean>>({ active: true, solved: true, subscribers: true });
  return (
    <section className="stats-chart h-[218px] min-w-0 rounded-[9px] border border-[#e9edf4] bg-white/85 px-[13px] pb-[11px] pt-[13px] shadow-[0_1px_3px_#26385606]" aria-labelledby="stats-chart-title">
      <div className="mb-[10px] flex min-h-[22px] flex-wrap items-center justify-between gap-2">
        <h2 id="stats-chart-title" className="text-[14px] font-bold tracking-[-.25px] text-[#172335]">Son 7 Günlük İstatistikler</h2>
        <div className="flex gap-[16px]" aria-label="Grafik metrikleri">
          {series.map((item) => <button key={item.key} type="button" aria-pressed={visible[item.key]} title={`${item.label} metriğini ${visible[item.key] ? "gizle" : "göster"}`} onClick={() => setVisible((value) => ({ ...value, [item.key]: !value[item.key] }))} className={`flex items-center gap-[5px] text-[9px] text-[#344156] transition-opacity hover:opacity-70 ${visible[item.key] ? "opacity-100" : "opacity-40"}`}><span className="h-[8px] w-[8px] rounded-full" style={{ background: item.color }} aria-hidden="true" />{item.label}</button>)}
        </div>
      </div>
      <div className="h-[161px] w-full" role="img" aria-label="3 ile 9 Mayıs arasında aktif kullanıcı, soru çözme ve yeni abone sayıları">
        <ResponsiveContainer width="100%" height="100%" minWidth={0}>
          <AreaChart data={chartData} margin={{ top: 7, right: 17, left: -14, bottom: 0 }} accessibilityLayer>
            <defs>{series.map((item) => <linearGradient key={item.key} id={`${id}-${item.key}`} x1="0" y1="0" x2="0" y2="1"><stop offset="0%" stopColor={item.color} stopOpacity={0.1} /><stop offset="100%" stopColor={item.color} stopOpacity={0.045} /></linearGradient>)}</defs>
            <CartesianGrid stroke="#edf0f5" strokeDasharray="0" />
            <XAxis dataKey="date" axisLine={false} tickLine={false} tick={{ fill: "#667185", fontSize: 9 }} tickMargin={8} interval={0} height={22} />
            <YAxis domain={[0, 2000]} ticks={[0, 500, 1000, 1500, 2000]} axisLine={false} tickLine={false} tick={{ fill: "#566176", fontSize: 9 }} tickFormatter={formatNumber} width={48} />
            <Tooltip contentStyle={{ border: "1px solid #e4eaf3", borderRadius: 8, fontSize: 11, boxShadow: "0 3px 12px #17233512" }} labelStyle={{ fontWeight: 600, marginBottom: 5 }} formatter={(value) => formatNumber(Number(value))} labelFormatter={(label) => `${label} 2025`} />
            {series.map((item) => <Area key={item.key} type="monotone" dataKey={item.key} name={item.label} stroke={item.color} strokeWidth={1.4} fill={`url(#${id}-${item.key})`} dot={{ r: 2.7, fill: item.color, strokeWidth: 0 }} activeDot={{ r: 4, stroke: "white", strokeWidth: 2 }} hide={!visible[item.key]} isAnimationActive={false} />)}
          </AreaChart>
        </ResponsiveContainer>
      </div>
    </section>
  );
}
