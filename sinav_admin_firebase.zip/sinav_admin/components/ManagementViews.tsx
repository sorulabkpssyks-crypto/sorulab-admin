"use client";

import { useEffect, useRef, useState, type FormEvent, type ReactNode } from "react";
import { Check, CheckCheck, Download, Eye, FileJson, Pencil, Plus, Search, ShieldCheck, Trash2, Upload, X } from "lucide-react";
import { useAdmin } from "@/lib/admin-context";
import { downloadJson, validateBackup } from "@/lib/backup";
import { chartData, formatDate, formatNumber, type AppSettings, type ForumStatus, type RecordId } from "@/lib/mockData";
import { AdmobWidget, CategoriesWidget, ForumFiltersWidget, SubscriptionWidget } from "./BottomWidgets";
import StatCards from "./StatCards";
import StatsChart from "./StatsChart";

function matches(query: string, ...values: (string | number)[]) {
  return values.join(" ").toLocaleLowerCase("tr-TR").includes(query.trim().toLocaleLowerCase("tr-TR"));
}

function Panel({ title, action, children }: { title: string; action?: ReactNode; children: ReactNode }) {
  return <section className="panel"><div className="panel-heading flex flex-wrap items-center justify-between gap-3"><h2 className="text-base font-semibold">{title}</h2>{action}</div><div className="management-panel-body">{children}</div></section>;
}

function Empty({ text = "Aramanızla eşleşen kayıt bulunamadı." }: { text?: string }) {
  return <p className="py-10 text-center text-sm text-slate-500">{text}</p>;
}

function StatusBadge({ status }: { status: ForumStatus }) {
  return <span className={`badge ${status === "Onaylandı" ? "badge-green" : status === "Reddedildi" ? "badge-red" : "badge-amber"}`}>{status}</span>;
}

function BooleanBadge({ enabled, positive = "Aktif", negative = "Pasif" }: { enabled: boolean; positive?: string; negative?: string }) {
  return <span className={`badge ${enabled ? "badge-green" : "badge-red"}`}>{enabled ? positive : negative}</span>;
}

function HintsView() {
  const { data, query, openDialog, updateData, confirm, notify } = useAdmin();
  const hints = data.hints.filter((hint) => matches(query, hint.title, hint.category, hint.content));
  const remove = (id: number, title: string) => confirm(`“${title}” ipucu silinsin mi?`, async () => {
    if (!await updateData((current) => ({ ...current, hints: current.hints.filter((hint) => hint.id !== id) }), `${title} ipucu silindi`)) return;
    notify("İpucu silindi.");
  });
  return <Panel title="İpuçları" action={<button type="button" className="btn btn-primary" onClick={() => openDialog("hint")}><Plus size={15} />İpucu Ekle</button>}>
    <div className="grid gap-3 md:grid-cols-2 xl:grid-cols-3">{hints.map((hint) => <article key={hint.id} className="rounded-lg border border-slate-200 bg-slate-50 p-4"><div className="mb-2 flex items-start justify-between gap-2"><h3 className="font-semibold">{hint.title}</h3><div className="flex gap-1"><button type="button" className="icon-button" aria-label={`${hint.title} ipucunu düzenle`} onClick={() => openDialog("hint", hint.id)}><Pencil size={15} /></button><button type="button" className="icon-button danger" aria-label={`${hint.title} ipucunu sil`} onClick={() => remove(hint.id, hint.title)}><Trash2 size={15} /></button></div></div><span className="badge badge-blue">{hint.category}</span><p className="mt-3 whitespace-pre-wrap text-sm leading-6 text-slate-600">{hint.content}</p></article>)}</div>{!hints.length && <Empty />}
  </Panel>;
}

function AdsView() {
  const { data, query, openDialog, updateData, confirm, notify } = useAdmin();
  const ads = data.ads.filter((ad) => matches(query, ad.title, ad.placement, ad.url));
  const remove = (id: number, title: string) => confirm(`“${title}” reklam alanı silinsin mi?`, async () => {
    if (!await updateData((current) => ({ ...current, ads: current.ads.filter((ad) => ad.id !== id) }), `${title} reklam alanı silindi`)) return;
    notify("Reklam alanı silindi.");
  });
  async function toggle(id: number) {
    if (!await updateData((current) => ({ ...current, ads: current.ads.map((ad) => ad.id === id ? { ...ad, active: !ad.active } : ad) }), "Reklam alanının durumu değiştirildi")) return;
    notify("Reklam alanının durumu güncellendi.");
  }
  return <Panel title="Ücretli Reklam Alanları" action={<button type="button" className="btn btn-primary" onClick={() => openDialog("ad")}><Plus size={15} />Reklam Alanı Ekle</button>}>
    <p className="mb-4 text-sm text-slate-500">Reklam alanlarını, hedef bağlantıları ve yayın durumunu bu tarayıcıda yönetin.</p>
    <div className="table-scroll overflow-x-auto"><table className="data-table w-full text-left"><thead><tr><th scope="col">Başlık</th><th scope="col">Yerleşim</th><th scope="col">Hedef Bağlantı</th><th scope="col">Durum</th><th scope="col">İşlem</th></tr></thead><tbody>{ads.map((ad) => <tr key={ad.id}><td className="font-medium">{ad.title}</td><td>{ad.placement}</td><td className="max-w-xs break-all text-slate-500">{ad.url}</td><td><BooleanBadge enabled={ad.active} /></td><td><div className="flex gap-2"><button type="button" className="btn btn-small" onClick={() => toggle(ad.id)}>{ad.active ? "Durdur" : "Etkinleştir"}</button><button type="button" className="icon-button" aria-label={`${ad.title} reklamını düzenle`} onClick={() => openDialog("ad", ad.id)}><Pencil size={15} /></button><button type="button" className="icon-button danger" aria-label={`${ad.title} reklamını sil`} onClick={() => remove(ad.id, ad.title)}><Trash2 size={15} /></button></div></td></tr>)}</tbody></table></div>{!ads.length && <Empty />}
  </Panel>;
}

function CommentsView() {
  const { data, query, updateData, openDialog, confirm, notify } = useAdmin();
  const comments = data.comments.filter((comment) => matches(query, comment.user, comment.text, comment.status, data.forums.find((post) => post.id === comment.postId)?.topic ?? ""));
  const remove = (id: number) => confirm("Bu yorum kalıcı olarak silinsin mi?", async () => {
    if (!await updateData((current) => ({ ...current, comments: current.comments.filter((comment) => comment.id !== id) }), `${id} numaralı yorum silindi`)) return;
    notify("Yorum silindi.");
  });
  async function setStatus(id: number, status: ForumStatus) {
    if (!await updateData((current) => ({ ...current, comments: current.comments.map((comment) => comment.id === id ? { ...comment, status } : comment) }), `${id} numaralı yorum: ${status}`)) return;
    notify(`Yorum ${status === "Onaylandı" ? "onaylandı" : "reddedildi"}.`);
  }
  return <Panel title="Forum Yorumları"><div className="table-scroll overflow-x-auto"><table className="data-table w-full text-left"><thead><tr><th scope="col">Kullanıcı</th><th scope="col">Yorum / Gönderi</th><th scope="col">Durum</th><th scope="col">İşlem</th></tr></thead><tbody>{comments.map((comment) => {
    const post = data.forums.find((item) => item.id === comment.postId);
    return <tr key={comment.id}><td className="font-medium">{comment.user}</td><td className="max-w-lg"><p className="whitespace-pre-wrap">{comment.text}</p>{post ? <button type="button" className="mt-1 text-xs text-blue-600 hover:underline" onClick={() => openDialog("forum", post.id)}>{post.topic}</button> : <span className="mt-1 block text-xs text-slate-400">Gönderi silinmiş</span>}</td><td><StatusBadge status={comment.status} /></td><td><div className="flex gap-2"><button type="button" className="icon-button text-emerald-600" aria-label={`${comment.user} yorumunu onayla`} disabled={comment.status === "Onaylandı"} onClick={() => setStatus(comment.id, "Onaylandı")}><Check size={15} /></button><button type="button" className="icon-button danger" aria-label={`${comment.user} yorumunu reddet`} disabled={comment.status === "Reddedildi"} onClick={() => setStatus(comment.id, "Reddedildi")}><X size={15} /></button><button type="button" className="icon-button danger" aria-label={`${comment.user} yorumunu sil`} onClick={() => remove(comment.id)}><Trash2 size={15} /></button></div></td></tr>;
  })}</tbody></table></div>{!comments.length && <Empty />}</Panel>;
}

function ReportsView() {
  const { data, query, updateData, openDialog, notify } = useAdmin();
  const reports = data.reports.filter((report) => matches(query, report.user, report.reason, report.resolved ? "Çözüldü" : "İnceleme Bekliyor"));
  async function resolve(id: number) {
    if (!await updateData((current) => ({ ...current, reports: current.reports.map((report) => report.id === id ? { ...report, resolved: true } : report) }), `${id} numaralı kullanıcı raporu çözüldü`)) return;
    notify("Rapor çözüldü olarak işaretlendi.");
  }
  return <Panel title="Kullanıcı Raporları"><div className="table-scroll overflow-x-auto"><table className="data-table w-full text-left"><thead><tr><th scope="col">Raporlayan</th><th scope="col">Gönderi</th><th scope="col">Neden</th><th scope="col">Durum</th><th scope="col">İşlem</th></tr></thead><tbody>{reports.map((report) => {
    const post = data.forums.find((item) => item.id === report.postId);
    return <tr key={report.id}><td>{report.user}</td><td>{post?.topic ?? "Gönderi silinmiş"}</td><td>{report.reason}</td><td><span className={`badge ${report.resolved ? "badge-green" : "badge-amber"}`}>{report.resolved ? "Çözüldü" : "İnceleme Bekliyor"}</span></td><td><div className="flex gap-2"><button type="button" className="btn btn-small" disabled={!post} onClick={() => openDialog("forum", report.postId)}><Eye size={14} />İncele</button><button type="button" className="btn btn-small" disabled={report.resolved} onClick={() => resolve(report.id)}><ShieldCheck size={14} />Çöz</button></div></td></tr>;
  })}</tbody></table></div>{!reports.length && <Empty />}</Panel>;
}

function ProfanityView() {
  const { data, query, updateData, confirm, notify } = useAdmin();
  const [word, setWord] = useState("");
  async function add(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    const value = word.trim().toLocaleLowerCase("tr-TR");
    if (!value) return;
    if (data.profanity.some((item) => item.toLocaleLowerCase("tr-TR") === value)) { notify("Bu kelime zaten filtre listesinde.", "error"); return; }
    if (!await updateData((current) => ({ ...current, profanity: [...current.profanity, value] }), "Küfür filtresine yeni kelime eklendi")) return;
    setWord("");
    notify("Kelime filtre listesine eklendi.");
  }
  function remove(value: string) {
    confirm(`“${value}” filtre listesinden çıkarılsın mı?`, async () => {
      if (!await updateData((current) => ({ ...current, profanity: current.profanity.filter((item) => item !== value) }), "Küfür filtresinden kelime çıkarıldı")) return;
      notify("Kelime filtre listesinden çıkarıldı.");
    });
  }
  const words = data.profanity.filter((value) => matches(query, value));
  return <div className="management-stack grid gap-4 lg:grid-cols-2"><Panel title="Filtrelenen Kelimeler"><form onSubmit={add} className="mb-5 flex items-end gap-2"><label className="form-field min-w-0 flex-1"><span>Yeni kelime</span><input className="field" value={word} maxLength={100} onChange={(event) => setWord(event.target.value)} required autoComplete="off" /></label><button type="submit" className="btn btn-primary"><Plus size={15} />Ekle</button></form><ul className="space-y-2">{words.map((value) => <li key={value} className="flex items-center justify-between rounded-lg bg-slate-50 px-3 py-2"><span>{value}</span><button type="button" className="icon-button danger" aria-label={`${value} kelimesini kaldır`} onClick={() => remove(value)}><Trash2 size={15} /></button></li>)}</ul>{!words.length && <Empty />}</Panel><ForumFiltersWidget full /></div>;
}

function SettingsView({ forum = false }: { forum?: boolean }) {
  const { data, updateData, notify } = useAdmin();
  const [settings, setSettings] = useState<AppSettings>(data.settings);
  useEffect(() => setSettings(data.settings), [data.settings]);
  async function save(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    if (forum && (!Number.isInteger(settings.maxPostLength) || settings.maxPostLength < 50 || settings.maxPostLength > 100000 || !Number.isInteger(settings.dailyPostLimit) || settings.dailyPostLimit < 1 || settings.dailyPostLimit > 1000)) {
      notify("Gönderi uzunluğu 50–100.000, günlük limit 1–1.000 arasında tam sayı olmalıdır.", "error");
      return;
    }
    if (!forum && (!settings.name.trim() || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(settings.email.trim()))) { notify("Uygulama adı ve geçerli destek e-postası girin.", "error"); return; }
    if (!await updateData((current) => ({ ...current, settings: forum ? { ...current.settings, forumEnabled: settings.forumEnabled, maxPostLength: settings.maxPostLength, dailyPostLimit: settings.dailyPostLimit } : { ...current.settings, name: settings.name.trim(), email: settings.email.trim(), maintenance: settings.maintenance, registration: settings.registration } }), forum ? "Forum ayarları kaydedildi" : "Uygulama ayarları kaydedildi")) return;
    notify("Ayarlar kaydedildi.");
  }
  return <div className={`management-stack grid gap-4 ${forum ? "lg:grid-cols-2" : ""}`}><Panel title={forum ? "Forum Ayarları" : "Uygulama Ayarları"}><form onSubmit={save} className="max-w-2xl space-y-5">{forum ? <>
    <label className="flex items-center gap-3 text-sm"><input type="checkbox" className="h-4 w-4 accent-blue-600" checked={settings.forumEnabled} onChange={(event) => setSettings((current) => ({ ...current, forumEnabled: event.target.checked }))} />Forum kullanımını etkinleştir</label>
    <label className="form-field"><span>En uzun gönderi (karakter)</span><input className="field" type="number" min={50} max={100000} step={1} value={settings.maxPostLength} required onChange={(event) => setSettings((current) => ({ ...current, maxPostLength: Number(event.target.value) }))} /></label>
    <label className="form-field"><span>Kullanıcı başına günlük gönderi limiti</span><input className="field" type="number" min={1} max={1000} step={1} value={settings.dailyPostLimit} required onChange={(event) => setSettings((current) => ({ ...current, dailyPostLimit: Number(event.target.value) }))} /></label>
  </> : <>
    <div className="form-grid grid gap-4 sm:grid-cols-2"><label className="form-field"><span>Uygulama adı</span><input className="field" value={settings.name} maxLength={100} required onChange={(event) => setSettings((current) => ({ ...current, name: event.target.value }))} /></label><label className="form-field"><span>Destek e-postası</span><input className="field" type="email" value={settings.email} required onChange={(event) => setSettings((current) => ({ ...current, email: event.target.value }))} /></label></div>
    <label className="flex items-center gap-3 text-sm"><input type="checkbox" className="h-4 w-4 accent-blue-600" checked={settings.maintenance} onChange={(event) => setSettings((current) => ({ ...current, maintenance: event.target.checked }))} />Bakım modu</label>
    <label className="flex items-center gap-3 text-sm"><input type="checkbox" className="h-4 w-4 accent-blue-600" checked={settings.registration} onChange={(event) => setSettings((current) => ({ ...current, registration: event.target.checked }))} />Yeni kullanıcı kaydına izin ver</label>
  </>}<p className="text-xs leading-5 text-slate-500">Bu ayarlar bu tarayıcıda saklanır. Mobil uygulamada uygulanmaları için uygulamanın ayar servisine ayrıca bağlanmaları gerekir.</p><button type="submit" className="btn btn-primary"><Check size={15} />Ayarları Kaydet</button></form></Panel>{forum && <ForumFiltersWidget full />}</div>;
}

function UsersView() {
  const { data, query, openDialog, updateData, notify, saving, collectionState, retryCollections } = useAdmin();
  const userState = collectionState.users;
  const blocked = saving || userState.loading || Boolean(userState.error);
  const users = data.users.filter((user) => matches(query, user.name, user.email, user.role, user.premium ? "Premium" : "Ücretsiz", user.active ? "Aktif" : "Pasif"));
  async function toggle(id: RecordId, key: "active" | "premium") {
    if (!await updateData((current) => ({ ...current, users: current.users.map((user) => user.id === id ? { ...user, [key]: !user[key] } : user) }), `${id} numaralı kullanıcının ${key === "active" ? "hesap" : "Premium"} durumu değiştirildi`)) return;
    notify("Kullanıcı güncellendi.");
  }
  return <Panel title={`Kullanıcılar (${formatNumber(data.users.length)})`} action={<button type="button" className="btn btn-primary" disabled={blocked} onClick={() => openDialog("user")}><Plus size={15} />Kullanıcı Ekle</button>}><p className="mb-4 text-xs leading-5 text-slate-500">Bu işlemler Firestore kullanıcı profilini günceller. Yeni giriş hesabı oluşturma ve giriş hesabını devre dışı bırakma Firebase Authentication üzerinden yönetilir.</p><div className="table-scroll overflow-x-auto"><table className="data-table w-full text-left"><thead><tr><th scope="col">Ad / E-posta</th><th scope="col">Rol</th><th scope="col">Abonelik</th><th scope="col">Durum</th><th scope="col">Kayıt Tarihi</th><th scope="col">İşlem</th></tr></thead><tbody>{users.map((user) => <tr key={user.id}><td><span className="block font-medium">{user.name}</span><span className="text-xs text-slate-500">{user.email}</span></td><td>{user.role}</td><td><span className={`badge ${user.premium ? "badge-amber" : "badge-blue"}`}>{user.premium ? "Premium" : "Ücretsiz"}</span></td><td><BooleanBadge enabled={user.active} /></td><td className="whitespace-nowrap">{formatDate(user.joined)}</td><td><div className="flex flex-wrap gap-2"><button type="button" className="icon-button" aria-label={`${user.name} kullanıcısını düzenle`} disabled={blocked} onClick={() => openDialog("user", user.id)}><Pencil size={15} /></button><button type="button" className="btn btn-small" disabled={blocked} onClick={() => toggle(user.id, "active")}>{user.active ? "Pasifleştir" : "Etkinleştir"}</button><button type="button" className="btn btn-small" disabled={blocked} onClick={() => toggle(user.id, "premium")}>{user.premium ? "Premium Kaldır" : "Premium Yap"}</button></div></td></tr>)}</tbody></table></div>{userState.loading ? <p role="status" className="py-8 text-center text-slate-500">Kullanıcılar Firestore’dan yükleniyor…</p> : userState.error ? <div role="alert" className="form-error">{userState.error}<button type="button" className="btn btn-small ml-3" onClick={retryCollections}>Yeniden Dene</button></div> : !users.length && <Empty />}</Panel>;
}

function NotificationsView() {
  const { data, query, openDialog, updateData, confirm, notify } = useAdmin();
  const notifications = data.notifications.filter((item) => matches(query, item.title, item.message, item.audience));
  const unread = data.notifications.filter((item) => !item.read).length;
  async function markRead(id?: number) {
    if (!await updateData((current) => ({ ...current, notifications: current.notifications.map((item) => id === undefined || item.id === id ? { ...item, read: true } : item) }), id === undefined ? "Tüm bildirimler okundu" : "Bildirim okundu olarak işaretlendi")) return;
    notify(id === undefined ? "Tüm bildirimler okundu olarak işaretlendi." : "Bildirim okundu olarak işaretlendi.");
  }
  function remove(id: number) {
    confirm("Bu yerel bildirim kaydı silinsin mi?", async () => {
      if (!await updateData((current) => ({ ...current, notifications: current.notifications.filter((item) => item.id !== id) }), "Yerel bildirim kaydı silindi")) return;
      notify("Bildirim silindi.");
    });
  }
  return <Panel title="Bildirimler" action={<div className="flex flex-wrap gap-2"><button type="button" className="btn" disabled={!unread} onClick={() => markRead()}><CheckCheck size={15} />Tümünü Okundu Yap</button><button type="button" className="btn btn-primary" onClick={() => openDialog("notification")}><Plus size={15} />Bildirim Oluştur</button></div>}><p className="mb-5 text-sm leading-6 text-slate-500">Bildirimler bu tarayıcıdaki yerel kayıtlardır. Bildirim oluşturmak cihazlara push bildirimi veya e-posta göndermez.</p><ul className="space-y-3">{notifications.map((item) => <li key={item.id} className={`flex items-start justify-between gap-3 rounded-lg border p-4 ${item.read ? "border-slate-200 bg-slate-50" : "border-blue-100 bg-blue-50/60"}`}><div className="min-w-0"><div className="flex flex-wrap items-center gap-2"><h3 className="font-semibold">{item.title}</h3>{!item.read && <span className="badge badge-blue">Yeni</span>}</div><p className="mt-2 whitespace-pre-wrap text-sm text-slate-600">{item.message}</p><p className="mt-2 text-xs text-slate-500">{formatDate(item.date, true)} · {item.audience}</p></div><div className="flex shrink-0 gap-2">{!item.read && <button type="button" className="icon-button" aria-label={`${item.title} bildirimini okundu yap`} onClick={() => markRead(item.id)}><CheckCheck size={15} /></button>}<button type="button" className="icon-button danger" aria-label={`${item.title} bildirimini sil`} onClick={() => remove(item.id)}><Trash2 size={15} /></button></div></li>)}</ul>{!notifications.length && <Empty />}</Panel>;
}

function BackupView() {
  const { data, updateData, restoreData, confirm, notify, saving } = useAdmin();
  const inputRef = useRef<HTMLInputElement>(null);
  const [reading, setReading] = useState(false);
  async function download() {
    try {
      downloadJson({ version: 1, createdAt: new Date().toISOString(), data }, `sinavapp-yedek-${new Date().toISOString().slice(0, 10)}.json`);
      if (!await updateData((current) => current, "Firestore kayıtları ve yerel ayarların JSON yedeği indirildi")) return;
      notify("Yedek dosyası indirildi.");
    } catch { notify("Yedek dosyası indirilemedi.", "error"); }
  }
  async function readFile(file?: File) {
    if (!file || reading || saving) return;
    setReading(true);
    try {
      if (file.size > 10 * 1024 * 1024) throw new Error("Yedek dosyası 10 MB’den küçük olmalıdır.");
      const validated = validateBackup(JSON.parse(await file.text()));
      confirm(`“${file.name}” dosyası doğrulandı. Yalnızca bu tarayıcıdaki ayarlar, ipuçları, reklam alanları, yorumlar, raporlar, bildirimler ve günlükler geri yüklensin mi? Firestore kullanıcıları, soruları, forum gönderileri ve kategorileri değiştirilmez.`, async () => {
        try { return await restoreData(validated); }
        catch (error) { notify(error instanceof Error ? error.message : "Yedek geri yüklenemedi.", "error"); return false; }
      });
    } catch (error) {
      notify(error instanceof SyntaxError ? "Dosya geçerli bir JSON belgesi değil." : error instanceof Error ? error.message : "Yedek dosyası okunamadı.", "error");
    } finally {
      setReading(false);
      if (inputRef.current) inputRef.current.value = "";
    }
  }
  return <div className="management-stack grid gap-4 lg:grid-cols-2"><Panel title="Veri Yedeği Oluştur"><div className="mb-5 flex h-12 w-12 items-center justify-center rounded-xl bg-blue-50 text-blue-600"><FileJson size={25} /></div><p className="mb-4 text-sm leading-6 text-slate-600">Panelde görüntülenen Firestore kullanıcılarını, soruları, forum gönderilerini ve kategorileri yerel ayarlar ve sistem günlükleriyle birlikte JSON olarak indirin.</p><dl className="mb-5 grid grid-cols-3 gap-3 rounded-lg bg-slate-50 p-4 text-sm"><div><dt className="text-slate-500">Soru</dt><dd className="mt-1 font-semibold">{formatNumber(data.questions.length)}</dd></div><div><dt className="text-slate-500">Kullanıcı</dt><dd className="mt-1 font-semibold">{formatNumber(data.users.length)}</dd></div><div><dt className="text-slate-500">Gönderi</dt><dd className="mt-1 font-semibold">{formatNumber(data.forums.length)}</dd></div></dl><button type="button" className="btn btn-primary" disabled={saving} onClick={download}><Download size={16} />JSON Yedeğini İndir</button></Panel><Panel title="Yedekten Geri Yükle"><div className="mb-5 flex h-12 w-12 items-center justify-center rounded-xl bg-purple-50 text-purple-600"><Upload size={25} /></div><p className="mb-4 text-sm leading-6 text-slate-600">JSON yedeği yalnızca bu tarayıcıdaki ayarlar, ipuçları, reklam alanları, yorumlar, raporlar, bildirimler ve günlükleri geri yükler. Canlı Firestore kullanıcıları, soruları, forum gönderileri ve kategorileri korunur.</p><label className="form-field mb-4"><span>JSON yedek dosyası</span><input ref={inputRef} type="file" accept=".json,application/json" className="field text-sm file:mr-3 file:rounded file:border-0 file:bg-blue-50 file:px-3 file:py-1 file:text-blue-600" disabled={reading || saving} onChange={(event) => void readFile(event.target.files?.[0])} /></label><p role="status" className="text-xs text-slate-500">{reading ? "Yedek dosyası doğrulanıyor…" : "En fazla 10 MB. Geri yükleme canlı Firestore koleksiyonlarına yazmaz."}</p></Panel></div>;
}

function LogsView() {
  const { data, query, notify } = useAdmin();
  const [search, setSearch] = useState("");
  const logs = data.logs.filter((log) => matches(query, log.action, log.type, formatDate(log.date, true)) && matches(search, log.action, log.type, formatDate(log.date, true)));
  function download() {
    try {
      downloadJson({ createdAt: new Date().toISOString(), logs }, `sinavapp-gunlukler-${new Date().toISOString().slice(0, 10)}.json`);
      notify("Görüntülenen günlük kayıtları indirildi.");
    } catch { notify("Günlük dosyası indirilemedi.", "error"); }
  }
  return <Panel title={`Sistem Günlükleri (${formatNumber(logs.length)})`} action={<button type="button" className="btn" onClick={download}><Download size={15} />Günlükleri İndir</button>}><label className="relative mb-4 block max-w-md"><span className="sr-only">Günlük kayıtlarında ara</span><Search size={16} className="pointer-events-none absolute left-3 top-3 text-slate-400" /><input type="search" className="field pl-10" value={search} onChange={(event) => setSearch(event.target.value)} placeholder="İşlem veya tarihe göre ara…" /></label><p className="mb-4 text-xs text-slate-500">Bu tarayıcıda gerçekleştirilen yönetim işlemlerinin son 500 kaydı tutulur.</p><div className="table-scroll overflow-x-auto"><table className="data-table w-full text-left"><thead><tr><th scope="col">Tarih</th><th scope="col">İşlem</th><th scope="col">Tür</th></tr></thead><tbody>{logs.map((log, index) => <tr key={`${log.id}-${index}`}><td className="whitespace-nowrap">{formatDate(log.date, true)}</td><td>{log.action}</td><td><span className={`badge ${log.type === "Uyarı" ? "badge-amber" : "badge-blue"}`}>{log.type}</span></td></tr>)}</tbody></table></div>{!logs.length && <Empty />}</Panel>;
}

function SubscriptionsView() {
  const { data, query, openDialog, collectionState, retryCollections, saving } = useAdmin();
  const subscribers = data.users.filter((user) => user.premium && matches(query, user.name, user.email, user.active ? "Aktif" : "Pasif"));
  return <div className="management-stack grid gap-4 lg:grid-cols-[1fr_1.8fr]"><SubscriptionWidget full /><Panel title={`Premium Kullanıcılar (${data.users.filter((user) => user.premium).length})`}><p className="mb-4 text-xs leading-5 text-slate-500">Firestore kullanıcı kayıtlarındaki Premium abonelik bilgileri gösterilir.</p><div className="table-scroll overflow-x-auto"><table className="data-table w-full text-left"><thead><tr><th scope="col">Kullanıcı</th><th scope="col">E-posta</th><th scope="col">Hesap Durumu</th><th scope="col">İşlem</th></tr></thead><tbody>{subscribers.map((user) => <tr key={user.id}><td className="font-medium">{user.name}</td><td>{user.email}</td><td><BooleanBadge enabled={user.active} /></td><td><button type="button" disabled={saving || collectionState.users.loading || Boolean(collectionState.users.error)} className="icon-button" aria-label={`${user.name} aboneliğini düzenle`} onClick={() => openDialog("user", user.id)}><Pencil size={15} /></button></td></tr>)}</tbody></table></div>{collectionState.users.loading ? <p role="status" className="py-8 text-center text-slate-500">Abonelikler yükleniyor…</p> : collectionState.users.error ? <div role="alert" className="form-error">{collectionState.users.error}<button type="button" className="btn btn-small ml-3" onClick={retryCollections}>Yeniden Dene</button></div> : !subscribers.length && <Empty text="Eşleşen Premium kullanıcı kaydı yok." />}</Panel></div>;
}

function StatisticsView() {
  return <div className="management-stack space-y-4"><StatCards /><StatsChart /><Panel title="Günlük Metrikler"><p className="mb-4 text-xs leading-5 text-slate-500">3–9 Mayıs 2025 dönemine ait tasarımın örnek istatistikleri. Günlük analitik verileri henüz bir olay koleksiyonuna bağlanmamıştır.</p><div className="table-scroll overflow-x-auto"><table className="data-table w-full text-left"><thead><tr><th scope="col">Tarih</th><th scope="col">Aktif Kullanıcı</th><th scope="col">Çözülen Soru</th><th scope="col">Yeni Abone</th></tr></thead><tbody>{chartData.map((day) => <tr key={day.date}><td>{day.date} 2025</td><td>{formatNumber(day.active)}</td><td>{formatNumber(day.solved)}</td><td>{formatNumber(day.subscribers)}</td></tr>)}</tbody><tfoot><tr className="font-semibold"><td>Dönem Özeti</td><td>{formatNumber(Math.round(chartData.reduce((total, day) => total + day.active, 0) / chartData.length))} günlük ortalama</td><td>{formatNumber(chartData.reduce((total, day) => total + day.solved, 0))} toplam</td><td>{formatNumber(chartData.reduce((total, day) => total + day.subscribers, 0))} toplam</td></tr></tfoot></table></div></Panel></div>;
}

export default function ManagementViews({ section }: { section: string }) {
  switch (section) {
    case "ipuclari": return <HintsView />;
    case "reklam-alanlari": return <AdsView />;
    case "yorumlar": return <CommentsView />;
    case "raporlar": return <ReportsView />;
    case "kufur-filtresi": return <ProfanityView />;
    case "forum-ayarlari": return <SettingsView forum />;
    case "kullanicilar": return <UsersView />;
    case "uygulama-ayarlari": return <SettingsView />;
    case "bildirimler": return <NotificationsView />;
    case "yedekleme": return <BackupView />;
    case "gunlukler": return <LogsView />;
    case "abonelikler": return <SubscriptionsView />;
    case "admob": return <AdmobWidget full />;
    case "kategoriler": return <CategoriesWidget full />;
    case "istatistikler": return <StatisticsView />;
    default: return null;
  }
}
