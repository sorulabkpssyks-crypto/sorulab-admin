"use client";

import { useEffect } from "react";
import Link from "next/link";
import { CheckCircle2, AlertCircle, Info, X } from "lucide-react";
import { useAdmin } from "@/lib/admin-context";
import Sidebar from "./Sidebar";
import Header from "./Header";
import StatCards from "./StatCards";
import StatsChart from "./StatsChart";
import QuickActions from "./QuickActions";
import QuestionsTable from "./QuestionsTable";
import ForumTable from "./ForumTable";
import BottomWidgets from "./BottomWidgets";
import Dialogs from "./Dialogs";
import ManagementViews from "./ManagementViews";
import PdfImport from "./PdfImport";

const titles: Record<string, string> = {
  sorular: "Soru Yönetimi", pdf: "PDF ile Soru Ekle", kategoriler: "Kategoriler", ipuclari: "İpuçları Yönetimi",
  admob: "AdMob Ayarları", "reklam-alanlari": "Ücretli Reklam Alanları", abonelikler: "Abonelik Yönetimi",
  forum: "Forum Gönderileri", yorumlar: "Forum Yorumları", raporlar: "Kullanıcı Raporları", "kufur-filtresi": "Küfür Filtresi",
  "forum-ayarlari": "Forum Ayarları", kullanicilar: "Kullanıcılar", "uygulama-ayarlari": "Uygulama Ayarları",
  istatistikler: "İstatistikler", bildirimler: "Bildirimler", yedekleme: "Yedekleme", gunlukler: "Sistem Günlükleri",
};

export default function AdminPanel({ section }: { section: string }) {
  const { sidebarOpen, toasts, dismissToast, setQuery } = useAdmin();
  useEffect(() => { setQuery(""); }, [section, setQuery]);
  return <div className="admin-shell">
    <a href="#main-content" className="skip-link">İçeriğe geç</a>
    <Sidebar />
    <div className={`main-shell ${sidebarOpen ? "sidebar-visible" : ""}`}>
      <Header />
      <main id="main-content" className={`main-content ${section ? "management-content" : "dashboard-content"}`}>
        {!section ? <>
          <h1 className="sr-only">SınavApp Admin Paneli</h1>
          <StatCards />
          <div className="dashboard-middle"><StatsChart /><QuickActions /></div>
          <div className="dashboard-tables"><QuestionsTable /><ForumTable /></div>
          <BottomWidgets />
        </> : <>
          <div className="page-heading"><div><div className="breadcrumb"><Link href="/">Ana Sayfa</Link><span>/</span><span>{titles[section]}</span></div><h1>{titles[section]}</h1></div></div>
          {section === "sorular" ? <QuestionsTable full /> : section === "forum" ? <ForumTable full /> : section === "pdf" ? <PdfImport /> : <ManagementViews section={section} />}
        </>}
      </main>
    </div>
    <Dialogs />
    <div className="toast-stack" aria-live="polite" aria-atomic="false">
      {toasts.map((toast) => {
        const Icon = toast.type === "error" ? AlertCircle : toast.type === "info" ? Info : CheckCircle2;
        return <div key={toast.id} className={`toast toast-${toast.type}`} role={toast.type === "error" ? "alert" : "status"}><Icon size={19} /><span>{toast.message}</span><button aria-label="Mesajı kapat" onClick={() => dismissToast(toast.id)}><X size={16} /></button></div>;
      })}
    </div>
  </div>;
}
